package uky.itr.POLE;
   

public class HPlanner {
	protected ParseSPUDD m_MDP;
	protected DD m_valueFn;
	protected DD m_policy;
    protected String [] m_V1Values = new String[16];
    protected int max;
    
    protected DD policyExpansion(DD E,int flag){
    DD from=E;
    
   
    
    DD [] everything = new DD[m_MDP.varNames.size()/2 + 1];
    int [] allVar = new int[m_MDP.varNames.size()/2];
    for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
	{
		allVar[i] = i+1;
	}
    
        if (flag==0)
    {
    	DD [] tempEverything=new DD[m_MDP.varNames.size()/2 + 1];
		
		// construct a two dimensional array: cpt -- cpt[i] stores a list of cpts of all actions for
		// variable i
	
	tempEverything[tempEverything.length-1]=OP.clearConfig(E);
	
	for (int i=0;i<m_MDP.actNames.size();i++)
		
	{	
		
		 for ( int j = 0; j < m_MDP.varNames.size()/2; j++ )
			{
				DD [] cptForCurrentVar = new DD[1];
				cptForCurrentVar[0] = ((DD [])(m_MDP.actTransitions.get(i)))[j];
				tempEverything[j] = DDnode.myNew(Global.varNames.length, cptForCurrentVar);
				tempEverything[j]=OP.clearConfig(tempEverything[j]);
			}
	
		//DD tempE=OP.addMultVarElim(tempEverything,allVar);
		DD tempE=OP.multAddVarElim(tempEverything,allVar);
		tempE=OP.clearConfig(tempE);
	//	System.out.println("tempE");
		tempE=OP.originalVars(tempE,m_MDP.varNames.size()/2);
		tempE=OP.addToBdd(tempE);
		tempE=OP.reorder(tempE);
	//	tempE.display();
		E=OP.max(E,tempE);
		
		
	}
	
    } else
    {	
    for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
	{
		DD [] cptForCurrentVar = new DD[1];
		cptForCurrentVar[0] = ((DD [])(m_MDP.policyActTransitions.get(0)))[i];
	//	cptForCurrentVar[0] = ((DD [])(m_MDP.policyActTransitions.get(0)))[i];
		everything[i] = DDnode.myNew(Global.varNames.length, cptForCurrentVar);
	}
    
   
   from = OP.clearConfig(from);
  everything[everything.length-1] = from;
    E = OP.addMultVarElim(everything, allVar);
//   E.display();
  E=OP.addToBdd(E);
 // E.display();
  E=OP.originalVars(E,m_MDP.varNames.size()/2);
  E=OP.max(from,E);
  
    }
    return E;
    
    }
    
    protected DD valueIteration(DD E,DD V)
	{


		int [] originalVar = new int[m_MDP.varNames.size()/2];
		int [] primedVar = new int[m_MDP.varNames.size()/2];
		int start = m_MDP.varNames.size()/2;
	//	DD saveV=V;
		
		// construct an array of all variables
		for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
		{
			originalVar[i] = i+1;
		}

		// construct an array of primed variables
		for ( int i = start; i < m_MDP.varNames.size(); i++ )
		{
			primedVar[i-start] = i+1;
		}
		
		DD [] everything = new DD[m_MDP.varNames.size()/2 + 2]; // last two will be primedValFn and discount
		DD [] tempEverything=new DD[m_MDP.varNames.size()/2 + 1];
		
			// construct a two dimensional array: cpt -- cpt[i] stores a list of cpts of all actions for
			// variable i
		DD primedE;
		tempEverything[tempEverything.length-1]=OP.clearConfig(E);
		primedE=DD.zero;
		for (int i=0;i<m_MDP.actNames.size();i++)
			
		{	
			
			 for ( int j = 0; j < m_MDP.varNames.size()/2; j++ )
				{
					DD [] cptForCurrentVar = new DD[1];
					cptForCurrentVar[0] = ((DD [])(m_MDP.actTransitions.get(i)))[j];
					tempEverything[j] = DDnode.myNew(Global.varNames.length, cptForCurrentVar);
					tempEverything[j]=OP.clearConfig(tempEverything[j]);
				}
		
			DD tempE=OP.addMultVarElimRounding(tempEverything,originalVar);
			tempE=OP.clearConfig(tempE);
		//	System.out.println("tempE");
			tempE=OP.originalVars(tempE,m_MDP.varNames.size()/2);
			tempE=OP.addToBdd(tempE);
			tempE=OP.reorder(tempE);
		//	tempE.display();
			primedE=OP.max(primedE,tempE);
			primedE=OP.reorder(primedE);
			
		}
		
		for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
		{
			DD [] cptsForCurrentVar = new DD[m_MDP.actNames.size()];
			for ( int j = 0; j < m_MDP.actNames.size(); j++ )
			{
				cptsForCurrentVar[j] = ((DD [])(m_MDP.actTransitions.get(j)))[i];
			}
			everything[i] = DDnode.myNew(Global.varNames.length, cptsForCurrentVar);
		
		}

		int [] allVar = new int[m_MDP.varNames.size()];
		for ( int i = 0; i < m_MDP.varNames.size(); i++ )
		{
			allVar[i] = i+1;
		}
		
		//construct reward add, assuming actions have no costs
		DD rewards = m_MDP.reward;
		rewards = OP.multRounding(rewards,E);
		
		
		//primedE=OP.originalVars(primedE,m_MDP.varNames.size()/2);
	//primedE.display();
		DD discount = m_MDP.discount;
		double tolerance = m_MDP.tolerance.getVal();
		boolean converged = false;
		DD bellErr = DD.one;
		int iter = 0;
		boolean firstIteration = true;
		//V.display();
		
		V=OP.multRounding(V,primedE);
		V=OP.reorder(V);
	//	System.out.println("V");
	//	V.display();
	
		while( (!converged )&& (iter<30))
		{
			
			System.out.println(" # of Iterations for value iteration: " + iter);
			iter++;
		
			DD primedValFn = OP.primeVars(OP.clearConfig(V), m_MDP.varNames.size()/2);
			
			everything[everything.length-2] = primedValFn;
			
			everything[everything.length-1] = discount;
			
			DD qFn = OP.addMultVarElimRounding(everything, primedVar);
			
			qFn = OP.addRounding(qFn, rewards);
			
			if ( !firstIteration ){
				
				qFn = OP.approximate(qFn, (1-discount.getVal()>0.95?0.95:discount.getVal())*bellErr.getVal()/10);
			
			}
			int [] tempVars = new int[1];
			tempVars[0] = Global.varNames.length;
			
			DD newValFn = OP.maxAddVarElimRounding(qFn, tempVars);
			
			
	
		
			DD diff = OP.abs(OP.sub(OP.mult(newValFn,E),OP.mult(V,E)));
			
			bellErr = OP.maxAddVarElim(diff, allVar);
			//V=OP.max(OP.multRounding(newValFn,E),OP.multRounding(saveV,OP.reverseBdd(E)));
			V=OP.max(OP.multRounding(newValFn,E),OP.multRounding(m_MDP.reward,OP.reverseBdd(E)));
			V=OP.reorder(V);
			firstIteration = false;
			converged = bellErr.getVal()<=tolerance;
		
	 		
		} 
		System.out.println("Total # of Iterations for value iteration: " + iter);
	
		return V;
}
    
    protected DD buildPolicy(DD valFn)
	{	
		DD[] children = valFn.getChildren();
		if ( children == null ) // leaf node
		{
			int [][] config = ((DDleaf)valFn).getConfig();
			if ( config == null )
			{
				//System.out.println("Error: cannot parse policy");
				return DDnode.one;
			}
			for ( int i = 0; i < config[0].length; i++ )
			{
				// TODO: we now assume that actions are of the form "a\d"!
				String action = Global.valNames[config[0][i]-1][config[1][i]-1];
				double actionID = Double.parseDouble(action.substring(1));
				return DDleaf.myNew(actionID, config);
			}
		}
		DD[] newchildren = new DD[children.length];
		for ( int i = 0; i < children.length; i++ )
		{
			newchildren[i] = buildPolicy(children[i]);
		}
		return DDnode.myNew(valFn.getVar(), newchildren);
	}
	
    public DD getPolicy() {
		return m_policy;
	}
    
    public void run(String filename,long timeLimit,int iterNum)
	{
    	
		m_MDP = new ParseSPUDD(filename);
		m_MDP.parsePOMDP(true);
		DD E=m_MDP.initial;
		(OP.reorder(E)).display();
		
		
		DD V=m_MDP.reward ;
		V=OP.reorder(V);
		long beginTime,endTime,time,totalTime;
		time=0;
		totalTime=0;
		int iter=0;
		while ((time<=timeLimit)&& (iter<iterNum))
		{
			iter++;
			System.out.println("iter:"+iter);
			time=0;

			beginTime=System.currentTimeMillis();
	/*		
			if (iter==1)
			{
			E=OP.reorder(policyExpansion(E,0));
			}
			else 
			{
			*/
			E=OP.reorder(policyExpansion(E,0));
		
			E.display();
/*			m_valueFn = valueIteration(E,V);
			//m_valueFn.display();
			V=OP.multRounding(m_valueFn,E);
			V=OP.reorder(V);
	//		V.display();
		
		
			m_policy = buildPolicy(V);
			//m_policy.display(); 
			m_MDP.m_ddPolicyCore=m_policy; 
			m_MDP.policyActCPTGen();
			endTime=System.currentTimeMillis();
			time=endTime-beginTime;
			totalTime=totalTime+time;
			System.out.println("time="+time); */
		}
	/*	System.out.println("Total # of iter="+iter);
		System.out.println("Total time="+totalTime);
		V=OP.multRounding(V,m_MDP.initial);
		V=OP.reorder(V);
		V.display();
		m_policy = buildPolicy(V);
		m_policy.display();*/
	}
}