package uky.itr.POLE;
import uky.itr.POLE.ParseSPUDD;
import java.math.*;
public class CMain {
	protected ParseSPUDD m_MDP;
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		/*
		 * The action add description in the input file must be complete: each variable whose domain 
		 * has n values should have n branches. For example, for binary variable a, it should look like
		 * (a (true (1.00)) (false (0.00))). Please note that the format is different from the format that
		 * SPUDD uses. It is similar to the "old format" on the SPUDD website. However, in each brunch,
		 * the value of the variable must be specified, unlike that in the SPUDD old format where those
		 * values are omitted.
		 * Furthermore, the ADD representation of the CPT for an action must have the following form. 
		 * Let a' be the primed variable associated with an ADD. In other words, this ADD specifies
		 * the probability of variable a having one of its values in the next planning step, given an
		 * action. Assuming a is a binary variable, in SPUDD format, we only need to specify the probility
		 * for a being true in the next step. However, here we need to specify both probabilities: a being
		 * true and a being false. In a multi-valued case, we need to specify probabilities for each value.
		 * Please refer to the "example.txt" to get an idea how to write such an ADD.
		 */    
	
		//test IPlanner

	
		
	
	for (int i=0;i<10;i++)
		{
	

		IPlanner planner=new IPlanner();
	
	
	
		double value[]=new double[2];
		
		value=planner.simulate("factory1.dat",10000,10,10);
		
		System.out.println(value[1]);
		
		}
	
		
		
	//test concurrent action planner or SPUDD
	/*
		
	CPlanner planner1 = new CPlanner();
	planner1.run(args[0],0,10);
	

	*/
	
	}
	

}
