package uky.itr.POLE;

import java.io.IOException;
import java.io.StreamTokenizer;
import java.io.StringReader;
import java.util.Random;
import uky.itr.POLE.DD;
import uky.itr.POLE.DDnode;
import uky.itr.POLE.Global;
import uky.itr.POLE.OP;
import uky.itr.POLE.ParseSPUDD;

import java.util.Vector;
import java.util.Random;
//import planIt.pole.DD;
//import planIt.pole.DDnode;
//import planIt.pole.Global;
//import planIt.pole.OP;
//import planIt.pole.ParseSPUDD;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.lang.management.*;


public class IPlanner {
	public ParseSPUDD m_MDP;
	public DD[] policy;
	protected DD m_valueFn;
	protected DD m_policy;
    protected String [] m_V1Values = new String[16];
    protected int max;
    protected boolean stop;
    public int[] acts = new int[1]; 
    public String actName;
    //m_MDP = new ParseSPUDD(input);
	//m_MDP.parsePOMDP(true);
   public int[][] config;
    
   public long getCpuTime() {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    return bean.isCurrentThreadCpuTimeSupported( ) ?
	        bean.getCurrentThreadCpuTime( ) : 0L;
	}
	 
	/** Get user time in nanoseconds. */
	public long getUserTime( ) {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    return bean.isCurrentThreadCpuTimeSupported( ) ?
	        bean.getCurrentThreadUserTime( ) : 0L;
	}

	/** Get system time in nanoseconds. */
	public long getSystemTime( ) {
	   
	       return getCpuTime( ) - getUserTime( );
	}
	
    //get reachable states from E
    
    protected DD spaceExpansion(DD E, int flag){
      
    int [] allVar = new int[m_MDP.varNames.size()/3];
    for ( int i = 0; i < m_MDP.varNames.size()/3; i++ )
	{
		allVar[i] = i+1;
	}
    
   
  //  DD [] tempEverything=new DD[m_MDP.varNames.size()/2 + 1];
   DD [] tempEverything=new DD[m_MDP.varNames.size()/3+1 ];
   DD [] everything = new DD[m_MDP.actNames.size()];	
    int [] primedVar = new int[m_MDP.varNames.size()/3];
    int start = m_MDP.varNames.size()/3;
    for ( int i = start; i < m_MDP.varNames.size()/3*2; i++ )
	{
		primedVar[i-start] = i+1;
	}
		// construct a two dimensional array: cpt -- cpt[i] stores a list of 
    	//cpts of all actions for variable i
	
	//tempEverything[tempEverything.length-1]=OP.clearConfig(E);
	
    tempEverything[tempEverything.length-1]=OP.clearConfig(E);
  	if (flag==0){
		for (int i=0;i<m_MDP.actNames.size();i++)
		
		{	
			
		 for ( int j = 0; j < m_MDP.varNames.size()/3; j++ )
			{
				DD [] cptForCurrentVar = new DD[1];
				cptForCurrentVar[0] = ((DD [])(m_MDP.actTransitions.get(i)))[j];
				tempEverything[j] = DDnode.myNew(Global.varNames.length, cptForCurrentVar);
				tempEverything[j]=OP.clearConfig(tempEverything[j]);
			
				DD tempE=OP.mult(tempEverything[tempEverything.length-1],tempEverything[j]);
			
				tempE=OP.addToBdd(tempE);
				//tempE.display();
				
				for (int k=0;k< m_MDP.varNames.size()/3;k++)
				{
					tempE=OP.addout(tempE, k+1);
				}
			tempE=OP.addToBdd(tempE);
				if (j==0)
					{
						everything[i]=tempE;
					}
				else 
				{
					everything[i]=OP.mult(everything[i],tempE);
	
					//everything[i]=OP.add(everything[i],tempE);
					everything[i]=OP.addToBdd(everything[i]);
	
				}
			}
		
		 everything[i]=OP.originalVars(everything[i], m_MDP.varNames.size()/3);
		
		 everything[i]=OP.addToBdd(everything[i]);
	
		
		}
	
		
		
		
		E=OP.addN(everything);
		E=OP.addToBdd(E);
		//tempE.display();
	}
	else {
	 for ( int i = 0; i < m_MDP.varNames.size()/3; i++ )
		{
			DD [] cptForCurrentVar = new DD[1];
			cptForCurrentVar[0] = ((DD [])(m_MDP.policyActTransitions.get(0)))[i];
		
			everything[i] = DDnode.myNew(Global.varNames.length, cptForCurrentVar);
			everything[i]=OP.clearConfig(everything[i]);
		}
	    
	   
		  everything[everything.length-1] = OP.clearConfig(E);
	 // DD tempE = OP.addMultVarElim(everything, allVar);
		  DD tempE = OP.addMultVarElim(everything, primedVar);
//	   E.display();tempE=OP.clearConfig(tempE);
		//tempE=OP.originalVars(tempE,m_MDP.varNames.size()/2);
		tempE=OP.addToBdd(tempE);
		tempE=OP.reorder(tempE);
	  
	  E=OP.max(tempE,E);
	    
	}
	return E;
    }
	
    //compute the value functions for states already expanded (at horizon 0,..,n-1)
    //E is the current state space, V is the current value functions 
    //n is the current horizon
	 protected DD [] valueIteration(DD [] E,DD [] V,int n,boolean flag)
		{

		 	
			int [] originalVar = new int[m_MDP.varNames.size()/3];
			int [] primedVar = new int[m_MDP.varNames.size()/3];
			int start = m_MDP.varNames.size()/3;
			DD discount = m_MDP.discount;
			DD bellErr = DD.one;
		//	DD [] Val=new DD[n+1];
			//Val[n]=V[n];
			// construct an array of all variables
			for ( int i = 0; i < m_MDP.varNames.size()/3; i++ )
			{
				originalVar[i] = i+1;
			}

			// construct an array of primed variables
			for ( int i = start; i < m_MDP.varNames.size()/3*2; i++ )
			{
				primedVar[i-start] = i+1;
			}
			
			//DD [] everything = new DD[m_MDP.varNames.size()/2 + 3];
			//DD [] everything = new DD[m_MDP.varNames.size()/2 + 2];		
			DD [] everything = new DD[m_MDP.varNames.size()/3 + 1];		
			
			for ( int i = 0; i < m_MDP.varNames.size()/3; i++ )
			{
				DD [] cptsForCurrentVar = new DD[m_MDP.actNames.size()];
				for ( int j = 0; j < m_MDP.actNames.size(); j++ )
				{
					cptsForCurrentVar[j] = ((DD [])(m_MDP.actTransitions.get(j)))[i];
				}
				everything[i] = DDnode.myNew(Global.varNames.length, cptsForCurrentVar);
			
			}

			int [] allVar = new int[m_MDP.varNames.size()/3*2];
			for ( int i = 0; i < m_MDP.varNames.size()/3*2; i++ )
			{
				allVar[i] = i+1;
			}
			
			
			for (int i=n;i>=1;i--)
			{
				//DD primedValFn = OP.primeVars(OP.clearConfig(V[i]), m_MDP.varNames.size()/2);
				DD primedValFn = OP.primeVars(V[i], m_MDP.varNames.size()/3);
				everything[everything.length-1] = primedValFn;
			
				//everything[everything.length-2] = E[i-1];
				//everything[everything.length-3]=discount;
				DD qFn = OP.addMultVarElimRounding(everything, primedVar);
			
				 //qFn = OP.addRounding(OP.mult(qFn,discount),V[i]);
				 qFn = OP.addRounding(OP.mult(qFn,discount),OP.mult(E[i-1],m_MDP.reward));
				//qFn = OP.addRounding(qFn, V[i]);
			if ( i!=n ){
					
					qFn = OP.approximate(qFn, (1-discount.getVal()>0.95?0.95:discount.getVal())*bellErr.getVal()/10);
				
				}
				int [] tempVars = new int[1];
				tempVars[0] = Global.varNames.length;
			
				V[i-1] = OP.maxAddVarElimRounding(qFn, tempVars);	
				
				if ((flag)& (!stop))
					{
						DD diff = OP.abs(OP.subRounding(V[i-1], V[i]));
					
						bellErr = OP.maxAddVarElimRounding(diff, allVar);
						 stop= bellErr.getVal()<=m_MDP.tolerance.getVal();
					}
				V[i-1]=OP.reorder(OP.mult(V[i-1],E[i-1]));	
				//	System.out.println("belErr="+bellErr.getVal());
			}
			return V;
	}
	 
	 	protected String pickAction(DD valFn)
	 	{	
			DD[] children = valFn.getChildren();
			int actionID=0;
			String action="";
			if ( children == null ) // leaf node
			{
				int [][] config = ((DDleaf)valFn).getConfig();
				if ( config != null )
				{
					//System.out.println("Error: cannot parse policy");
					//return DDnode.one;
			
			
			for ( int i = 0; i < config[0].length; i++ )
					//for ( int i = config[0].length-1; i >=0; i-- )
				{
					// TODO: we now assume that actions are of the form "a\d"!
					action = Global.valNames[config[0][i]-1][config[1][i]-1];
				
					actionID=m_MDP.actNames.indexOf(action);
					
					//Double.parseDouble(action.substring(1));
				
					return action;
				}
			}
			}
			DD[] newchildren = new DD[children.length];
			for ( int i = 0; i < children.length; i++ )
			{
				newchildren[i] = buildPolicy(children[i]);
			}
			
			return "";
			
		}
		
	 	protected DD buildPolicy(DD valFn)
		{	
			DD[] children = valFn.getChildren();
			
			int j=0;
			if ( children == null ) // leaf node
			{
				int [][] config = ((DDleaf)valFn).getConfig();
				if ( config == null )
				{
					//System.out.println("Error: cannot parse policy");
					//return DDnode.one;
					return DDnode.zero;
				}
			for ( int i = 0; i < config[0].length; i++ )
					//for ( int i = config[0].length-1; i >=0; i-- )
				{
					// TODO: we now assume that actions are of the form "a\d"!
					String action = Global.valNames[config[0][i]-1][config[1][i]-1];
					
					int actionID=m_MDP.actNames.indexOf(action);
					acts[0]=actionID;
					actName=action;
					//System.out.println(actName);
				
					return DDleaf.myNew(actionID, config);
					
				}
			}
			DD[] newchildren = new DD[children.length];
			for ( int i = 0; i < children.length; i++ )
			{
				newchildren[i] = buildPolicy(children[i]);
			}
			return DDnode.myNew(valFn.getVar(), newchildren);
		}
		
		//build optimal policy for finite horizon MDPs --------Liangrong Dec. 8
		protected DD [] buildFinitePolicy(DD [] valFns, int n)
		{	
		//	for (int i=0;i<valFns.length;i++)
				for (int i=0;i<n;i++){
				System.out.println(i);
					valFns[i] = buildPolicy(valFns[i]);
			}
			return valFns;
		}
			    
public int run(String input,long timeLimit,int maxIter, int p, int first)
		{	
	long startSystemTimeNano = getSystemTime( );
	long startUserTimeNano   = getUserTime( );
	long startCpuTime=getCpuTime();
		 	long beginTime,endTime,time,totaltime;
		 	beginTime=System.currentTimeMillis();
		 	totaltime=0;
			time=0;
			if (first==1)
				{
					m_MDP = new ParseSPUDD(input);
					m_MDP.parsePOMDP(true);
					
				}
			//m_MDP.initial.display();
			//m_MDP.reward.display();
			
			int [][] varval=new int [m_MDP.nStateVars][2];
			double totalstates=1;
		
			for (int i=0;i<m_MDP.nStateVars;i++)
			{
				varval[i][0]=i+1;
				varval[i][1]=((Vector) m_MDP.valNames.elementAt(i)).size();
				//System.out.println(varval[i][1]);
			totalstates= totalstates*varval[i][1];
				
			}
			System.out.println("totalstates="+totalstates);
			int n=maxIter;
			DD [] E=new DD[n+1]; 
			DD [] V=new DD[n+1];
			
			E[0]=m_MDP.initial;
			V[0]=OP.mult(E[0],m_MDP.reward);
						
			
			Boolean flag=false;
			int i=1;
			int [] allVar = new int[m_MDP.varNames.size()/3*2];
			for ( int j = 0; j < m_MDP.varNames.size()/3*2; j++ )
			{
				allVar[j] = j+1;
			}
			Boolean converged=false;
			
			stop=false;
			while ((i<=n)& (time<timeLimit) & (!stop))
			{
			//System.out.println("iter="+i);
						
			
				if (converged==false)
				{	
					E[i]= spaceExpansion(E[i-1],0);
				//						
				
				//	if (OP.totalStates(E[i], varval, m_MDP.nStateVars-1)==OP.totalStates(E[i-1], varval, m_MDP.nStateVars-1))
				//		System.out.println("stop");
					
					if (OP.sub(E[i],E[i-1])==DD.zero)
					{
						if (p==1)
						{
							System.out.println("i="+i);
							System.out.println("state space stops expanding");
							System.out.println("number of states expended="+OP.totalStates(E[i], varval, m_MDP.nStateVars-1));
							
						}
						converged=true;
						//E[i].display();
					}
				
				
					if (E[i].getVar() == 0)
					{
						flag=true;
						System.out.println("flag is "+flag);
					}
				}		
				else E[i]=E[i-1];
				
				//the value functions for states at the fringe are static
						
				V[i]=OP.mult(E[i],m_MDP.reward);
				
		
				V=valueIteration(E,V,i,flag);
				endTime=System.currentTimeMillis();
				time=endTime-beginTime;
				
				
				i++;
			
				
				
		}
			
			
			
			//get the value function for states at all stages
		//	System.out.println("total time for computing value functions ="+totaltime);
		
		
			//V[0]=OP.elimZero(V[0]);
		
		//V[0].display();
		//OP.mult(V[0],E[0]).display();
		buildPolicy(OP.elimZero(OP.mult(V[0],E[0])));
		long taskUserTimeNano    = getUserTime( ) - startUserTimeNano;
		long taskSystemTimeNano  = getSystemTime( ) - startSystemTimeNano;
		long taskCpuTimeNano  = getCpuTime( ) - startCpuTime;
		
		System.out.println(taskCpuTimeNano);
		//System.out.println("acition="+actName);
		
	
			
//		policy=buildFinitePolicy(V,i-1);
	//	OP.mult(policy[0],E[0]).display();
		return acts[0];
	//	return V;
		}


public double take (int actionID)
{ 
	DD [] actTrans = (DD[])(m_MDP.actTransitions.get((int)actionID));
	int [][] s=new int[2][m_MDP.varNames.size()/3];
	
	double [] leaves;
	 Random generator = new Random();
	// System.out.print(generator);
	 
	 double rand =generator.nextDouble();
	 
	for ( int j = 0; j < m_MDP.varNames.size()/3; j++ )
	{//OP.restrict(actTrans[j],m_MDP.initialConfig).display();
		//actTrans[j].display();

		leaves = OP.enumerateLeaves(OP.restrict(actTrans[j],m_MDP.initialConfig));
		double t[]=new double[leaves.length];
		t[0] = leaves[0];
		for (int m = 1;m <leaves.length;m++)
		{
			t[m]=t[m-1] + leaves[m];
		}
		
		
		 int newvalue=0;
		 for (int i=0;i<leaves.length;i++)
		 {
			 if (rand<=t[i]) 
			{
				 	newvalue=i;
				 	break;
			}
		 }
		 
		 s[0][j]=j+1;
		 s[1][j]=newvalue+1;
		//System.out.println(s[1][j]);
		 
	}
	m_MDP.initialConfig=s;
	m_MDP.initial=Config.convert2dd(s);
//	if (OP.eval(OP.addToBdd(m_MDP.reward), m_MDP.initialConfig)>0) return 0;
//	else return 1;
//	if (OP.sub(OP.addToBdd(m_MDP.reward), m_MDP.initial)==DD.zero)	return 1;
	//else return 0;
	//if (OP.eval(m_MDP.reward, m_MDP.initialConfig)>0) return 1; else return 0;
	
	return OP.eval(m_MDP.reward, s);

}

public double []simulate(String filename,int max, int horizon, int step)
{
	double value;
	double returnvalue[]= new double [2];
	int actionID=run(filename,max,horizon,1,1);
	//System.out.println("action="+actionID);
	value=take(actionID);
	int i;
	for (i=1;i<step; i++)
		{
		
		actionID=run(filename,max,horizon,1,1);
		//System.out.println("action="+actionID);
			//value=+take(actionID);
			value=value+Math.pow(m_MDP.discount.getVal(),i)*take(actionID);
		//	System.out.println("value="+value);
			//if (OP.eval(m_MDP.reward, m_MDP.initialConfig)>0) break;
		}
	returnvalue[0]=i;
	returnvalue[1]=value;
//	System.out.println("totalvalue="+value);
	return returnvalue;
	
}
public  DD getOneConfig (DD dd)
{	
	
	if ((dd.getVar() == 0)& (dd.getVal()==1)){
		
			
			if (((DDleaf)dd).getConfig()!=null)
				{
					//System.out.println("HOw");
					config = ((DDleaf)dd).getConfig();
				}
			return Config.convert2dd(config);
		
}
	else {
		if (dd.getVar() != 0)
		{DD[] children = new DD[dd.getChildren().length];
		for (int i=0; i<children.length; i++) {
				children[i] = getOneConfig(dd.getChildren()[i]);
		}
		return DDnode.myNew(dd.getVar(),children);
		}
		else return DDleaf.myNew(0,null);

	}
}
}