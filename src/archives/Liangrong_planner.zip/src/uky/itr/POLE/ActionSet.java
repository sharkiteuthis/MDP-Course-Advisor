package uky.itr.POLE;
import java.io.*;


public class ActionSet{
	private StreamTokenizer stream;
	public String[][] comActions;
	//added by Liangrong
	public String[][] ActionSets(String fileName) {
		
		//comActions=new String [1004][4];
		comActions=new String [40][3];
		//comActions=new String [15][3];
		//for (int j=1;j<=1003;j++)
		
			for (int j=1;j<2;j++)
			{
			//initialize the combin action set
			comActions[j][0]="";
			comActions[j][1]="";
			comActions[j][2]="";
			//comActions[j][3]="";
			}
	
		try {
				stream = new StreamTokenizer(new FileReader(fileName));
			} 
		catch (FileNotFoundException e) 
			{             				
				System.out.println("Error: file not found\n");
				System.exit(1);
			} 
		stream.wordChars('\'','\'');
		stream.wordChars('_','_');
		
		try{
			while (StreamTokenizer.TT_EOF!= stream.ttype) {
				stream.nextToken();
			
				switch(stream.ttype) 
				{
					case StreamTokenizer.TT_WORD:
						if (stream.sval.compareTo("Answer-set") == 0) {
							System.out.println("d");
							parseActions();
							}
					default: 
				}
			}
			
		}
		
		catch (IOException e) {             
					System.out.println("Error: IOException\n");
					System.exit(1);
		}

	
	return comActions;
	}
	
	public void parseActions() {
		try {
			int i=0;
			
			stream.nextToken();
			if (StreamTokenizer.TT_NUMBER == stream.ttype) {
					int index=(int)(stream.nval);
					System.out.println("index="+index);
					//robot coffee tea, two combined actions
					
					 	 
						while (i<2){
						stream.nextToken();
						switch(stream.ttype) {
						case ',':
						{
							stream.nextToken();
							if (StreamTokenizer.TT_WORD == stream.ttype){
								i++;
								if (i==1)comActions[index][0]=stream.sval.toString();
								else comActions[index][0]=comActions[index][0]+stream.sval.toString();
								comActions[index][i]=stream.sval.toString();
							}
						}
						default: 
						}
					}
					
					//master advising 3 combined actions ------added by Liangrong April 27, 2008
					/*while (i<3){
						System.out.println(i);
						stream.nextToken();
						switch(stream.ttype) {
						case '(':
						{
							
							stream.nextToken();
							System.out.println(stream.sval.toString());
							if (StreamTokenizer.TT_WORD == stream.ttype){
								i++;
								System.out.println(i);
								if (i==1){
									
										System.out.println("1="+i);
										comActions[index][0]=stream.sval.toString();
										comActions[index][i]=stream.sval.toString();
										}
								if(i==2){
									System.out.println("2="+i);
										
										comActions[index][0]=comActions[index][0]+stream.sval.toString();
										comActions[index][i]=stream.sval.toString();
										
									}
									if (i==3){ System.out.println("3="+i);
										comActions[index][0]=comActions[index][0]+stream.sval.toString();
										comActions[index][i]=stream.sval.toString();
										
									}
								
								
							}
						}
						default: 
						}
						
					}*/
					System.out.println(comActions[index][0]);
			}
						else {
							System.out.println("Error: set not found\n");
							System.exit(1);
						}
						
			
		
		}
		catch (IOException e) {
			System.out.println("Error: IOException\n");
			System.exit(1);
		}
	}
}
