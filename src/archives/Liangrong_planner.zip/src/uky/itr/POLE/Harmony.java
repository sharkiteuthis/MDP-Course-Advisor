package uky.itr.POLE;
   
import java.util.Vector;
import java.lang.Number;

import java.util.Random;
public class Harmony {
	protected ParseSPUDD m_MDP;
	protected DD m_valueFn;
	protected DD m_policy;
    protected String [] m_V1Values = new String[16];
    protected int max;
    
    protected DD [] valueIterationMusic(boolean policyEvaluation, int steps)
	{
		if ( policyEvaluation )
		{
			System.out.println("Evaluating plan ...");
		}
		else
		{
			System.out.println("Computing the optimal plan ...");
		}
		
		int [] allVar = new int[m_MDP.varNames.size()/3*2];
		int [] primedVar = new int[m_MDP.varNames.size()/3];
		int start = m_MDP.varNames.size()/3;
		
		// construct an array of all variables
//		int v1ID = m_MDP.varNames.indexOf("v1");
//		int v5ID = m_MDP.varNames.indexOf("v1");
//		int v9ID = m_MDP.varNames.indexOf("v9");

		int vID = 0;
		for ( int i = 0; i < m_MDP.varNames.size()/3*2; i++ )
		{
//			if ( i == v1ID || i == v5ID )
//				continue;
			
			allVar[vID] = i+1;
			vID++;
		}

		// construct an array of primed variables
		vID = start;
		for ( int i = start; i < m_MDP.varNames.size()/3*2; i++ )
		{
//			if ( i == start+v1ID || i == start + v5ID )
//				continue;
			
			primedVar[vID-start] = i+1;
			vID++;
		}
		
		
		
		
		DD [] everything = new DD[m_MDP.varNames.size()/3+2]; // last two will be primedValFn and discount

		int everythingID = 0;
		if ( policyEvaluation )
		{
			// variable i
			for ( int i = 0; i < m_MDP.varNames.size()/3; i++ )
			{
//				if ( i == v1ID || i == v5ID )
//					continue;
				
				DD [] cptForCurrentVar = new DD[1];
				cptForCurrentVar[0] = ((DD [])(m_MDP.policyActTransitions.get(0)))[i];
				everything[everythingID] = 
					DDnode.myNew(Global.varNames.length, cptForCurrentVar);
				everythingID++;
			}
		}
		else
		{
			// construct a two dimensional array: cpt -- cpt[i] stores a list of cpts of all actions for
			// variable i
			for ( int i = 0; i < m_MDP.varNames.size()/3; i++ )
			{
//				if ( i == v1ID || i == v5ID )
//					continue;
				
				DD [] cptsForCurrentVar = new DD[m_MDP.actNames.size()];
				for ( int j = 0; j < m_MDP.actNames.size(); j++ )
				{
					cptsForCurrentVar[j] = ((DD [])(m_MDP.actTransitions.get(j)))[i];
				}
				everything[everythingID] = DDnode.myNew(Global.varNames.length, cptsForCurrentVar);
				everythingID++;
			}
		}
		
		//construct reward add, assuming actions have no costs
//		Vector varValNames = (Vector)m_MDP.valNames.get(v5ID);
		DD rewards = m_MDP.reward;
/*		int [][] v1set = new int[2][2];

		v1set[0][0] = v1ID+1;
		v1set[1][0] = varValNames.indexOf(m_V1Values[steps-2])+1;
		v1set[0][1] = v5ID+1;
		v1set[1][1] = varValNames.indexOf(m_V1Values[steps-1])+1;
		DD currentrewards = OP.restrict(rewards, v1set);
		currentrewards.display();
		DD valFn = currentrewards;
*/
		int iter = steps-1;
		DD discount = m_MDP.discount;
		DD valFn = rewards;
//		DD currentrewards;
		DD [] valFns= new DD[steps] ;
		DD primedValFn;
		while ( iter >=0 )
		{
			System.out.println("Iteration #"+iter);
		/*	if (iter==5)
				{
					m_MDP.initial.display();
					primedValFn = OP.primeVars(OP.clearConfig(OP.mult(valFn,m_MDP.initial)), m_MDP.varNames.size()/2);
					//primedValFn.display();
				}
			else 
				{*/
					primedValFn = OP.primeVars(OP.clearConfig(valFn), m_MDP.varNames.size()/3);
					//primedValFn.display();
			//	}
			everything[everything.length-2] = primedValFn;
			everything[everything.length-1] = discount;
			
			// change the CPT for variable v5 in each iteration: Pr(v5=m_V1Values[steps-iter-1]) = 1
			// the probabilities are stored in everything[4]
	/*		DD [] children = everything[v1ID].getChildren();
			for ( int j = 0; j < children.length; j++ ){
				DD [] grandChildren = children[j].getChildren();
				for (int i=0;i<children.length;i++){
					if ( varValNames.indexOf(m_V1Values[steps-iter-1]) == i )
					{
						grandChildren[i] = DDleaf.myNew(1.0, grandChildren[i].getConfig());
					}
					else
					{
						grandChildren[i] = DDleaf.myNew(0.0, grandChildren[i].getConfig());
					}
				}
			}*/
//			everything[v5ID].display();

//			System.out.println("everything[0]:");
//			everything[0].display();
//			System.out.println("everything[1]:");
//			everything[1].display();
			
			DD qFn = OP.addMultVarElim(everything, primedVar);
			/*			v1set[0][0] = v1ID+1;
			v1set[1][0] = varValNames.indexOf(m_V1Values[steps-iter-1])+1;
			v1set[0][1] = v5ID+1;
			v1set[1][1] = varValNames.indexOf(m_V1Values[steps-iter-1])+1;
			currentrewards = OP.restrict(rewards, v1set);
			currentrewards.display();
			
			qFn = OP.add(qFn, currentrewards);*/
		
			qFn = OP.add(qFn, rewards);
			int [] tempVars = new int[1];
			tempVars[0] = Global.varNames.length;
			DD newValFn = OP.maxAddVarElim(qFn, tempVars);
			valFn = newValFn;
			valFns[iter]=newValFn;
			OP.reorder(valFn);
			//valFn.display();
			iter--;
		}
	
		return valFns;
	}
    
   
    public void music(String filename)
	{
    	m_MDP = new ParseSPUDD(filename);
		
		m_MDP.parsePOMDP(true);
		
    	
		String [] p1 = new String[16];
		String [] p2= new String[16];
		String [] p3 = new String[16];
		String [] p4 = new String[16];
	
		int [][] s=new int[2][10];
	
		
		/*m_V1Values[0] = "E";
		m_V1Values[1] = "G";
		m_V1Values[2] = "E";
     	m_V1Values[3] = "C";
     	m_V1Values[4] = "D";
		m_V1Values[5] = "G";
		m_V1Values[6] = "D";
		m_V1Values[7] = "D";
		
		m_V1Values[0] = "E";
		m_V1Values[1] = "G";
		m_V1Values[2] = "E";
     	m_V1Values[3] = "C";
     	m_V1Values[4] = "D";
		m_V1Values[5] = "D";
		m_V1Values[6] = "C";
		m_V1Values[7] = "C";
		*/
		/*m_V1Values[0] = "E";
		m_V1Values[1] = "E";
		m_V1Values[2] = "F";
     	m_V1Values[3] = "G";
     	m_V1Values[4] = "G";
		m_V1Values[5] = "F";
		m_V1Values[6] = "E";
		m_V1Values[7] = "D";
		*/
	/*	m_V1Values[0] = "C";
		m_V1Values[1] = "C";
		m_V1Values[2] = "D";
		m_V1Values[3] = "E";
		m_V1Values[4] = "D";
		m_V1Values[5] = "C";
		m_V1Values[6] = "C";
		m_V1Values[7] = "C";
		*/
	
		/*m_V1Values[0] = "G";
		m_V1Values[1] = "E";
		m_V1Values[2] = "A";
		m_V1Values[3] = "B";
		m_V1Values[4] = "C";
		m_V1Values[5] = "C";
		m_V1Values[6] = "B";
		m_V1Values[7] = "B";*/
	/*	
		m_V1Values[0] = "C";
		m_V1Values[1] = "D";
		m_V1Values[2] = "E";
		m_V1Values[3] = "D";
		m_V1Values[4] = "C";
		m_V1Values[5] = "B";
		m_V1Values[6] = "A";
		m_V1Values[7] = "G";*/
		
		m_V1Values[0] = "C";
		m_V1Values[1] = "F";
		m_V1Values[2] = "E";
		m_V1Values[3] = "D";
		m_V1Values[4] = "E";
		m_V1Values[5] = "D";
		m_V1Values[6] = "C";
		m_V1Values[7] = "C";
		
		DD []	valueFn = valueIterationMusic(m_MDP.isPlanEvaluation(), 5);
		DD []policy=buildFinitePolicy(valueFn);
		//IPlanner musicPlanner= new IPlanner();
	
		//DD [] policy=musicPlanner.run(filename,10000000,6,1,1);
	
		
	for (int l=0;l<2;l++){
		 System.out.println("l="+l);	
		for (int i = 0; i < 10; i++ )
		{
			s[0][i]=i+1;
		}
		Vector varValNames = (Vector)m_MDP.valNames.get(1);
	/*	s[1][0]=varValNames.indexOf(m_V1Values[0])+1; 		
		s[1][1]=7;
		s[1][2]=5 ;
		s[1][3]= 3;
		s[1][4]=varValNames.indexOf(m_V1Values[1])+1;
		s[1][5]=7 ;
		s[1][6]=5 ;
		s[1][7]=3 ;
		s[1][8]=varValNames.indexOf(m_V1Values[2])+1;
		s[1][9]=1;*/
		s[1][0]=varValNames.indexOf(m_V1Values[0])+1; 		
		s[1][1]=7;
		s[1][2]=3 ;
		s[1][3]= 5;
		s[1][4]=varValNames.indexOf(m_V1Values[1])+1;
		s[1][5]=2 ;
		s[1][6]=6 ;
		s[1][7]=4 ;
		s[1][8]=varValNames.indexOf(m_V1Values[2])+1;
		s[1][9]=1;
		p1[0]=varValNames.get(s[1][0]-1).toString();
		p2[0]=varValNames.get(s[1][1]-1).toString();
		p3[0]=varValNames.get(s[1][2]-1).toString();
		p4[0]=varValNames.get(s[1][3]-1).toString();
		p1[1]=varValNames.get(s[1][4]-1).toString();
		p2[1]=varValNames.get(s[1][5]-1).toString();
		p3[1]=varValNames.get(s[1][6]-1).toString();
		p4[1]=varValNames.get(s[1][7]-1).toString();
		double [] leaves;
	
		for ( int i = 0; i <5; i++ )
		{
			 System.out.println("i="+i);
			//policy[i].display();
			 for (int j=0;j<=9;j++)
				{
					
					System.out.println(m_MDP.varNames.get(j) + " = " + varValNames.get(s[1][j]-1));
				}
			 double actionID =OP.eval(policy[i],s);
			 //System.out.println(s[1][9]);
			    System.out.println("actionID="+actionID);
				DD [] actTrans = (DD[])(m_MDP.actTransitions.get((int)actionID-1));
				int [] news = new int[3];
			
			for ( int k = 5; k <= 7; k++)
				{
					leaves = OP.enumerateLeaves(OP.restrict(actTrans[k],s));
					//System.out.println("leaves length = "+leaves.length);
					double t[]=new double[15];
					
					t[0] = leaves[0];
					for (int m = 1;m <leaves.length;m++)
					{
						t[m]=t[m-1] + leaves[m];
						//System.out.println("pr:"+t[m]);
					}
					
					 Random generator = new Random();
					 int newvalue=0;
					 double rand =generator.nextDouble();
					 for (int j=0;j<leaves.length;j++)
					 {
						 if (rand<=t[j]) 
						{
							 	newvalue=j;
							 	break;
						}
					 }
					 news[k-5]=newvalue+1;
					// System.out.println(varValNames.get(newvalue));
					 
					// varValnames.get(newvalue);
						 
				}
		
				s[1][0]=s[1][4];
				s[1][1]=s[1][5];
				s[1][2]=s[1][6];
				s[1][3]=s[1][7];
				s[1][4]=s[1][8];
				s[1][5]=news[0];
				s[1][6]=news[1];
				s[1][7]=news[2];
				
				
				
					s[1][8]=varValNames.indexOf(m_V1Values[i+3])+1;
				
				//System.out.println(varValNames.indexOf(m_V1Values[i+2])+1);
				s[1][9]=s[1][9]+1;
				//System.out.println(s[1][9]);
		
		/*if (i==0)
		{
			p1[i+1]=varValNames.get(s[1][0]-1).toString();
			p2[i+1]=varValNames.get(s[1][1]-1).toString();
			p3[i+1]=varValNames.get(s[1][2]-1).toString();
			p4[i+1]=varValNames.get(s[1][3]-1).toString();
		}
			*/
		for (int j=4;j<=7;j++)
		{
			
			System.out.println(m_MDP.varNames.get(j) + " = " + varValNames.get(s[1][j]-1));
			
		}
		p1[i+2]=varValNames.get(s[1][4]-1).toString();
		p2[i+2]=varValNames.get(s[1][5]-1).toString();
		p3[i+2]=varValNames.get(s[1][6]-1).toString();
		p4[i+2]=varValNames.get(s[1][7]-1).toString();
		/*p1=p1+varValNames.get(s[1][4]-1);
		p2=p2+varValNames.get(s[1][5]-1);
		p3=p3+varValNames.get(s[1][6]-1);
		p4=p4+varValNames.get(s[1][7]-1);*/
		//System.out.println(m_MDP.varNames.get(9) + " = " + varValNames.get(s[1][9]-1));
		
		}
		System.out.println("V: 1");
		for (int i=0;i<=6;i++)
		{
			
			if ((p2[i].charAt(0)>(p1[i].charAt(0))&(p1[i]!="A")& (p1[i]!="B"))){
				System.out.print(p1[i].toLowerCase()+"'");
			}else System.out.print(p1[i].toLowerCase());
			
			if ((i%4)==3) System.out.print("|");
		}
		System.out.println("|");
		System.out.println("V: 2");
		for (int i=0;i<=6;i++)
		{
			System.out.print(p2[i].toLowerCase());
			if ((i%4)==3) System.out.print("|");
		}
		
		
		System.out.println("|");
		System.out.println("V: 3");
		for (int i=0;i<=6;i++)
		{
			System.out.print(p3[i]);
			if ((i%4)==3) System.out.print("|");
		}
		System.out.println("|");
		System.out.println("V: 4");
		for (int i=0;i<=6;i++)
		{
			if ((p4[i].charAt(0)>(p3[i].charAt(0))&(p3[i]!="A")& (p3[i]!="B"))){
				System.out.print(p4[i]+",");}
				else System.out.print(p4[i]);
			if ((i%4)==3) System.out.print("|");
		}
		System.out.println("|");
	}
	}
    public  DD [] buildFinitePolicy(DD [] valFns)
	{	
		for (int i=0;i<valFns.length;i++){
				System.out.println("i="+i);
				valFns[i] = buildPolicy(valFns[i]);
		}
		return valFns;
	}
    public DD buildPolicy(DD valFn)
	{	
		DD[] children = valFn.getChildren();
		if ( children == null ) // leaf node
		{
			int [][] config = ((DDleaf)valFn).getConfig();
			if ( config == null )
			{
				//System.out.println("Error: cannot parse policy");
				//return DDnode.one;
				return DDnode.zero;
			}
		for ( int i = 0; i < config[0].length; i++ )
				//for ( int i = config[0].length-1; i >=0; i-- )
			{
				
				String action = Global.valNames[config[0][i]-1][config[1][i]-1];
		
				
				int actionID=m_MDP.actNames.indexOf(action)+1;
				return DDleaf.myNew(actionID, config);
				
			}
		}
		DD[] newchildren = new DD[children.length];
		for ( int i = 0; i < children.length; i++ )
		{
			newchildren[i] = buildPolicy(children[i]);
		}
		return DDnode.myNew(valFn.getVar(), newchildren);
	}
	
    public void musicInput(String filename)
    {
	m_MDP = new ParseSPUDD(filename);
	System.out.println("begin");
	m_MDP.parsePOMDP(true);
	m_MDP.reward.display();
	
	
	String [] p1 = new String[16];
	String [] p2= new String[16];
	String [] p3 = new String[16];
	String [] p4 = new String[16];

	int [][] s=new int[2][10];

	
	m_V1Values[0] = "E";
	m_V1Values[1] = "E";
	m_V1Values[2] = "F";
 	m_V1Values[3] = "G";
 	m_V1Values[4] = "G";
	m_V1Values[5] = "F";
	m_V1Values[6] = "E";
	m_V1Values[7] = "D";
	
	m_V1Values[0] = "C";
	m_V1Values[1] = "C";
	m_V1Values[2] = "D";
	m_V1Values[3] = "E";
	m_V1Values[4] = "D";
	m_V1Values[5] = "C";
	m_V1Values[6] = "C";
	m_V1Values[7] = "C";
	
    }

}
	