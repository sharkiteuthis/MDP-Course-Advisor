package uky.itr.POLE;
class DDcollection {
	
	
		/////////////////////////////////////////////////////////
		// removeIth
		/////////////////////////////////////////////////////////
		public static DD[] removeIth(DD[] collection, int ith) {

				DD[] remCollection = new DD[collection.length-1];
				for (int i=0; i<ith; i++) 
						remCollection[i] = collection[i];
				for (int i=ith+1; i<collection.length; i++)
						remCollection[i-1] = collection[i];
				return remCollection;
		}

		/////////////////////////////////////////////////////////
		// add
		/////////////////////////////////////////////////////////
		public static DD[] add(DD[] collection, DD dd) {

				DD[] newCollection = new DD[collection.length+1];
				for (int i=0; i<collection.length; i++)
						newCollection[i] = collection[i];
				newCollection[collection.length] = dd;
				return newCollection;
		}
		
		/*public static int[] getVarSets(DD [] collection){
			int[] varSet;
			varSet=collection[0].getVarSet();
			for (int i=1; i<collection.length; i++)
			{
				if (varSet == null) 
				{
					varSet = new int[1];
					varSet[0] = collection[i].getVar();
					for (int childId=0; childId<collection[i].getChildren().length; childId++) {
					{
						DD [] children=collection[childId].getChildren();
						
						varSet = MySet.unionOrdered(getVarSets(children),varSet);
					}
				}
			}
			return varSet;	
		}
}*/
		
		public static int[] getVarSets(DD [] collection){
			int[] varSet;
			varSet=collection[0].getVarSet();
			for (int i=0;i<varSet.length ;i++)
				System.out.println(varSet[i]);
			for (int i=1; i<collection.length; i++)
			{
				if (varSet==null)
				{
					varSet=collection[i].getVarSet();
				}
				else varSet=MySet.unionOrdered(varSet,collection[i].getVarSet());
				
			}
			return varSet;
		}
		
}
		
		

