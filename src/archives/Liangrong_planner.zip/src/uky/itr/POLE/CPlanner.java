package uky.itr.POLE;
   
import java.util.Vector;
import java.util.Random;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.math.*;
public class CPlanner {
	protected ParseSPUDD m_MDP;
	protected DD m_valueFn;
	protected DD m_policy;
    protected String [] m_V1Values = new String[16];
    protected int max;
    protected Vector actNames;
    
    
    public long getCpuTime() {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    return bean.isCurrentThreadCpuTimeSupported( ) ?
	        bean.getCurrentThreadCpuTime( ) : 0L;
	}
	 
	/** Get user time in nanoseconds. */
	public long getUserTime( ) {
	    ThreadMXBean bean = ManagementFactory.getThreadMXBean( );
	    return bean.isCurrentThreadCpuTimeSupported( ) ?
	        bean.getCurrentThreadUserTime( ) : 0L;
	}

	/** Get system time in nanoseconds. */
	public long getSystemTime( ) {
	   
	       return getCpuTime( ) - getUserTime( );
	}
   // CPlanner(String[] args) {maxiteration=args[0],limit=args[1] }
 //   CPlanner(){};
	/*
	 * Global.varNames/valNames are array version of m_MDP.varNames/valNames
	 * 
	 */
	protected DD valueIteration(boolean policyEvaluation,int max)
	{
/*	if ( policyEvaluation )
		{
			System.out.println("Evaluating plan ...");
		}
		else
		{
			System.out.print("Computing the optimal plan ...");
		}*/
	//	System.out.print("displaying the reward ...");
		//m_MDP.reward.display();

		int [] allVar = new int[m_MDP.varNames.size()/3*2];
		int [] primedVar = new int[m_MDP.varNames.size()/3];
		int start = m_MDP.varNames.size()/3;
	
		
		// construct an array of all variables
		for ( int i = 0; i < m_MDP.varNames.size()/3*2; i++ )
		{
			allVar[i] = i+1;
		}

		// construct an array of primed variables
		for ( int i = start; i < m_MDP.varNames.size()/3*2; i++ )
		{
			primedVar[i-start] = i+1;
		}
		
		DD [] everything = new DD[m_MDP.varNames.size()/3 + 2]; // last two will be primedValFn and discount

		if ( policyEvaluation )
		{
			// variable i
			for ( int i = 0; i < m_MDP.varNames.size()/3; i++ )
			{
				DD [] cptForCurrentVar = new DD[1];
				cptForCurrentVar[0] = ((DD [])(m_MDP.policyActTransitions.get(0)))[i];
				everything[i] = DDnode.myNew(Global.varNames.length, cptForCurrentVar);
			}
		}
		else
		{
			// construct a two dimensional array: cpt -- cpt[i] stores a list of cpts of all actions for
			// variable i
			
			//((DD [])(m_MDP.actTransitions.get(9)))[1].display();
			for ( int i = 0; i < m_MDP.varNames.size()/3; i++ )
			{	//System.out.println("I="+i);
				DD [] cptsForCurrentVar = new DD[m_MDP.actNames.size()];
				//System.out.println("num of actions"+m_MDP.actNames.size());
				for ( int j = 0; j < m_MDP.actNames.size(); j++ )
				{
					cptsForCurrentVar[j] = ((DD [])(m_MDP.actTransitions.get(j)))[i];
					
				}
				everything[i] = DDnode.myNew(Global.varNames.length, cptsForCurrentVar);
			}
		}
		
		//construct reward add, assuming actions have no costs
		DD rewards = m_MDP.reward;
		
		rewards = OP.reorder(rewards);
		//m_MDP.reward.display();
		DD valFn = rewards;
		DD discount = m_MDP.discount;
		double tolerance = m_MDP.tolerance.getVal();
		//System.out.println("tolerance="+tolerance);
		boolean converged = false;
		DD bellErr = DD.one;
		int iter = 0;
		boolean firstIteration = true;
		
		int [][] varval=new int [m_MDP.nStateVars][2];
		for (int i=0;i<m_MDP.nStateVars;i++)
		{
			varval[i][0]=i+1;
			varval[i][1]=((Vector) m_MDP.valNames.elementAt(i)).size();
			
		}
		//while ((( max==0)&&(!converged ))|| (iter<max))
			while ((!converged )&& (iter<max))
		{
			
			//System.out.println(" # of Iterations for value iteration: " + iter);
			iter++;
			//System.out.println("start");
			DD primedValFn = OP.primeVars(OP.clearConfig(valFn), m_MDP.varNames.size()/3);
			//System.out.println("end");
			
			//primedValFn.display();
			
			everything[everything.length-2] = primedValFn;
			//System.out.println("min"+OP.minAll(primedValFn));
			//System.out.println("min"+OP.maxAll(primedValFn));
			everything[everything.length-1] = discount;
			//System.out.println("muliply");
			DD qFn = OP.addMultVarElim(everything, primedVar);
			//System.out.println("min"+OP.minAll(qFn));
			//System.out.println("min"+OP.maxAll(qFn));
			//qFn = OP.reorder(qFn);
			//System.out.println("min"+OP.minAll(qFn));
			//System.out.println("min"+OP.maxAll(qFn));
			//System.out.println("number of leaves: "+qFn.getNumLeaves()) ;
			qFn = OP.add(qFn, rewards);
			//qFn.display();
			//System.out.println("min"+OP.minAll(qFn));
			//System.out.println("min"+OP.maxAll(qFn));
			//System.out.println("number of leaves: "+qFn.getNumLeaves()) ;
					//qFn = OP.reorder(qFn);			
			if ( !firstIteration ){
				
				qFn = OP.approximate(qFn, (1-discount.getVal()>0.95?0.95:discount.getVal())*bellErr.getVal()/10);
			
			}
			int [] tempVars = new int[1];
			tempVars[0] = Global.varNames.length;
			//System.out.println("max");
			DD newValFn = OP.maxAddVarElim(qFn, tempVars);
			//newValFn=OP.reorder(newValFn);
			//System.out.println("min"+OP.minAll(newValFn));
			//System.out.println("max"+OP.maxAll(newValFn));
			//System.out.println("number of tree leaves: "+newValFn.getNumLeaves()) ;
			newValFn.clearLeafCountFlag();
			//System.out.println("number of DD leaves: "+newValFn.getDDLeafN()) ;
			//System.out.println("max");
			DD diff = OP.abs(OP.sub(newValFn, valFn));
			//diff=OP.reorder(diff);
			//System.out.println("max");
			bellErr = OP.maxAddVarElim(diff, allVar);
			valFn = newValFn;
			//System.out.println("number of leaves: "+valFn.getNumLeaves()) ;
			//valFn.display();
		//System.out.println("bell "+bellErr.getVal()) ;
			firstIteration = false;
			converged = bellErr.getVal()<=tolerance;
		//	System.out.println("converged "+converged) ;
		// System.out.println("num of states expanded"+OP.totalStates(valFn, varval, m_MDP.nStateVars-1));
	 		
		}
			//System.out.println("Total # of Iterations for value iteration: " + iter);
	//	System.out.println("    bellmanErr = "+bellErr.getVal());
//		System.out.println("    valueFn: " + OP.nEdges(valFn) + 
//							"edges, " + OP.nNodes(valFn) + "nodes, " + OP.nLeaves(valFn) + "leaves");
		//valFn.display();
		//	buildPolicy(valFn);
		return valFn;
		
	}

	//This is not correct ----------------------Liangrong Dec.8
	protected DD valueIterationFiniteHorizon(boolean policyEvaluation, int steps)
	{
		if ( policyEvaluation )
		{
			System.out.println("Evaluating plan ...");
		}
		else
		{
			System.out.println("Computing the optimal plan ...");
		}
		
		int [] allVar = new int[m_MDP.varNames.size()];
		int [] primedVar = new int[m_MDP.varNames.size()/2];
		int start = m_MDP.varNames.size()/2;
		
		// construct an array of all variables
		int v1ID = m_MDP.varNames.indexOf("v1");
		int v5ID = m_MDP.varNames.indexOf("v1");
//		int v9ID = m_MDP.varNames.indexOf("v9");

		int vID = 0;
		for ( int i = 0; i < m_MDP.varNames.size(); i++ )
		{
//			if ( i == v1ID || i == v5ID )
//				continue;
			
			allVar[vID] = i+1;
			vID++;
		}

		// construct an array of primed variables
		vID = start;
		for ( int i = start; i < m_MDP.varNames.size(); i++ )
		{
//			if ( i == start+v1ID || i == start + v5ID )
//				continue;
			
			primedVar[vID-start] = i+1;
			vID++;
		}
		
	;
		
		
		DD [] everything = new DD[m_MDP.varNames.size()/2+2]; // last two will be primedValFn and discount

		int everythingID = 0;
		if ( policyEvaluation )
		{
			// variable i
			for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
			{
//				if ( i == v1ID || i == v5ID )
//					continue;
				
				DD [] cptForCurrentVar = new DD[1];
				cptForCurrentVar[0] = ((DD [])(m_MDP.policyActTransitions.get(0)))[i];
				everything[everythingID] = 
					DDnode.myNew(Global.varNames.length, cptForCurrentVar);
				everythingID++;
			}
		}
		else
		{
			// construct a two dimensional array: cpt -- cpt[i] stores a list of cpts of all actions for
			// variable i
			for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
			{
//				if ( i == v1ID || i == v5ID )
//					continue;
				
				DD [] cptsForCurrentVar = new DD[m_MDP.actNames.size()];
				for ( int j = 0; j < m_MDP.actNames.size(); j++ )
				{
					cptsForCurrentVar[j] = ((DD [])(m_MDP.actTransitions.get(j)))[i];
				}
				everything[everythingID] = DDnode.myNew(Global.varNames.length, cptsForCurrentVar);
				everythingID++;
			}
		}
		
		//construct reward add, assuming actions have no costs
		Vector varValNames = (Vector)m_MDP.valNames.get(v5ID);
		DD rewards = m_MDP.reward;
		int [][] v1set = new int[2][2];

//		v1set[0][0] = v1ID+1;
//		v1set[1][0] = varValNames.indexOf(m_V1Values[steps-2])+1;
//		v1set[0][1] = v5ID+1;
//		v1set[1][1] = varValNames.indexOf(m_V1Values[steps-1])+1;
//		DD currentrewards = OP.restrict(rewards, v1set);
//		currentrewards.display();
//		DD valFn = currentrewards;

		int iter = 0;
		DD discount = m_MDP.discount;
		DD valFn = rewards;
		DD currentrewards;
		
		while ( iter < steps )
		{
			System.out.println("Iteration #"+iter);
			DD primedValFn = OP.primeVars(OP.clearConfig(valFn), m_MDP.varNames.size()/2);
			everything[everything.length-2] = primedValFn;
			everything[everything.length-1] = discount;
			
			// change the CPT for variable v5 in each iteration: Pr(v5=m_V1Values[steps-iter-1]) = 1
			// the probabilities are stored in everything[4]
			DD [] children = everything[v1ID].getChildren();
			for ( int i = 0; i < children.length; i++ )
			{
				if ( varValNames.indexOf(m_V1Values[steps-iter-1]) == i )
				{
//					System.out.println(i);
					children[i] = DDleaf.myNew(1.0, children[i].getConfig());
				}
				else
				{
					children[i] = DDleaf.myNew(0.0, children[i].getConfig());
				}
			}
//			everything[v5ID].display();

//			System.out.println("everything[0]:");
//			everything[0].display();
//			System.out.println("everything[1]:");
//			everything[1].display();
			DD qFn = OP.addMultVarElim(everything, primedVar);
			v1set[0][0] = v1ID+1;
			v1set[1][0] = varValNames.indexOf(m_V1Values[steps-iter-1])+1;
//			v1set[0][1] = v5ID+1;
//			v1set[1][1] = varValNames.indexOf(m_V1Values[steps-iter-1])+1;
			currentrewards = OP.restrict(rewards, v1set);
//			currentrewards.display();
			
			qFn = OP.add(qFn, currentrewards);
//			qFn = OP.add(qFn, rewards);
			System.out.println("qFn = ");
			qFn.display();

			int [] tempVars = new int[1];
			tempVars[0] = Global.varNames.length;
			DD newValFn = OP.maxAddVarElim(qFn, tempVars);
			valFn = newValFn;
			OP.reorder(valFn);
			iter++;
		}
		
		return valFn;
	}

	
	//A finite horizon planner -----------Liangrong Dec. 8
	protected DD [] valueIterationFiniteHorizonNew(boolean policyEvaluation, int steps)
	{
		if ( policyEvaluation )
		{
			System.out.println("Evaluating plan ...");
		}
		else
		{
			System.out.println("Computing the optimal plan ...");
		}
		
		int [] allVar = new int[m_MDP.varNames.size()];
		int [] primedVar = new int[m_MDP.varNames.size()/2];
		int start = m_MDP.varNames.size()/2;
		
		
		int vID = 0;
		for ( int i = 0; i < m_MDP.varNames.size(); i++ )
		{
		
			allVar[vID] = i+1;
			vID++;
		}

		// construct an array of primed variables
		vID = start;
		for ( int i = start; i < m_MDP.varNames.size(); i++ )
		{
		
			primedVar[vID-start] = i+1;
			vID++;
		}
		
		
		
		
		DD [] everything = new DD[m_MDP.varNames.size()/2+2]; // last two will be primedValFn and discount

		int everythingID = 0;
		if ( policyEvaluation )
		{
			// variable i
			for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
			{
	
				DD [] cptForCurrentVar = new DD[1];
				cptForCurrentVar[0] = ((DD [])(m_MDP.policyActTransitions.get(0)))[i];
				everything[everythingID] = 
					DDnode.myNew(Global.varNames.length, cptForCurrentVar);
				everythingID++;
			}
		}
		else
		{
			// construct a two dimensional array: cpt -- cpt[i] stores a list of cpts of all actions for
			// variable i
			for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
			{
				DD [] cptsForCurrentVar = new DD[m_MDP.actNames.size()];
				for ( int j = 0; j < m_MDP.actNames.size(); j++ )
				{
					cptsForCurrentVar[j] = ((DD [])(m_MDP.actTransitions.get(j)))[i];
				}
				everything[everythingID] = DDnode.myNew(Global.varNames.length, cptsForCurrentVar);
				everythingID++;
			}
		}
		
		//construct reward add, assuming actions have no costs
		DD rewards = m_MDP.reward;
//		int [][] v1set = new int[2][2];

//		v1set[0][0] = v1ID+1;
//		v1set[1][0] = varValNames.indexOf(m_V1Values[steps-2])+1;
//		v1set[0][1] = v5ID+1;
//		v1set[1][1] = varValNames.indexOf(m_V1Values[steps-1])+1;
//		DD currentrewards = OP.restrict(rewards, v1set);
//		currentrewards.display();
//		DD valFn = currentrewards;

		int iter = steps-1;
		DD discount = m_MDP.discount;
		DD valFn = rewards;
//		DD currentrewards;
		DD [] valFns= new DD[steps] ;
		
		while ( iter >=0 )
		{
			System.out.println("Iteration #"+iter);
			DD primedValFn = OP.primeVars(OP.clearConfig(valFn), m_MDP.varNames.size()/2);
			everything[everything.length-2] = primedValFn;
			everything[everything.length-1] = discount;
			
			// change the CPT for variable v5 in each iteration: Pr(v5=m_V1Values[steps-iter-1]) = 1
			// the probabilities are stored in everything[4]
/*			DD [] children = everything[v1ID].getChildren();
			for ( int j = 0; j < children.length; j++ ){
				DD [] grandChildren = children[j].getChildren();
				for (int i=0;i<children.length;i++){
					if ( varValNames.indexOf(m_V1Values[steps-iter-1]) == i )
					{
						grandChildren[i] = DDleaf.myNew(1.0, grandChildren[i].getConfig());
					}
					else
					{
						grandChildren[i] = DDleaf.myNew(0.0, grandChildren[i].getConfig());
					}
				}
			}
*/
//			everything[v5ID].display();

//			System.out.println("everything[0]:");
//			everything[0].display();
//			System.out.println("everything[1]:");
//			everything[1].display();
			
			DD qFn = OP.addMultVarElim(everything, primedVar);
	//		v1set[0][0] = v1ID+1;
	//		v1set[1][0] = varValNames.indexOf(m_V1Values[steps-iter-1])+1;
//			v1set[0][1] = v5ID+1;
//			v1set[1][1] = varValNames.indexOf(m_V1Values[steps-iter-1])+1;
//			currentrewards = OP.restrict(rewards, v1set);
//			currentrewards.display();
			
//			qFn = OP.add(qFn, currentrewards);
			qFn = OP.add(qFn, rewards);
			System.out.println("qFn = ");
			qFn.display();

			int [] tempVars = new int[1];
			tempVars[0] = Global.varNames.length;
			DD newValFn = OP.maxAddVarElim(qFn, tempVars);
			valFn = newValFn;
			valFns[iter]=newValFn;
			OP.reorder(valFn);
			iter--;
		}
		
		return valFns;
	}
/* planning without v1 and v5
  	protected DD valueIterationFiniteHorizon(boolean policyEvaluation, int steps)
	{
		if ( policyEvaluation )
		{
			System.out.println("Evaluating plan ...");
		}
		else
		{
			System.out.print("Computing the optimal plan ...");
		}
		
		int [] allVar = new int[m_MDP.varNames.size()-2];
		int [] primedVar = new int[m_MDP.varNames.size()/2-2];
		int start = m_MDP.varNames.size()/2;
		
		// construct an array of all variables
		int v1ID = m_MDP.varNames.indexOf("v1");
		int v5ID = m_MDP.varNames.indexOf("v3");

		int vID = 0;
		for ( int i = 0; i < m_MDP.varNames.size(); i++ )
		{
			if ( i == v1ID || i == v5ID )
				continue;
			
			allVar[vID] = i+1;
			vID++;
		}

		// construct an array of primed variables
		vID = start;
		for ( int i = start; i < m_MDP.varNames.size(); i++ )
		{
			if ( i == start+v1ID || i == start + v5ID )
				continue;
			
			primedVar[vID-start] = i+1;
			vID++;
		}
		
		DD [] everything = new DD[m_MDP.varNames.size()/2]; // last two will be primedValFn and discount

		int everythingID = 0;
		if ( policyEvaluation )
		{
			// variable i
			for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
			{
				if ( i == v1ID || i == v5ID )
					continue;
				
				DD [] cptForCurrentVar = new DD[1];
				cptForCurrentVar[0] = ((DD [])(m_MDP.policyActTransitions.get(0)))[i];
				everything[everythingID] = 
					DDnode.myNew(Global.varNames.length, cptForCurrentVar);
				everythingID++;
			}
		}
		else
		{
			// construct a two dimensional array: cpt -- cpt[i] stores a list of cpts of all actions for
			// variable i
			for ( int i = 0; i < m_MDP.varNames.size()/2; i++ )
			{
				if ( i == v1ID || i == v5ID )
					continue;
				
				DD [] cptsForCurrentVar = new DD[m_MDP.actNames.size()];
				for ( int j = 0; j < m_MDP.actNames.size(); j++ )
				{
					cptsForCurrentVar[j] = ((DD [])(m_MDP.actTransitions.get(j)))[i];
				}
				everything[everythingID] = DDnode.myNew(Global.varNames.length, cptsForCurrentVar);
				everythingID++;
			}
		}
		
		//construct reward add, assuming actions have no costs
		Vector varValNames = (Vector)m_MDP.valNames.get(v5ID);
		DD rewards = m_MDP.reward;
		int [][] v1set = new int[2][2];

//		v1set[0][0] = v1ID+1;
//		v1set[1][0] = varValNames.indexOf(m_V1Values[steps-2])+1;
//		v1set[0][1] = v5ID+1;
//		v1set[1][1] = varValNames.indexOf(m_V1Values[steps-1])+1;
//		DD currentrewards = OP.restrict(rewards, v1set);
//		currentrewards.display();
//		DD valFn = currentrewards;

		int iter = 0;
		DD discount = m_MDP.discount;
		DD valFn = DD.one;
		DD currentrewards;
		
		while ( iter < steps - 1 )
		{
			
			DD primedValFn = OP.primeVars(OP.clearConfig(valFn), m_MDP.varNames.size()/2);
			everything[everything.length-2] = primedValFn;
			everything[everything.length-1] = discount;
			
			// change the CPT for variable v5 in each iteration: Pr(v5=m_V1Values[steps-iter-1]) = 1
			// the probabilities are stored in everything[4]
//			DD [] children = everything[v5ID].getChildren();
//			for ( int i = 0; i < children.length; i++ )
//			{
//				if ( varValNames.indexOf(m_V1Values[steps-iter-1]) == i )
//				{
//					System.out.println(i);
//					children[i] = DDleaf.myNew(1.0, children[i].getConfig());
//				}
//				else
//				{
//					children[i] = DDleaf.myNew(0.0, children[i].getConfig());
//				}
//			}
//			everything[v5ID].display();

			DD qFn = OP.addMultVarElim(everything, primedVar);
			qFn.display();
			v1set[0][0] = v1ID+1;
			v1set[1][0] = varValNames.indexOf(m_V1Values[steps-iter-2])+1;
			v1set[0][1] = v5ID+1;
			v1set[1][1] = varValNames.indexOf(m_V1Values[steps-iter-1])+1;
			currentrewards = OP.restrict(rewards, v1set);
			currentrewards.display();
			qFn = OP.add(qFn, currentrewards);

			int [] tempVars = new int[1];
			tempVars[0] = Global.varNames.length;
			DD newValFn = OP.maxAddVarElim(qFn, tempVars);
			valFn = newValFn;
			iter++;
		}
		
		return valFn;
	}
*/
	public DD buildPolicy(DD valFn)
	{	
		DD[] children = valFn.getChildren();
		if ( children == null ) // leaf node
		{
			int [][] config = ((DDleaf)valFn).getConfig();
			if ( config == null )
			{
				//System.out.println("Error: cannot parse policy");
				//return DDnode.one;
				return DDnode.zero;
			}
		for ( int i = 0; i < config[0].length; i++ )
				//for ( int i = config[0].length-1; i >=0; i-- )
			{
				
				String action = Global.valNames[config[0][i]-1][config[1][i]-1];
		
				
				int actionID=m_MDP.actNames.indexOf(action)+1;
				return DDleaf.myNew(actionID, config);
				
			}
		}
		DD[] newchildren = new DD[children.length];
		for ( int i = 0; i < children.length; i++ )
		{
			newchildren[i] = buildPolicy(children[i]);
		}
		return DDnode.myNew(valFn.getVar(), newchildren);
	}
	
	
	public void run(String filename, int testtype, int steps)
	{
		long startSystemTimeNano = getSystemTime( );
		long startUserTimeNano   = getUserTime( );
		long startCpuTime=getCpuTime();
		m_MDP = new ParseSPUDD(filename);
		m_MDP.parsePOMDP(true);
	if (testtype==1){
	//combine actions	
		int[][] comActions;
		String[][] actions;
		ActionSet act=new ActionSet();
		actions=act.ActionSets("result.txt");
		//combine simultaneous actions-----------added by Liangrong 2007.9.10
		//comActions=new int[1004][3];
		comActions=new int[40][2];
		for (int i=1;i<actions.length;i++){
		comActions[i][0]=m_MDP.actNames.indexOf(actions[i][1]);
		comActions[i][1]=m_MDP.actNames.indexOf(actions[i][2]);
		//comActions[i][2]=m_MDP.actNames.indexOf(actions[i][3]);
		m_MDP.combine(actions[i][0],comActions[i]);
	}
	
	}
		
		m_valueFn = valueIteration(m_MDP.isPlanEvaluation(),500);
		
		m_policy = buildPolicy(m_valueFn);
	
		long taskUserTimeNano    = getUserTime( ) - startUserTimeNano;
		long taskSystemTimeNano  = getSystemTime( ) - startSystemTimeNano;
		long taskCpuTimeNano  = getCpuTime( ) - startCpuTime;
		
		System.out.println("time"+taskCpuTimeNano);
		
		int [][] initialCofig=m_MDP.initialConfig;
		
	
		//simulation
	

		int i;
		
		if (testtype==0)
		{
			
				double reward=0;
				double total=0;
				
				//System.out.println(j);
		
				for (i=0;i<500;i++){
					//System.out.println(i);
					m_MDP.initialConfig=initialCofig;
									//m_policy.display();
					reward=simulate(steps);
					System.out.println(reward);
				
				//	total=total+reward;
				
				
					//System.out.println("steps needed"+simulateGD());
					//m_MDP.initial.display();
				}
			//compute average reward
			reward=total/i;
		
		
			System.out.println("average="+reward);
		
			
		
		}
	if (testtype==1)
	{
		int step=0;
		int totalstep=0;
		for (i=0;i<1;i++){
		//System.out.println(i);
			m_MDP.initialConfig=initialCofig;
			//reward=simulate(j);
			//System.out.println(reward);
			
			//total=total+reward;
			
			step=simulateGD();
			totalstep=totalstep+step;
			System.out.println("steps needed"+step);
			//m_MDP.initial.display();
		}
		step=totalstep/i;
		System.out.println("average="+step);
	}
	
}

	public void take (int actionID)
	{ 
		DD [] actTrans = (DD[])(m_MDP.actTransitions.get((int)actionID));
		int [][] s=new int[2][m_MDP.varNames.size()/3];
		
		double [] leaves;
		 Random generator = new Random();
		 //System.out.print(generator);
		 
		 double rand =generator.nextDouble();
		 
		for ( int j = 0; j < m_MDP.varNames.size()/3; j++ )
		{
			//System.out.println(m_MDP.initialConfig.toString());
			leaves = OP.enumerateLeaves(OP.restrict(actTrans[j],m_MDP.initialConfig));
			double t[]=new double[leaves.length];
			t[0] = leaves[0];
			for (int m = 1;m <leaves.length;m++)
			{
				t[m]=t[m-1] + leaves[m];
			}
			
			
			 int newvalue=0;
			 for (int i=0;i<leaves.length;i++)
			 {
				 if (rand<=t[i]) 
				{
					 	newvalue=i;
					 	break;
				}
			 }
			 
			 s[0][j]=j+1;
			 s[1][j]=newvalue+1;
		
			}
		m_MDP.initialConfig=s;
		
		m_MDP.initial=Config.convert2dd(s);
	

	}

	public double simulate(int step)
	{	
		int i=0;
		//m_MDP.initial=Config.convert2dd(m_MDP.initialConfig);
		//m_MDP.initial.display();
	//	double expectedReward=OP.eval(m_MDP.reward, m_MDP.initialConfig);

		double expectedReward=0;
	
		for (i=0;i<step;i++){
		
	
			
			
			int [][] config = ((DDleaf)OP.restrict(m_policy,m_MDP.initialConfig)).getConfig();
	
			//System.out.println("action="+Global.valNames[config[0][0]-1][config[1][0]-1]);
			int actionID=m_MDP.actNames.indexOf(Global.valNames[config[0][0]-1][config[1][0]-1]);
			//System.out.println(actionID);
			take(actionID);
			double temp=OP.eval(m_MDP.reward, m_MDP.initialConfig);
			//System.out.println(temp);
			expectedReward=expectedReward+Math.pow(m_MDP.discount.getVal() ,i)*temp;
			//System.out.println(expectedReward);
			
			
		}
		return expectedReward;
	
}
	//simulate goal-directed planning
	//return number of steps needed to reach the goal
	//added by Liangrong  Jan.24 2008
	public int simulateGD()
	{	
		int i=0;
		boolean stop =false;
		while(!stop){
			//System.out.println("i="+i);
			i++;
			int [][] config = ((DDleaf)OP.restrict(m_policy,m_MDP.initialConfig)).getConfig();
			int actionID=m_MDP.actNames.indexOf(Global.valNames[config[0][0]-1][config[1][0]-1]);
			System.out.println("action="+actionID);
			take(actionID);
			//decide whether the goal is reached
			if (i==20) stop=true;
			if (OP.eval(m_MDP.reward, m_MDP.initialConfig)>0) stop=true;
		}
		return i;
	}
	public void music(String filename)
	{
		m_MDP = new ParseSPUDD(filename);
		m_MDP.parsePOMDP(true);
		int [][] s=new int[2][9];

		m_V1Values[0] = "C";
		m_V1Values[1] = "E";
		m_V1Values[2] = "e";
     	m_V1Values[3] = "f";
     	m_V1Values[4] = "A";
		m_V1Values[5] = "A";
		m_V1Values[6] = "G";
		m_V1Values[7] = "G";
		m_V1Values[8] = "F";
//		m_V1Values[9] = "F";
//		m_V1Values[10] = "E";
//		m_V1Values[11] = "E";
//		m_V1Values[12] = "D";
//		m_V1Values[13] = "D";
//		m_V1Values[14] = "C";
//		m_V1Values[15] = "C";
		
		DD []	valueFn = valueIterationFiniteHorizonNew(m_MDP.isPlanEvaluation(), 8);
		DD[]	policy = buildFinitePolicy(valueFn);

		for ( int i = 0; i < 9; i++ )
		{
			s[0][i]=i+1;
		}
		Vector varValNames = (Vector)m_MDP.valNames.get(1);
		s[1][0]=varValNames.indexOf(m_V1Values[0])+1; 		
		s[1][1]=7;
		s[1][2]=5 ;
		s[1][3]= 3;
		s[1][4]=varValNames.indexOf(m_V1Values[1])+1;
		s[1][5]=7 ;
		s[1][6]=5 ;
		s[1][7]=3 ;
		s[1][8]=varValNames.indexOf(m_V1Values[2])+1;
		double [] leaves;
		for ( int i = 2; i <8; i++ )
		{
			    double actionID =OP.eval(policy[i],s);
			    System.out.println(actionID);
				DD [] actTrans = (DD[])(m_MDP.actTransitions.get((int)actionID-1));
				int [] news = new int[3];
				for ( int k = 5; k <= 7; k++)
				{
					leaves = OP.enumerateLeaves(OP.restrict(actTrans[k],s));
					//System.out.println("leaves length = "+leaves.length);
					double t[]=new double[15];
					
					t[0] = leaves[0];
					for (int m = 1;m <leaves.length;m++)
					{
						t[m]=t[m-1] + leaves[m];
					}
					 Random generator = new Random();
					 int newvalue=0;
					 double rand =generator.nextDouble();
					 for (int j=0;j<leaves.length;j++)
					 {
						 if (rand<=t[j]) 
						{
							 	newvalue=j;
							 	break;
						}
					 }
					 news[k-5]=newvalue+1;
					// System.out.println(varValNames.get(newvalue));
					 
					// varValnames.get(newvalue);
						 
				}
				s[1][0]=s[1][4];
				s[1][1]=s[1][5];
				s[1][2]=s[1][6];
				s[1][3]=s[1][7];
				s[1][4]=s[1][8];
				s[1][5]=news[0];
				s[1][6]=news[1];
				s[1][7]=news[2];
				if (i!=7)
				{
					s[1][8]=varValNames.indexOf(m_V1Values[i+1])+1;
				}
				for (int j=0;j<=8;j++)
				{
					if ( i==7 && j==8 )
						break;
					System.out.println(m_MDP.varNames.get(j) + " = " + varValNames.get(s[1][j]-1));
				}
				System.out.println("eee");
			}
		
	}
	

	public void musicgen(String filename)
	{
		m_MDP = new ParseSPUDD(filename);
		m_MDP.parsePOMDP(true);

		m_V1Values[0] = "C";
		m_V1Values[1] = "E";
		m_V1Values[2] = "g";
     	m_V1Values[3] = "e";
    			m_V1Values[4] = "A";
    			m_V1Values[5] = "A";
    			m_V1Values[6] = "G";
    			m_V1Values[7] = "G";
    		m_V1Values[8] = "F";
    			m_V1Values[9] = "F";
    			m_V1Values[10] = "E";
    			m_V1Values[11] = "E";
    			m_V1Values[12] = "D";
    			m_V1Values[13] = "D";
    			m_V1Values[14] = "C";
    			m_V1Values[15] = "C";

//		m_V1Values[0] = "D";
//		m_V1Values[1] = "F";
//		m_V1Values[2] = "A";
//		m_V1Values[3] = "G";
//		m_V1Values[4] = "B";
//		m_V1Values[5] = "A";
//		m_V1Values[6] = "E";
//		m_V1Values[7] = "G";
		
	DD []	valueFn = valueIterationFiniteHorizonNew(m_MDP.isPlanEvaluation(), 8);
	DD[]	policy = buildFinitePolicy(valueFn);
	}


	public void run()
	{
		m_valueFn = valueIteration(m_MDP.isPlanEvaluation(),0);		
	}	

	public DD getValueFn() {
		return m_valueFn;
	}

	public DD getPolicy() {
		return m_policy;
	}
	
	public void updateReward(String varName, String varValue, double deltaReward)
	{
		DD currentRewards = m_MDP.reward;
		System.out.println("current rewards:");
		currentRewards.display();
		
		int varId = m_MDP.varNames.indexOf(varName);
		System.out.println("varid = " + varId + "; var = " + varName);
		if (varId == -1) System.out.println("Not an existing dd nor an existing variable");
		
		Vector varValNames = (Vector)m_MDP.valNames.get(varId);
		System.out.println("valsize = " + varValNames.size());
		DD[] children = new DD[varValNames.size()];
		for (int i = 0; i < children.length; i++) 
		{
				children[i] = DD.zero;
		}
		
		int valId = varValNames.indexOf(varValue);
		System.out.println("valid = " + valId + "; val = " + varValue);
		children[valId] = DDleaf.myNew(deltaReward);
		
		DD updaterADD = DDnode.myNew(varId+1,children);		
		System.out.println("updater ADD:");
		updaterADD.display();
		
		currentRewards = OP.add(currentRewards, updaterADD);

		System.out.println("updated rewards:");
		currentRewards.display();
		
		m_MDP.reward = currentRewards;
	}
	
	public int localSearchPlanner(String filename,int maxIter,int maxIteration,int limit)
	{
	
		m_MDP = new ParseSPUDD(filename);
		m_MDP.parsePOMDP(true);
		
		// TO DO: implement the local search planner here
		// m_MDP.changePolicy(mask, action);

		int [] allVar = new int[m_MDP.varNames.size()];
		// construct an array of all variables
		
		int num=0;
		
		for ( int i = 0; i < m_MDP.varNames.size(); i++ )
		{
			allVar[i] = i+1;
		}

		//The maximum number of iterations 
	//	maxiteration=Math.pow(2,m_MDP.varNames.size()/2)-1;
	//	maxiteration=16;
		
		DD oldValueFn = valueIteration(true,maxIter);
		DD newValueFn;
		DD bestValueFn = oldValueFn;
//		oldValueFn.display() ;
		int i = 0;
		int j=0;
		do
		{
//			System.out.println("i="+i);
//			System.out.println("value function:");
//			oldValueFn.display();
			m_MDP.savePolicyCore();
			m_MDP.changePolicy(limit);
			
			newValueFn = valueIteration(true,maxIter);
//			newValueFn.display();
			DD diff = OP.sub(newValueFn, oldValueFn);

		//	System.out.println("min diff = "+OP.minAll(diff)+";   max diff = "+OP.maxAll(diff));
			double minDiff = OP.minAll(diff);
			double maxDiff = OP.maxAll(diff);
/*			if ( minDiff > 0 || maxDiff > 0 )
			{
				System.out.println("    continue");
				oldValueFn = newValueFn;				
				if ( OP.minAll(OP.sub(newValueFn, bestValueFn)) >= 0 &&
					 OP.maxAll(OP.sub(newValueFn, bestValueFn)) > 0 )
				{
					bestValueFn = newValueFn;
				}
				i++;
				if ( i >= 100)
					break;
			}
			else
			{
				System.out.println("    restore");
				m_MDP.restoreCore();								
			}
*/			if ( minDiff > 0 || (minDiff == 0 && maxDiff > 0) )
			{
				j=0;
//				System.out.println("    continue");
				oldValueFn = newValueFn;
				if ( OP.minAll(OP.sub(newValueFn, bestValueFn)) >= 0 &&
					 OP.maxAll(OP.sub(newValueFn, bestValueFn)) > 0 )
				{
		//			System.out.println("update bestValueFn");
					bestValueFn = newValueFn;
					
				}
				
			}
			else if ( minDiff == 0 && maxDiff == 0 )
			{	
				j++;
				if ( Math.random() >= 0.5 )
				{
	//				System.out.println("    continue");
					oldValueFn = newValueFn;
					if ( OP.minAll(OP.sub(newValueFn, bestValueFn)) >= 0 &&
							 OP.maxAll(OP.sub(newValueFn, bestValueFn)) > 0 )
					{
		//				System.out.println("update bestValueFn");
						bestValueFn = newValueFn;
					}

					 if ( j >= maxIteration)
						break;
				}
				else
				{
	//				System.out.println("    restore");
					m_MDP.restoreCore();	
					 if ( j >= maxIteration)
							break;
				}				
			}
			else if ( minDiff < 0 && maxDiff > 0 )
			{	
				j++;
				if ( Math.random() >= 0.9 )
				{
	//				System.out.println("    continue");
					oldValueFn = newValueFn;
					if ( OP.minAll(OP.sub(newValueFn, bestValueFn)) >= 0 &&
							 OP.maxAll(OP.sub(newValueFn, bestValueFn)) > 0 )
					{
						System.out.println("update bestValueFn");
						bestValueFn = newValueFn;
					}
		/*			i++;
					if ( i >= max)
						break;*/
					 if ( j >= maxIteration)
							break;
				}
				else
				{
	//				System.out.println("    restore");
					m_MDP.restoreCore();	
					 if ( j >= maxIteration)
							break;
				}				
			}
			else
			{
				j++;
	//			System.out.println("    restore");
				m_MDP.restoreCore();	
				 if ( j >= maxIteration)
						break;
			}
		i++;
		}while (true);
		
		m_valueFn = bestValueFn;
//		System.out.println("total nujmber of iterations="+i);
		num=i;
				
		return num;
	//	m_policy = buildPolicy(m_valueFn);
//		m_valueFn.display();
	}
	
//	build optimal policy for finite horizon MDPs --------Liangrong Dec. 8
	public  DD [] buildFinitePolicy(DD [] valFns)
	{	
		for (int i=0;i<valFns.length;i++){
				valFns[i] = buildPolicy(valFns[i]);
		}
		return valFns;
	}
	
}
