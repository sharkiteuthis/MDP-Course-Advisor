
package uky.itr.POLE;
class MyDoubleArray {

		public double[] doubleArray;

		public MyDoubleArray(double[] doubleArray) {
				this.doubleArray = doubleArray;
		}
}
