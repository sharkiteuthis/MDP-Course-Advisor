package uky.itr.POLE;
import java.util.*;
import java.lang.ref.*;
import java.io.*;

class DDleaf extends DD {
		private double val;
		private int[][] config;
		//added by YLR
		private boolean leafCountFlag;
		
		private DDleaf(double val) {
				this.val = val;
				this.var = 0;
				this.config = null;
				this.leafCountFlag = false;
		}

		private DDleaf(double val, int[][] config) {
				this.val = val;
				this.var = 0;
				this.config = config;
		}

		public static DD myNew(double val) {

				// create new leaf
				DDleaf leaf = new DDleaf(val);

				// try to lookup leaf in leafHashtable 
				WeakReference storedLeaf = (WeakReference)Global.leafHashtable.get(leaf); 
				if (storedLeaf != null) return (DDleaf)storedLeaf.get();

				// store leaf in leafHashtable
				Global.leafHashtable.put(leaf,new WeakReference(leaf));
				return leaf;
		}

		public static DD myNew(double val, int[][] config) {

				// create new leaf
				DDleaf leaf = new DDleaf(val,config);

				// try to lookup leaf in leafHashtable
				WeakReference storedLeaf = (WeakReference)Global.leafHashtable.get(leaf);
				if (storedLeaf != null) return (DDleaf)storedLeaf.get();

				// store leaf in leafHashtable
				Global.leafHashtable.put(leaf,new WeakReference(leaf));
				return leaf;
		}

    //public SortedSet getScope() {
		//		return new TreeSet();
		//}

    public int[] getVarSet() {
				return new int[0];
		}

		public double getVal() {
				return val;
		}

		public int[][] getConfig() {
				return config;
		}

		public int getNumLeaves() {
				return 1;
		}
		
		public int getNumTrueLeaves() {
			if (val==1)
			return 1;
			else return 0;
	}
		public int getDDLeafN() {
			if ( leafCountFlag )
				return 0;
			else
			{
				leafCountFlag = true;
				return 1;
			}
		}
		
		public void clearLeafCountFlag() {
			leafCountFlag = false;
		}
		
		public boolean equals(Object obj) {

				if (obj.getClass() != getClass()) return false;
				DDleaf leaf = (DDleaf)obj;

				if (val == leaf.val && Config.equals(config,leaf.config))
						return true;
				else return false;
		}

		public int hashCode() {
				Double valD = new Double(val);
				return valD.hashCode() + Config.hashCode(config);
		}

		public DD store() {
				return DDleaf.myNew(val,config);
		}

		public void display(String space) {
				System.out.println(space + "leaf: " + Double.toString(val) + "  " 
													 + Config.toString(config));
		}

		public void display(String space, String prefix) {
				System.out.println(space + prefix + Double.toString(val) + "  " 
													 + Config.toString(config));
		}
    public void printSpuddDD(PrintStream ps) {
	ps.print("(" + Double.toString(val) + ")");
    }
}
