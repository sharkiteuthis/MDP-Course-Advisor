package planIt.gui;


import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Enumeration;

import javax.swing.ButtonGroup;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.tree.DefaultMutableTreeNode;

import planIt.comm.XmlSrvConnector;
import planIt.data.Globals;
import planIt.parsers.ADDParser;
import planIt.parsers.ActionParser;
import planIt.parsers.ArchetypeParser;
import planIt.parsers.AttributeParser;
import planIt.parsers.PlanParser;
import planIt.parsers.StateParser;
import planIt.planScan.data.Plan;
import planIt.planScan.gui.PlanPanel;
import planIt.poet.data.Archetype;
import planIt.poet.data.PrefNode;
import planIt.poet.data.UtilityNode;
import planIt.poet.gui.ButtonBar;
import planIt.poet.gui.ElicitationPane;
import planIt.poet.gui.PickArch;
import planIt.utils.ChanceComparator;
import planIt.utils.Logger;
import planIt.utils.UtilityComparator;
import planIt.utils.XMLFilter;


public class ToolBar extends JMenuBar implements ActionListener, ChangeListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private JMenu menu1 = new JMenu("File"), menu2 = new JMenu("View"), menu3 = new JMenu("Help");
	private JMenuItem menuItem1 = new JMenuItem("Save Domain (SPUDD)"), menuItem2 = new JMenuItem("Save Preferences"),
			menuItem3 = new JMenuItem("Save Current Plan"), menuItem4 = new JMenuItem("Load All"),
			menuItem5 = new JMenuItem("Load Preferences"), menuItem6 = new JMenuItem("Load Plan"),
			menuItem7 = new JMenuItem("Exit"), menuItem8 = new JMenuItem("Refresh"),
			menuItem9 = new JMenuItem("Help"), menuItem10 = new JMenuItem("About...");
			// menuItem11 = new JMenuItem("Open Project");

	private StartPane	startPane;

	private AttributeParser	attrParser;
	private ActionParser	actionParser;
	private ArchetypeParser	archParser;
	private ADDParser 		addParser;
	private StateParser 	stateParser;
	//private XmlSrvConnector XmlSrvConnection;

	private ButtonGroup		views;
	JRadioButtonMenuItem 	prefOrder;
	JRadioButtonMenuItem	probOrder;

	public ToolBar() // BUILD THE MENU BAR AND SETS UP MAIN WINDOW
	{
		views = new ButtonGroup();

		prefOrder = new JRadioButtonMenuItem("Order by preference");
		prefOrder.setSelected(true);
		// rbMenuItem.setMnemonic(KeyEvent.VK_R);
		views.add(prefOrder);

		probOrder = new JRadioButtonMenuItem("Order by probability");
		// rbMenuItem.setMnemonic(KeyEvent.VK_O);
		views.add(probOrder);

		Globals.tabs.addChangeListener(this);

		// Add action listeners to all menu items
		menuItem1.addActionListener(this);
		menuItem2.addActionListener(this);
		menuItem3.addActionListener(this);
		menuItem4.addActionListener(this);
		menuItem5.addActionListener(this);
		menuItem6.addActionListener(this);
		menuItem7.addActionListener(this);
		menuItem8.addActionListener(this);
		menuItem9.addActionListener(this);
		menuItem10.addActionListener(this);
		//menuItem11.addActionListener(this);
		probOrder.addActionListener(this);
		prefOrder.addActionListener(this);

		// Construct the first drop down menu
		//menu1.add(menuItem11);
		//menu1.addSeparator();
		menu1.add(menuItem2);
		menu1.add(menuItem3);
		menu1.add(menuItem1);
		menu1.addSeparator();
		// menu1.add(menuItem4);
		menu1.add(menuItem5);
		menu1.add(menuItem6);
		menu1.addSeparator();
		menu1.add(menuItem7);

		// Construct the second drop down menu
		menu2.add(prefOrder);
		menu2.add(probOrder);

		// Construct the third drop down menu
		menu3.add(menuItem9);
		menu3.add(menuItem10);

		// Add the consctucted drop down menus to the toolbar
		add(menu1);
		add(menu2);
		add(menu3);
	}

	/**
	 * Handles all action events on the menu items.
	 * @param e A action event on the menu bar.
	 */
	public void actionPerformed(ActionEvent e)
	{
		Object source = e.getSource();

		/* if (source == menuItem11)
		{
			String oldProject = Globals.project;
			new ProjectManager();
			
			if (!oldProject.equals(Globals.project)) {
				
				Globals.tabs.removeAll();
				
				// Call file parsers to initialize data
				// These need to be consolidated now that they are all in the same file
				attrParser = new AttributeParser(Globals.file);
				Globals.attributes = attrParser.parse();
		
				actionParser = new ActionParser(Globals.file);
				Globals.actions = actionParser.parse();
		
				archParser = new ArchetypeParser(Globals.file);
				Globals.archetypes = archParser.parse();
		
				addParser = new ADDParser(Globals.file);
				Globals.add = addParser.parse();
		
				stateParser = new StateParser(Globals.file);
				Globals.startState = stateParser.parse();
		
				Globals.planCount = 0;
				Globals.prefIndex = -1;

				// Construct and add GUI objects to the frame
				startPane = new StartPane();
				Globals.tabs.addTab("Start", startPane);
				Globals.tabs.setCloseIconVisibleAt(0, false);			
			}
		}
		else */ 
		if (source == menuItem1)
		{
			JFileChooser fc = new JFileChooser(Globals.codeBase.getPath().replace("%20", " ") + "XML");
			File file = null;
			FileWriter out = null;

			fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

			int val = fc.showSaveDialog(Globals.tabs);

			if (val == JFileChooser.APPROVE_OPTION)
			{
				try
				{
					file = fc.getSelectedFile();
					out = new FileWriter(file, false);
					out.write(Globals.add.toSPUDD());
					out.close();
					Logger.log_data("Menu action (Save Domain (SSPUD))");
				}

				catch (IOException ex)
				{
					System.err.println("Error saving SPUDD formatted domain file");
				}
			}
		}

		/* Save preferences */
		else if (source == menuItem2)
		{
			JFileChooser fc = new JFileChooser(Globals.codeBase.getPath().replace("%20", " ") + "XML");
			File file = null;
			FileWriter out = null;

			if (Globals.prefIndex < 1 || Globals.prefs == null)
			{
				System.err.println("No preferences found");
				return;
			}

			fc.setFileFilter(new XMLFilter());
			fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

			int val = fc.showSaveDialog(Globals.tabs);

			if (val == JFileChooser.APPROVE_OPTION)
			{
				try
				{
					file = fc.getSelectedFile();
					out = new FileWriter(file, false);
					out.write(prefsToXML());
					out.close();
					Logger.log_data("Menu action (Save Preferences)");
				}

				catch (IOException ex)
				{
					System.err.println("Error saving file");
				}
			}
		}

		/* Save current plan */
		else if (source == menuItem3)
		{
			int index = Globals.tabs.getSelectedIndex();
			Plan plan = null;
			JFileChooser fc = new JFileChooser(Globals.codeBase.getPath().replace("%20", " ") + "XML");
			File file = null;
			FileWriter out = null;

			if (index == 0 || index == Globals.prefIndex)
			{
				System.err.println("No plan currently selected to save");
				return;
			}

			plan = ((PlanPanel) Globals.tabs.getSelectedComponent()).getPlan();

			fc.setFileFilter(new XMLFilter());
			fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

			int val = fc.showSaveDialog(Globals.tabs);

			if (val == JFileChooser.APPROVE_OPTION)
			{
				try
				{
					file = fc.getSelectedFile();
					out = new FileWriter(file, false);
					out.write(plan.printXML());
					out.close();
					Logger.log_data("Menu action (Save Current Plan)");
				}

				catch (IOException ex)
				{
					System.err.println("Error saving file");
				}
			}
		}

		else if (source == menuItem4)
		{}

		/* Load preferences */
		else if (source == menuItem5)
		{
			JFileChooser fc = new JFileChooser(Globals.codeBase.getPath().replace("%20", " ") + "XML");
			DefaultMutableTreeNode[] nodes = null;

			fc.setFileFilter(new XMLFilter());
			fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

			int val = fc.showOpenDialog(Globals.tabs);

			if (val == JFileChooser.APPROVE_OPTION)
			{
				File file = fc.getSelectedFile();

				ArchetypeParser parser = new ArchetypeParser(file.getPath());

				nodes = parser.parse();

				if (nodes == null || nodes.length < 1)
				{
					System.err.println("Error parsing preference file");
					return;
				}

				Globals.prefs = nodes[0];
				PickArch panel = new PickArch();

				panel.removeAll();
				panel.setLayout(new BorderLayout());
				panel.add(new ElicitationPane(Globals.prefs), BorderLayout.CENTER);
				panel.add(new ButtonBar(panel), BorderLayout.PAGE_END);

				if (Globals.prefIndex < 0)
				{
					Globals.tabs.addTab("Preferences", panel);
					Globals.prefIndex = Globals.tabs.getTabCount() - 1;
					Globals.tabs.setSelectedIndex(Globals.tabs.getTabCount() - 1);
				}

				else
				{
					Component c = Globals.tabs.getComponentAt(Globals.prefIndex);
					PickArch temp = (PickArch) c;

					temp.removeAll();
					temp.add(panel);
					Globals.tabs.setSelectedIndex(Globals.tabs.getTabCount() - 1);
				}
				Logger.log_data("Menu action (Load Preferences)");
			}
		}

		/* Load a plan */
		else if (source == menuItem6)
		{
			JFileChooser fc = new JFileChooser(Globals.codeBase.getPath().replace("%20", " ") + "XML");
			Plan plan = null;

			fc.setFileFilter(new XMLFilter());
			fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

			int val = fc.showOpenDialog(Globals.tabs);

			if (val == JFileChooser.APPROVE_OPTION)
			{
				File file = fc.getSelectedFile();

				PlanParser planParser = new PlanParser(file.getPath());

				plan = planParser.parse();

				if (plan == null)
				{
					System.err.println("Error loading plan from file");
					return;
				}

				Globals.tabs.addTab("Plan " + (++Globals.planCount), new PlanPanel(plan));
				Globals.tabs.setSelectedIndex(Globals.tabs.getTabCount() - 1);
				Logger.log_data("Menu action (Load Plan)");
			}
		}

		else if (source == menuItem7)
		{
			Globals.frame.dispose();
			Logger.log_data("Menu action (Exit)");
		}

		else if (source == menuItem8)
		{}

		/* Help */
		else if (source == menuItem9)
		{
			new HelpFrame();
			Logger.log_data("Menu action (Help)");
		}

		else if (source == menuItem10)
		{}

		else if (source == prefOrder)
		{
			Globals.stateComparator = new UtilityComparator();

			for (int i = 1; i < Globals.tabs.getTabCount(); i++)
			{
				if (i != Globals.prefIndex)
				{
					PlanPanel p = (PlanPanel) Globals.tabs.getComponentAt(i);

					p.updateShapes();
					Logger.log_data("Menu action (Reorder based on Preference)");
				}
			}
		}

		else if (source == probOrder)
		{
			Globals.stateComparator = new ChanceComparator();

			for (int i = 1; i < Globals.tabs.getTabCount(); i++)
			{
				if (i != Globals.prefIndex)
				{
					PlanPanel p = (PlanPanel) Globals.tabs.getComponentAt(i);

					p.updateShapes();
					Logger.log_data("Menu action (Reorder based on Probability)");
				}
			}
		}
	}

	/**
	 * Change listener for the tabbed pane.  If a plan tab is selected, then
	 * the save plan menu option is enabled.  Otherwise, it is disabled.
	 * @param e The change event.
	 */
	public void stateChanged(ChangeEvent e)
	{
		if (e.getSource() == Globals.tabs)
		{
			int index = Globals.tabs.getSelectedIndex();

			if (index == 0 || index == Globals.prefIndex)
			{
				menuItem3.setEnabled(false);
			}

			else
			{
				menuItem3.setEnabled(true);
			}

			revalidate();
		}
	}

	private String prefsToXML()
	{
		String out = ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");

		out += "<prefs>\n";
		out += prefNodeToXML(Globals.prefs, "\t");
		out += "</prefs>\n";

		return out;
	}

	private String prefNodeToXML(DefaultMutableTreeNode node, String tab)
	{
		Object object = node.getUserObject();
		String out = "";

		if (object instanceof Archetype)
		{
			Archetype arch = (Archetype) object;

			out += tab + "<name>" + arch.getName() + "</name>\n";
			out += tab + "<description>" + arch.getDescription() + "</description>\n";

			for (Enumeration e = node.children(); e.hasMoreElements();)
			{
				out += prefNodeToXML((DefaultMutableTreeNode) e.nextElement(), tab + "\t");
			}
		}

		else if (object instanceof PrefNode)
		{
			PrefNode pNode = (PrefNode) object;

			out += tab + "<attribute>\n";
			out += tab + "\t" + "<name>" + pNode.attribute.getName();
			out += "</name>\n";

			if (object instanceof UtilityNode)
			{
				UtilityNode uNode = (UtilityNode) object;

				out += tab + "<preference>\n";
				out += tab + "\t" + "<value>" + uNode.value.getName();
				out += "</value>\n" + tab + "\t" + "<utility>";
				out += uNode.getUtility() + "</utility>\n";
				out += tab + "</preference>\n";
			}

			else
			{
				for (Enumeration e = node.children(); e.hasMoreElements();)
				{
					DefaultMutableTreeNode child = (DefaultMutableTreeNode) e.nextElement();

					out += tab + "\t" + "<edge>";
					out += tab + "\t" + "<value>" + pNode.value.getName() + "</value>\n";
					out += prefNodeToXML(child, tab + "\t");
					out += tab + "\t" + "</edge>";
				}
			}

			out += tab + "</attribute>\n";
		}

		return out;
	}
}

