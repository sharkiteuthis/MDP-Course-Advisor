package planIt.gui;


// Java packages
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JFileChooser;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import planIt.data.Globals;
import planIt.parsers.PlanParser;
import planIt.planScan.data.Plan;
import planIt.planScan.gui.PlanPanel;
import planIt.poet.gui.PickArch;
import planIt.utils.Logger;
import planIt.utils.XMLFilter;


public class StartPane extends JPanel implements ActionListener, HyperlinkListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	JEditorPane tutorialPane;
	JScrollPane	scrollPane;
	JPanel		buttonPanel;
	JPanel		bottomPanel;
	JButton		tutorialButton;
	JButton		prefButton;
	JButton		planButton;
	JLabel		startLabel;

	public StartPane()
	{
		// Instantiate the editor pane, button panel, and buttons
		tutorialPane = new JEditorPane();
		buttonPanel = new JPanel();
		bottomPanel = new JPanel();

		tutorialButton = new JButton("Tutorial Index");
		tutorialButton.setFont(Globals.mediumBoldFont);
		prefButton = new JButton("Begin Preference Elicitation");
		prefButton.setFont(Globals.mediumBoldFont);
		planButton = new JButton("Load A Plan");
		planButton.setFont(Globals.mediumBoldFont);
		startLabel = new JLabel("Welcome to PlanIt");
		startLabel.setFont(Globals.largeBoldFont);

		// Add action listeners on the buttons
		tutorialButton.addActionListener(this);
		prefButton.addActionListener(this);
		planButton.addActionListener(this);

		// Center the label both within the label space and it its parent component
		startLabel.setHorizontalAlignment(JLabel.CENTER);
		startLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

		// Try to display the html page in the editor pane
		try
		{
			tutorialPane.setEditable(false);
			tutorialPane.addHyperlinkListener(this);
			tutorialPane.setPage(Globals.codeBase + "resources/credits.htm");
		}

		catch (IOException e)
		{
			System.err.println("Attempted to read a bad URL: " + Globals.codeBase + "resources/credits.htm");
		}

		// Instantiate the scroll pane with the editor pane
		scrollPane = new JScrollPane(tutorialPane);

		// Construct border
		scrollPane.setBorder(BorderFactory.createLineBorder(new Color(96, 146, 255)));

		// Set the layout and add the objects
		bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.PAGE_AXIS));
		setLayout(new BorderLayout());

		buttonPanel.add(tutorialButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(10, 0))); // Spacer
		buttonPanel.add(prefButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(10, 0))); // Spacer
		buttonPanel.add(planButton);

		bottomPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer
		bottomPanel.add(startLabel);
		bottomPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer
		bottomPanel.add(buttonPanel);
		bottomPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer

		add(scrollPane, BorderLayout.CENTER);
		add(bottomPanel, BorderLayout.PAGE_END);
	}

	/**
	 * Listens for hyperlink selection and follows links on selection
	 */
	public void hyperlinkUpdate(HyperlinkEvent event) // LISTENER FOR HYPERLINKS IN CREDITS PAGE
	{
		if (event.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
		{
			try
			{
				tutorialPane.setPage(event.getURL());
				Logger.log_data("Tutorial directed to (" + event.getURL() + ")");
			}

			catch (IOException ioe)
			{
				System.err.println("Can't follow link to " + event.getURL().toExternalForm() + ": " + ioe);
			}
		}
	}

	/**
	 * Handles all action events on the buttons
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == tutorialButton)
		{
			try
			{
				tutorialPane.setPage(Globals.codeBase + "resources/tutorial.htm");
				Logger.log_data("Tutorial launched.");
			}

			catch (IOException ioe)
			{
				System.err.println("Can't follow link to index.htm: " + ioe);
			}
		}

		else if (e.getSource() == prefButton)
		{
			
			long startTime = System.currentTimeMillis();
			
			JTabbedPane tabs = Globals.tabs;

			// If there is no current preference elicitation UI in a tab, start one
			if (Globals.prefIndex < 0)
			{
				tabs.addTab("Preferences", new PickArch());
				Globals.prefIndex = tabs.getTabCount() - 1;
				Logger.log_data("Preference tab launched.");
			}

			// Select the current preference elicitation UI tab
			tabs.setSelectedIndex(Globals.prefIndex);
			
			long stopTime = System.currentTimeMillis();
			System.err.println("planIt.gui" + "\t" + ((stopTime - startTime)/1000.0) + " s");
			
		}

		else if (e.getSource() == planButton)
		{
			JFileChooser fc = new JFileChooser(Globals.codeBase.getPath().replace("%20", " ") + "xml");
			XMLFilter filter = new XMLFilter();
			Plan plan = null;

			fc.setFileFilter(filter);
			fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

			int val = fc.showOpenDialog(this);

			if (val == JFileChooser.APPROVE_OPTION)
			{
				File file = fc.getSelectedFile();

				PlanParser planParser = new PlanParser(file.getPath());

				plan = planParser.parse();

				JTabbedPane tabs = Globals.tabs;

				tabs.addTab("Plan " + (++Globals.planCount), new PlanPanel(plan));
				tabs.setSelectedIndex(tabs.getTabCount() - 1);
				Logger.log_data("Plan loaded.");
			}
		}
	}
}

