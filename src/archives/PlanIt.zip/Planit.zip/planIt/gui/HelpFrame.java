package planIt.gui;


// Java Packages
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JScrollPane;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;

import planIt.data.Globals;
import planIt.utils.Logger;


public class HelpFrame extends JFrame implements HyperlinkListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private JScrollPane scrollPane;
	private JEditorPane editorPane;

	public HelpFrame()
	{
		// Set the JFrame title
		super("PlanIt - The Interactive Planner");

		// Setup Frame size and position on screen
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		setBounds(50, 50, (dim.width) / 2, (dim.height) / 2);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		editorPane = new JEditorPane();

		// Try to display the html page in the editor pane
		try
		{
			editorPane.setEditable(false);
			editorPane.addHyperlinkListener(this);
			editorPane.setPage(Globals.codeBase + "resources/credits.htm");
		}

		catch (IOException e)
		{
			System.err.println("Failed to display URL: " + Globals.codeBase + "resources/credits.htm");
		}

		// Instantiate the scroll pane with the editor pane
		scrollPane = new JScrollPane(editorPane);

		// Construct line border
		scrollPane.setBorder(BorderFactory.createLineBorder(new Color(96, 146, 255)));

		add(scrollPane);
		setVisible(true);
	}

	/**
	 * Listens for hyperlink selection and follows links on selection
	 */
	public void hyperlinkUpdate(HyperlinkEvent event) // LISTENER FOR HYPERLINKS IN CREDITS PAGE
	{
		if (event.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
		{
			try
			{
				editorPane.setPage(event.getURL());
				Logger.log_data("Tutorial directed to (" + event.getURL() +")");
			}

			catch (IOException ioe)
			{
				System.err.println("Can't follow link to " + event.getURL().toExternalForm() + ": " + ioe);
			}
		}
	}
}

