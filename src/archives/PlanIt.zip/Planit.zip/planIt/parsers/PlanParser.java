package planIt.parsers;


// Java packages
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import planIt.data.Globals;
import planIt.planScan.data.ADDNode;
import planIt.planScan.data.ADDParent;
import planIt.planScan.data.Plan;
import planIt.planScan.data.PlanLeaf;


public class PlanParser
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private Document doc;

	/**
	 * Parse all attributes in the given file
	 */
	public PlanParser(String file)
	{
		try // TRY PARSING XML VIA DOM PARSER
		{
			DocumentBuilderFactory parser = DocumentBuilderFactory.newInstance();

			parser.setIgnoringComments(true);
			parser.setIgnoringElementContentWhitespace(true);

			DocumentBuilder db = parser.newDocumentBuilder();

			doc = db.parse(file);
		}

		catch (Exception e) // CATCH PARSER EXCEPTION
		{
			e.printStackTrace(System.err);
		}
	}

	public Plan parse()
	{
		Element element = doc.getDocumentElement();
		NodeList children = null;
		Plan plan = null;

		if (!element.getTagName().trim().equalsIgnoreCase("plan"))
		{
			System.err.println("Unexpected root element: " + element.getTagName());
			return plan;
		}

		children = element.getChildNodes();

		for (int i = 0; i < children.getLength(); i++)
		{
			if (children.item(i).getNodeName().equalsIgnoreCase("attribute"))
			{
				plan = new Plan(parseAttribute(children.item(i)));
				break;
			}
		}

		return plan;
	}

	ADDParent parseAttribute(Node element)
	{
		ADDParent node = null;
		ADDNode child = null;
		NodeList children = element.getChildNodes();
		NamedNodeMap attributes = null;
		String name = null;

		// Iterate through child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the attribute name
			if (children.item(i).getNodeName().equalsIgnoreCase("name"))
			{
				name = new String(children.item(i).getFirstChild().getNodeValue().trim());

				break; // Break when attribute name is found
			}
		}

		// Catch null or empty string name
		if (name == null || name == "")
		{
			System.err.println("Error - Missing attribute name");
			return null;
		}

		node = new ADDParent(Globals.attributes.get(name));

		// Catch unknown attribute name
		if (node.attribute == null)
		{
			System.err.println("Error - Unknown attribute \"" + name + "\"");
			return null;
		}

		// Iterate through child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the attribute name
			if (children.item(i).getNodeName().equalsIgnoreCase("edge"))
			{
				// Get the XML attributes for the node
				attributes = children.item(i).getAttributes();

				// Should be the first attribute, but this allows for future expansion
				for (int j = 0; j < attributes.getLength(); j++)
				{
					if (attributes.item(j).getNodeName().trim().equalsIgnoreCase("name"))
					{
						name = attributes.item(j).getNodeValue().trim();
					}
				}

				// Catch an unknown value name
				if (node.attribute.values.get(name) == null)
				{
					System.err.println(name + " is not a value for the attribute " + node.attribute.name);
				}// If a value is found, add the name/value pair to the hashmap

				else
				{
					child = parseNode(children.item(i));
					node.children.put(name, child);
				}
			}
		}

		return node;
	}

	/**
	 * Determine whether the given node is a leaf or not, and parse it accordingly
	 */
	public ADDNode parseNode(Node element)
	{
		ADDNode addNode = null;
		NodeList children = element.getChildNodes();

		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse a parent element
			if (children.item(i).getNodeName().equalsIgnoreCase("attribute"))
			{
				addNode = parseAttribute(children.item(i));
				break;
			}

			// Parse a leaf element
			if (children.item(i).getNodeName().equalsIgnoreCase("actions"))
			{
				addNode = parseActions(children.item(i));
				break;
			}
		}

		return addNode;
	}

	/**
	 * Parse a leaf node (action or set of actions)
	 */
	public ADDNode parseActions(Node element)
	{
		PlanLeaf node = new PlanLeaf();
		NodeList children = element.getChildNodes();
		String name = null;

		// PARSE CHILD ELEMENTS
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the CPT
			if (children.item(i).getNodeName().equalsIgnoreCase("action"))
			{
				name = children.item(i).getFirstChild().getNodeValue().trim();

				if (Globals.actions.get(name) == null)
				{
					System.err.println(name + " is an unrecognized action name.");
				}

				else
				{
					node.actions.add(Globals.actions.get(name));
				}
			}
		}

		return node;
	}
}

