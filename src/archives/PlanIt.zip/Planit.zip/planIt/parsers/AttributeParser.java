package planIt.parsers;


// Java packages
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import planIt.data.Attribute;
import planIt.data.Value;


public class AttributeParser
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private Document doc;
	private NodeList attributeList;

	/**
	 * Parse all attributes in the given file
	 */
	public AttributeParser(String filename)
	{
		Attribute temp = null;

		try // TRY PARSING XML VIA DOM PARSER
		{
			DocumentBuilderFactory parser = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = parser.newDocumentBuilder();

			doc = db.parse(filename);

			// Get a list of all elements with the tag name "attribute"
			attributeList = doc.getElementsByTagName("attribute");
		}

		catch (Exception e) // CATCH PARSER EXCEPTION
		{
			e.printStackTrace(System.err);
		}
	}

	public Map<String, Attribute> parse()
	{
		Map<String, Attribute> map = new HashMap<String, Attribute>();
		Attribute attr = null;

		// Check that the element is a sibling of the "attributes" element
		for (int i = 0; i < attributeList.getLength(); i++)
		{
			if (attributeList.item(i).getParentNode().getNodeName().equals("attributes"))
			{
				attr = parseAttribute(attributeList.item(i));
				map.put(attr.name, attr);
			}
		}

		return map;
	}

	/**
	 * Parse an attribute element
	 */
	public Attribute parseAttribute(Node node)
	{
		Attribute attr = new Attribute();
		Value val = null;
		NodeList children = node.getChildNodes();

		// ITERATE THROUGH CHILD ELEMENTS
		for (int i = 0; i < children.getLength(); i++)
		{
			// PARSE THE ATTRIBUTE NAME
			if (children.item(i).getNodeName().equalsIgnoreCase("name"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				attr.name = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}

			// PARSE THE ATTRIBUTE DESCRIPTION
			if (children.item(i).getNodeName().equalsIgnoreCase("description"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				attr.description = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}// PARSE ATTRIBUTE VALUES - Can be any finite number of them, so an array list is used

			else if (children.item(i).getNodeName().equals("value"))
			{
				val = parseAttributeValues(children.item(i));
				attr.values.put(val.name, val);
			}
		}

		// ERROR CHECKING -- NAME MUST EXIST
		if (attr.name == null || attr.name == "")
		{
			System.err.println("Name required for attribute: " + node.getNodeName() + " -- exiting...");
			System.exit(1);
		}

		// Throw warning if there is no description (they are not required currently)
		if (attr.description == null || attr.description == "")
		{
			System.err.println("Warning: No description for attribute: " + node.getNodeName());
		}

		return attr;
	}

	/**
	 * Parse an attribute's value elements
	 */
	public Value parseAttributeValues(Node node)
	{
		Value val = new Value();
		NodeList children = node.getChildNodes();

		// ITERATE THROUGH THE CHILD ELEMENTS
		for (int i = 0; i < children.getLength(); i++)
		{
			// PARSE A VALUE ELEMENT
			if (children.item(i).getNodeName().equalsIgnoreCase("name"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				val.name = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}// PARSE A VALUE DESCRIPTION

			else if (children.item(i).getNodeName().equalsIgnoreCase("description"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				val.description = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}
		}

		// Check that the value name exists
		if (val.name == null || val.name == "")
		{
			System.err.println("Name required for value: " + node.getNodeName() + " -- exiting...");
			System.exit(1);
		}

		// Throw a warning for no description (not required currently)
		if (val.description == null || val.description == "")
		{
			System.err.println("Warning: No description for value: " + node.getNodeName());
		}

		return val;
	}
}

