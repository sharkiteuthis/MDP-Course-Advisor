package planIt.parsers;


// Java packages
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import planIt.data.Action;


public class ActionParser
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private Document doc;
	private NodeList actionList;

	/**
	 * Parse all attributes in the given file
	 */
	public ActionParser(String filename)
	{
		try // TRY PARSING XML VIA DOM PARSER
		{
			DocumentBuilderFactory parser = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = parser.newDocumentBuilder();

			doc = db.parse(filename);

			// Get a list of all elements with the tag name "action"
			actionList = doc.getElementsByTagName("action");
		}

		catch (Exception e) // CATCH PARSER EXCEPTION
		{
			e.printStackTrace(System.err);
		}
	}

	public Map<String, Action> parse()
	{
		Map<String, Action> actions = new HashMap<String, Action>();
		Action action = null;

		// Check that the element is a sibling of the "actions" element
		for (int i = 0; i < actionList.getLength(); i++)
		{
			if (actionList.item(i).getParentNode().getNodeName().equalsIgnoreCase("actions"))
			{
				action = parseAction(actionList.item(i));
				actions.put(action.name, action);
			}
		}

		return actions;
	}

	/**
	 * Parse only the given action from the ADD
	 */
	public Action parseAction(Node node)
	{
		Action action = new Action();
		NodeList children = node.getChildNodes();

		// Iterate through all child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the action name
			if (children.item(i).getNodeName().equalsIgnoreCase("name"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				action.name = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}

			// Parse the label
			if (children.item(i).getNodeName().equalsIgnoreCase("label"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				action.label = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}// Parse the description

			else if (children.item(i).getNodeName().equalsIgnoreCase("description"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				action.description = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}
		}

		// ERROR CHECKING -- NAME MUST EXIST
		if (action.name == null || action.name == "")
		{
			System.err.println("Name required for action: " + node.getNodeName() + " -- exiting...");
			System.exit(1);
		}

		// THROW WARNING FOR NO LABEL -- NOT CURRENTLY REQUIRED, MAY CHANGE
		if (action.label == null || action.label == "")
		{
			System.err.println("Warning: No label for action: " + node.getNodeName());
		}

		// THROW WARNING FOR NO DESCRIPTION -- NOT CURRENTLY REQUIRED, MAY CHANGE
		if (action.description == null || action.description == "")
		{
			System.err.println("Warning: No description for action: " + node.getNodeName());
		}

		return action;
	}
}

