package planIt.parsers;

import java.io.IOException;
import java.io.StreamTokenizer;
import java.io.StringReader;

import planIt.data.Attribute;
import planIt.data.Globals;
import planIt.planScan.data.ADDParent;
import planIt.planScan.data.Plan;
import planIt.planScan.data.PlanLeaf;


public class SPUDDPlanParser
{
	StreamTokenizer stream;
	StringReader 	reader;

	public SPUDDPlanParser(String planText)
	{
		reader = new StringReader(planText);
		stream = new StreamTokenizer(reader);
	}

	public Plan parse()
	{
		Plan plan = null;
		ADDParent root = null;
		Attribute attribute = null;

		try
		{
			stream.nextToken();

			if(stream.ttype != StreamTokenizer.TT_WORD)
			{
				System.err.println("Root attribute of plan not found while parsing SPUDD plan.");
				return null;
			}

			attribute = Globals.attributes.get(stream.sval);

			if(attribute == null)
			{
				System.err.println("Invalid attribute name found while parsing SPUDD plan");
				return null;
			}

			root = new ADDParent(attribute);
			parseTree(root);
		}

		catch(IOException ioe)
		{
			System.err.println("Error parsing SPUDD plan");
		}

		if(root == null)
		{
			System.err.println("Error parsing plan: The resulting plan is null.");
		}

		plan = new Plan(root);
		reader.close();

		return plan;
	}

	public void parseTree(ADDParent root)
	{
		String value = null;

		try
		{
			while(stream.ttype != StreamTokenizer.TT_EOF)
			{
				stream.nextToken();

				switch(stream.ttype)
				{
					case StreamTokenizer.TT_WORD:
					{
						Attribute attr = Globals.attributes.get(stream.sval);

						if(attr == null)
						{
							System.err.println("Error parsing plan: Invalid attribute name - " + stream.sval);
							return;
						}

						ADDParent child = new ADDParent(attr);

						if(root.getAttribute().values.get(value) == null)
						{
							System.err.println("Error parsing plan: Unknown value - " + value + " for attribute - " + attr.getName());
							return;
						}

						root.addChild(value, child);
						parseTree(child);

						// If all the children have been parsed, quit from this branch
						if(root.children.size() >= root.getAttribute().getValues().size())
						{
							return;
						}

						// Otherwise, continue parsing.
						else
						{
							break;
						}
					}

					case '<':
					{
						stream.nextToken();

						if(stream.ttype != StreamTokenizer.TT_WORD)
						{
							System.err.println("Error parsing plan: Unexpected token.");
							return;
						}

						if(!stream.sval.equals(root.getAttribute().getName()))
						{
							System.err.print("Error parsing plan: Unexpected attribute name - " + stream.sval);
							System.err.println(".  Expected attribute \"" + root.getAttribute().getName() + "\"");
							return;
						}

						break;
					}

					case '=':
					{
						stream.nextToken();

						if(stream.ttype != StreamTokenizer.TT_WORD)
						{
							System.err.println("Error parsing plan: Expected value name.");
							return;
						}

						value = stream.sval;

						if(root.getAttribute().values.get(value) == null)
						{
							System.err.println("Error parsing plan: Unknown value - " + value);
						}

						break;
					}

					case '{' :
					{
						stream.nextToken();

						if(stream.ttype != StreamTokenizer.TT_WORD || !stream.sval.equals("action"))
						{
							break;
						}

						stream.nextToken();

						if(stream.ttype != '=')
						{
							System.err.println("Error parsing plan: Expected \"=\"");
							return;
						}

						stream.nextToken();

						if(stream.ttype != StreamTokenizer.TT_WORD)
						{
							System.err.println("Error parsing plan: Expected an action name.");
							return;
						}

						if(Globals.actions.get(stream.sval) == null)
						{
							System.err.println("Error parsing plan: Unknown action name.");
							return;
						}

						PlanLeaf leaf = new PlanLeaf();
						leaf.addAction(Globals.actions.get(stream.sval));
						root.addChild(value, leaf);

						// If all the children have been parsed, quit from this branch
						if(root.children.size() >= root.getAttribute().getValues().size())
						{
							return;
						}

						// Otherwise, continue parsing.
						else
						{
							break;
						}
					}

					case StreamTokenizer.TT_EOF:
					{
						return;
					}

					case StreamTokenizer.TT_NUMBER: break;
					case ':' : break;
					case '>' : break;
					case '}' : break;

					default :
					{
						System.err.println("Error parsing plan: Unknown token type - " + (char)stream.ttype);
						return;
					}
				}
			}
		}

		catch(IOException ioe)
		{
			System.err.println("Error parsing plan: IO exception thrown.");
		}
	}
}
