package planIt.parsers;


// Java packages
import java.util.ArrayList;
import java.util.List;

import javax.swing.tree.DefaultMutableTreeNode;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import planIt.data.Attribute;
import planIt.data.Globals;
import planIt.poet.data.Archetype;
import planIt.poet.data.PrefNode;
import planIt.poet.data.UtilityNode;


public class ArchetypeParser
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private Document doc;
	private NodeList archList;

	/**
	 * Parse all archetypes in the given file
	 */
	public ArchetypeParser(String filename)
	{
		try // TRY PARSING XML VIA DOM PARSER
		{
			DocumentBuilderFactory parser = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = parser.newDocumentBuilder();

			doc = db.parse(filename);

			// Get a list of all elements with the tag name "prefs"
			archList = doc.getElementsByTagName("prefs");
		}

		catch (Exception e) // CATCH PARSER EXCEPTION
		{
			e.printStackTrace(System.err);
		}
	}

	public DefaultMutableTreeNode[] parse()
	{
		List<DefaultMutableTreeNode> archetypes = new ArrayList<DefaultMutableTreeNode>();
		DefaultMutableTreeNode archArray[];
		DefaultMutableTreeNode temp = null;

		if (archList == null)
		{
			System.err.println("Invalid preference file");
			return null;
		}

		// Check that the element is a sibling of the "prefs" element
		for (int i = 0; i < archList.getLength(); i++)
		{
			temp = parseArchetype(archList.item(i));

			// If parsed archetype returns a non-null tree, add it
			if (temp != null)
			{
				archetypes.add(temp);
			}
		}

		// Convert the list of archetype trees into a static array
		archArray = new DefaultMutableTreeNode[archetypes.size()];
		archetypes.toArray(archArray);

		return archArray;
	}

	/************************************************
	 * FUNCTIONS FOR PARSING THE ARCHETYPE ELEMENTS *
	 ************************************************/

	/**
	 * Parse an archetype
	 */
	public DefaultMutableTreeNode parseArchetype(Node element)
	{
		DefaultMutableTreeNode node = new DefaultMutableTreeNode();
		DefaultMutableTreeNode temp = null;
		Archetype arch = new Archetype();
		NodeList children = element.getChildNodes();

		// Iterate over child nodes
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the archetype name
			if (children.item(i).getNodeName().equalsIgnoreCase("name"))
			{
				arch.name = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}
		}

		// Disallow empty names
		if (arch.name == null || arch.name == "")
		{
			System.err.println("Empty archetype name");
			return null;
		}

		// Iterate over child nodes
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the archetype description
			if (children.item(i).getNodeName().equalsIgnoreCase("description"))
			{
				arch.description = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}

			// Parse children and add them to the node
			else if (children.item(i).getNodeName().equals("attribute"))
			{
				parseAttribute(children.item(i), node);
			}
		}

		// Attach the archetype data to the node
		node.setUserObject(arch);

		return node;
	}

	/**
	 * Parses an Attribute node
	 */
	public void parseAttribute(Node element, DefaultMutableTreeNode node)
	{
		DefaultMutableTreeNode temp = null;
		Attribute attr = new Attribute();
		NodeList children = element.getChildNodes();
		String name = null;

		// Ensure attribute name is found first, so lookup can be performed
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse attribute name
			if (children.item(i).getNodeName().equalsIgnoreCase("name"))
			{
				name = children.item(i).getFirstChild().getNodeValue().trim();
			}
		}

		// Disallow empty attribute names
		if (name == null || name == "")
		{
			System.err.println("Empty attribute name");
			return;
		}

		// Lookup and verify the name represents a valid attribute
		attr = Globals.attributes.get(name);

		if (attr == null)
		{
			System.err.println("Could not find attribute \"" + name + "\"");
			return;
		}

		// Iterate through child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse branch element
			if (children.item(i).getNodeName().equalsIgnoreCase("edge"))
			{
				temp = parseBranch(children.item(i), attr);

				if (temp != null)
				{
					node.add(temp);
				}
			}

			// Parse a leaf element
			else if (children.item(i).getNodeName().equalsIgnoreCase("preference"))
			{
				temp = parseLeaf(children.item(i), attr);

				if (temp != null)
				{
					node.add(temp);
				}
			}
		}
	}

	/**
	 * Parses a branch value
	 */
	public DefaultMutableTreeNode parseBranch(Node element, Attribute attribute)
	{
		DefaultMutableTreeNode node = new DefaultMutableTreeNode();
		DefaultMutableTreeNode temp = null;
		PrefNode prefNode = new PrefNode();
		NodeList children = element.getChildNodes();
		String name = null;

		// Iterate through child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the branch value, perform lookup by name
			if (children.item(i).getNodeName().equalsIgnoreCase("value"))
			{
				name = children.item(i).getFirstChild().getNodeValue().trim();
			}
		}

		if (name == null || name == "")
		{
			System.err.println("Empty value name");
			return null;
		}

		prefNode.attribute = attribute;
		prefNode.value = attribute.values.get(name);

		if (prefNode.value == null)
		{
			System.err.println("Could not find value \"" + name + "\" for attribute \"" + attribute.name + "\"");
			return null;
		}

		// Iterate through child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse children
			if (children.item(i).getNodeName().equalsIgnoreCase("attribute"))
			{
				parseAttribute(children.item(i), node);
			}
		}

		node.setUserObject(prefNode);

		return node;
	}

	/**
	 * Parse a leaf node
	 */
	public DefaultMutableTreeNode parseLeaf(Node element, Attribute attribute)
	{
		DefaultMutableTreeNode node = new DefaultMutableTreeNode();
		DefaultMutableTreeNode temp = null;
		UtilityNode utilityNode = new UtilityNode();
		NodeList children = element.getChildNodes();
		String name = null;

		// Iterate through child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the branch value, perform lookup by name
			if (children.item(i).getNodeName().equalsIgnoreCase("value"))
			{
				name = children.item(i).getFirstChild().getNodeValue().trim();
			}
		}

		if (name == null || name == "")
		{
			System.err.println("Empty value name");
			return null;
		}

		utilityNode.attribute = attribute;
		utilityNode.value = attribute.values.get(name);

		if (utilityNode.value == null)
		{
			System.err.println("Could not find value \"" + name + "\" for attribute \"" + attribute.name + "\"");
			return null;
		}

		// Iterate through child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			if (children.item(i).getNodeName().trim().equalsIgnoreCase("utility"))
			{
				utilityNode.utility = Double.parseDouble(children.item(i).getFirstChild().getNodeValue().trim());
			}
		}

		if (utilityNode.utility < -1 || utilityNode.utility > 1)
		{
			System.err.println("Utility can't be less than -1 or greater than 1");
			utilityNode.utility = 0;
		}

		node.setUserObject(utilityNode);

		return node;
	}
}

