package planIt.parsers;


// Java packages
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import planIt.data.Attribute;
import planIt.data.Globals;
import planIt.data.Value;
import planIt.planScan.data.State;
import planIt.planScan.data.StateValue;


public class StateParser
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private Document doc;
	private Node root;
	private State state;

	/**
	 * Parse all attributes in the given file
	 */
	public StateParser(String filename)
	{
		try // TRY PARSING XML VIA DOM PARSER
		{
			NodeList children = null;

			DocumentBuilderFactory parser = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = parser.newDocumentBuilder();

			doc = db.parse(filename);

			// Get the first occurence of a start state (there should only be one)
			children = doc.getElementsByTagName("start_state");

			if (children.getLength() < 1)
			{
				System.err.println("No start state specified in the input the file");
				root = null;
			}

			else if (children.getLength() > 1)
			{
				System.err.println("Found multiple start states, only parsing one");
				root = children.item(0);
			}

			else
			{
				root = children.item(0);
			}
		}

		catch (Exception e) // CATCH PARSER EXCEPTION
		{
			e.printStackTrace(System.err);
		}
	}

	public State parse()
	{
		state = new State();
		NodeList children;

		// if start state is unspecified, use default
		if(root == null)
		{
			return defaultStartState();
		}

		children = root.getChildNodes();

		// Iterate through all child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the attribute name
			if (children.item(i).getNodeName().equalsIgnoreCase("attribute"))
			{
				parseAttribute(children.item(i));
			}
		}

		return state;
	}

	/**
	 * Parse the attributes and values for the starting state
	 */
	public void parseAttribute(Node node)
	{
		NodeList children = node.getChildNodes();
		StateValue sVal = null;
		Attribute attr = null;
		Value val = null;
		String name = null;
		String value = null;

		// Iterate through all child elements
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the attribute name
			if (children.item(i).getNodeName().equalsIgnoreCase("name"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				name = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}// Parse the value name

			else if (children.item(i).getNodeName().equalsIgnoreCase("value"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				value = new String(children.item(i).getFirstChild().getNodeValue().trim());
			}
		}

		// Check that a valid attribute name was parsed
		if (name == null || name == "")
		{
			System.err.println("No attribute name found");
			return;
		}

		// Check that a valid attribute name was parsed
		if (value == null || value == "")
		{
			System.err.println("No value name found");
			return;
		}

		attr = Globals.attributes.get(name);

		// Check that the attribute exists
		if (attr == null)
		{
			System.err.println("Attribute " + name + " was not found");
			return;
		}

		val = attr.values.get(value);

		// Check that the value exists for the attribute
		if (val == null)
		{
			System.err.println("Value \"" + val + "\" is not a value of attribute \"" + name + "\"");
		}

		sVal = new StateValue(attr, val, 1.0);

		state.stateValues.put(name, sVal);
	}

	public State defaultStartState()
	{
		State start = new State();
		StateValue sVal = null;
		Value val = null;

		for(Attribute attr : Globals.attributes.values())
		{
			val = (Value)attr.values.values().toArray()[0];
			sVal = new StateValue(attr, val, 1.0);
			start.stateValues.put(attr.getName(), sVal);
		}

		start.print();

		return start;
	}
}

