package planIt.parsers;


// Java packages
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;
import org.w3c.dom.NamedNodeMap;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import planIt.data.Attribute;
import planIt.data.Globals;
import planIt.planScan.data.ADD;
import planIt.planScan.data.ADDLeaf;
import planIt.planScan.data.ADDNode;
import planIt.planScan.data.ADDParent;


public class ADDParser
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private Document 	doc;
	private NodeList 	actionList;
	private Node		discount;
	private Node		tolerance;
	private String 		actionName;

	/**
	 * Parse all attributes in the given file
	 */
	public ADDParser(String filename)
	{
		try // TRY PARSING XML VIA DOM PARSER
		{
			DocumentBuilderFactory parser = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = parser.newDocumentBuilder();

			doc = db.parse(filename);

			// Get a list of all elements with the tag name "action"
			actionList = doc.getElementsByTagName("action");
			discount = doc.getElementsByTagName("discount").item(0);
			tolerance = doc.getElementsByTagName("tolerance").item(0);
		}

		catch (Exception e) // CATCH PARSER EXCEPTION
		{
			e.printStackTrace(System.err);
		}

		if (actionList == null)
		{
			System.out.println("Could not find any specified actions in input file");
			System.exit(1);
		}

		if (discount == null)
		{
			System.out.println("The planner discount could not be found in the input file");
			System.exit(1);
		}

		if (tolerance == null)
		{
			System.out.println("The planner tolerance could not be found in the input file");
			System.exit(1);
		}
	}

	/**
	 * Parse the all action trees in the ADD
	 */
	public ADD parse()
	{
		ADD add = new ADD();
		Map<String, ArrayList<ADDParent> > actionMap = new HashMap<String,  ArrayList<ADDParent> >();
		ArrayList<ADDParent> temp = null;

		// Check that the element is a sibling of the "actions" element
		for (int i = 0; i < actionList.getLength(); i++)
		{
			if (actionList.item(i).getParentNode().getNodeName().equalsIgnoreCase("actions"))
			{
				temp = parseActionTree(actionList.item(i));
				actionMap.put(actionName, temp);
			}
		}

		add.tolerance = getValue(tolerance);
		add.discount = getValue(discount);
		add.children = actionMap;

		return add;
	}

	/**
	 * Parse a single ADD action (single tree)
	 */
	public ArrayList<ADDParent> parseActionTree(Node node)
	{
		ArrayList<ADDParent> childNodes = new ArrayList<ADDParent>();
		NodeList children = node.getChildNodes();

		// ITERATE THROUGH CHILD ELEMENTS
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the action name
			if (children.item(i).getNodeName().equalsIgnoreCase("name"))
			{
				// Assume first child is the PCDATA
				actionName = new String(children.item(i).getFirstChild().getNodeValue().trim());
				break;
			}
		}

		// Catch null or empty string name
		if (actionName == null || actionName == "")
		{
			System.err.println("Error - An action element must specify a non-empty name");
			System.exit(1);
		}

		// Verify the action name is valid (is in the Global action hash map)
		if (Globals.actions.get(actionName) == null)
		{
			System.err.println("Error - Cannot find the specified action: " + actionName);
			System.exit(1);
		}

		// Re-iterate through child elements - This ensures that checks have been made on the name already
		for (int i = 0; i < children.getLength(); i++)
		{
			// PARSE THE BAYES NET FRAGMENTS FOR THE ACTION
			if (children.item(i).getNodeName().equals("fragment"))
			{
				childNodes.add(parseParent(children.item(i)));
			}
		}

		return childNodes;
	}

	/**
	 * Determine whether the given node is a leaf or not, and parse it accordingly
	 */
	public ADDNode parseNode(Node node)
	{
		ADDNode addNode = null;
		NodeList children = node.getChildNodes();

		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse a parent element
			if (children.item(i).getNodeName().equalsIgnoreCase("depends"))
			{
				addNode = parseParent(children.item(i));
			}

			// Parse a leaf element
			if (children.item(i).getNodeName().equalsIgnoreCase("cpt"))
			{
				addNode = parseLeaf(children.item(i));
			}
		}

		return addNode;
	}

	/**
	 * Parse a parent node in the ADD
	 */
	public ADDParent parseParent(Node node)
	{
		ADDParent addNode = null;
		NodeList children = node.getChildNodes();
		ADDNode child = null;
		String name = null;
		NamedNodeMap attributes = null;

		// Retrieve the attribute name first
		for (int i = 0; i < children.getLength(); i++)
		{
			// PARSE THE NAME AND LOOKUP THE CORRESPONDING ATTRIBUTE
			if (children.item(i).getNodeName().equalsIgnoreCase("name"))
			{
				// ASSUMES FIRST CHILD IS THE PCDATA
				name = new String(children.item(i).getFirstChild().getNodeValue().trim());
				break;
			}
		}

		// Verify a non=empty string was found
		if (name == null || name.equals(""))
		{
			System.err.println("Empty attribute name in action");
			System.exit(1);
		}

		// Perform the attribute lookup by name
		Attribute attr = Globals.attributes.get(name);

		// Check that an attribute was returned (ie - there was a match)
		if (attr == null)
		{
			System.err.println("No matching attribute for name " + name);
			System.exit(1);
		}

		// Create a new ADDNode referencing the returned attribute
		addNode = new ADDParent(attr);

		name = "";

		// Re-iterate over the elements to parse the children
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse a link (value) to a child node
			if (children.item(i).getNodeName().equalsIgnoreCase("edge"))
			{
				// Get the XML attributes for the node
				attributes = children.item(i).getAttributes();

				// Parse the node recursively
				child = parseNode(children.item(i));

				// Parse the XML attributes to get the value name
				for (int j = 0; j < attributes.getLength(); j++)
				{
					// Get the corresponding root value name for probability
					if (attributes.item(j).getNodeName().trim().equalsIgnoreCase("value"))
					{
						name = attributes.item(j).getNodeValue().trim();
					}
				}

				if (addNode.attribute.values.get(name) == null)
				{
					System.err.println(name + " is not a value for the attribute " + addNode.attribute.name);
				}

				else
				{
					// Hash the child node by the attribute value name for its edge
					addNode.children.put(name, child);
				}
			}
		}

		return addNode;
	}

	/**
	 * Parse a leaf node (CPT) in the ADD
	 */
	public ADDNode parseLeaf(Node node)
	{
		ADDLeaf addNode = new ADDLeaf();
		NodeList children = node.getChildNodes();
		String name = null;
		double value = 0;

		// PARSE CHILD ELEMENTS
		for (int i = 0; i < children.getLength(); i++)
		{
			// Parse the CPT
			if (children.item(i).getNodeName().equalsIgnoreCase("prob"))
			{
				// Get the XML attribute list for the element
				NamedNodeMap attributes = children.item(i).getAttributes();

				// Iterate through attributes - so it doesn't break if more attributes are added later
				for (int j = 0; j < attributes.getLength(); j++)
				{
					// Get the corresponding root value name for probability
					if (attributes.item(j).getNodeName().equalsIgnoreCase("value"))
					{
						name = attributes.item(j).getNodeValue();
					}

					value = Double.valueOf(children.item(i).getFirstChild().getNodeValue().trim());
				}

				addNode.cpt.put(name, value);
			}
		}

		return addNode;
	}

	public double getValue(Node node)
	{
		return Double.valueOf(node.getFirstChild().getNodeValue().trim());
	}
}

