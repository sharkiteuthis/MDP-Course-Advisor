package planIt.comm;


import java.io.*;
import java.net.*;
import java.util.*;


public class XmlSrvConnector
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private Socket sock;
    private BufferedReader in;
	private OutputStream outstr;
	private String strCommand;
	private String strHost;
	private String strResponse;
	private int intPort;
	private ArrayList<String> aryNetworkList = new ArrayList<String>();
	private ArrayList<String> aryProjectList = new ArrayList<String>();

	// Default constructor
	public  XmlSrvConnector()
	{
		strHost = "hammill.csr.uky.edu";
		intPort = 2500;
    }

	// Flexible constructor
	public  XmlSrvConnector(String strHost, int intPort)
	{
		this.strHost = strHost;
		this.intPort = intPort;
    }

	// Return the host.
	public String getHost()
	{
		return(strHost);
	}

	// Return the port.
	public int getPort()
	{
		return(intPort);
	}

	// Return the last known command sent to the server.
	public String getCommand()
	{
		return(strCommand);
	}

    // Connect to the data server.
    public void connect() throws IOException
    {
    	if (sock != null && sock.isConnected()) {
    		throw new IOException("Connection already established.");
    	}
    	sock = new Socket(strHost, intPort);
		outstr = sock.getOutputStream();
		in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
	}

	 // Close the connection to the data server.
    public void close() throws IOException
    {
		// Inform the server to close the thread.
		strCommand = "EXIT";
		outstr.write((strCommand + "\n").getBytes());
		// Close all the streams.
		in.close();
		in = null;
		outstr.close();
		sock.close();
		sock = null;
    }

    // Get the names of networks of the project in the data server.
    public ArrayList<String> getNetworkList(String strProject) throws IOException
    {
   		aryNetworkList.clear();
   		strCommand = "GET NETWORK NAMES " + strProject;
   		outstr.write((strCommand + "\n").getBytes());
   		strResponse = in.readLine();
 
   		if (strResponse.startsWith("FAILED:")) { 
   			throw new IOException("strResponse");
   		}

		// handle the names returned, can be empty list.
		String[] result = strResponse.split("\\s");
		for (int i = 0; i < result.length; i++) {
			aryNetworkList.add(aryNetworkList.size(), result[i]);
		}

		return(aryNetworkList);
    }

    // Get the names of projects of the project in the data server.
    public ArrayList<String> getProjectList() throws IOException
    {
  		aryProjectList.clear();
   		strCommand = "GET PROJECT NAMES";
   		outstr.write((strCommand + "\n").getBytes());
   		strResponse = in.readLine();

   		if (strResponse.startsWith("FAILED:")) { 
   			throw new IOException("strResponse");
   		}

		// handle the names returned , can be empty list.
   	    String[] result = strResponse.split("\\s");
   	    for (int i = 0; i < result.length; i++) {
   			aryProjectList.add(aryProjectList.size(), result[i]);
   	    }

		return(aryProjectList);
    }

    // Getting a portion of an XML file based on XQuery.
    public String getXQuery(String strXQuery) throws IOException
    {
   		strCommand = "PATH " + strXQuery;
   		outstr.write((strCommand + "\n").getBytes());

   		while (!in.ready()) {}

    	strResponse = in.readLine();
    	if (!strResponse.equals("Ready")) {
    		throw new IOException("Unexpected server response (" + strResponse + "). Was expecting (Ready)");
    	}

    	// Create a new BufferedReader stream.
    	StringBuffer strbufResponse = new StringBuffer();

    	while (!in.ready()) {}

    	// Test if the end of the xml file.
    	while((strResponse = in.readLine()) != "null") { 
    		strbufResponse.append(strResponse + "\n");
    	}
 
    	strResponse = strbufResponse.toString();
    	strbufResponse = null;

    	return(strResponse);
   	}

    // Get a file from the XML server.
    public void putProject(String strProject) throws IOException
    {
    	strCommand = "CREATE " + strProject;
   		outstr.write((strCommand + "\n").getBytes());
    }

    // Get a file from the XML server.
    public void getFile(File fileLocalFile, String strProject, String strFile) throws IOException
    {
    	strCommand = "GET " + strFile + " " + strProject;
   		outstr.write((strCommand + "\n").getBytes());

   		while (!in.ready()) {}

   		strResponse = in.readLine();
   		if (!strResponse.equals("Ready")) { 
    		throw new IOException("Unexpected server response (" + strResponse + "). Was expecting (Ready)");
   		}

    	StringBuffer strbufResponse = new StringBuffer();

    	// Test if the end of the xml file.
    	while (!in.ready()) {}

    	while (!(strResponse = in.readLine()).equals("null")) {
    		strbufResponse.append(strResponse + "\n");
    	}

    	String strXMLDoc = strbufResponse.toString();
    	strbufResponse = null;

    	// Write to file and store it.
    	try {
    		saveRetrievedFile(strProject, fileLocalFile, strXMLDoc);
    	} catch (Exception exc) {
    		throw new IOException("Save local file operation failed.");
    	}
   	}

    // Put a file on the XML server.
    public void putFile(File fileLocalFile, String strProject, String strFile) throws IOException
    {
   		strCommand = "MODIFY " + strFile + " " + strProject;
   		outstr.write((strCommand + "\n").getBytes());

   		while (!in.ready()) {}

   		strResponse = in.readLine();
  		if (!strResponse.equals("Ready")) {
  	   		strCommand = "STORE " + strFile + " " + strProject;
  			outstr.write((strCommand + "\n").getBytes());
  			
  			while (!in.ready()) {}

  	   		strResponse = in.readLine();
  	   		if (!strResponse.equals("Ready")) {
  	   			throw new IOException("Unexpected server response (" + strResponse + "). Was expecting (Ready)");
    		}
  		}

    	// Get the XML stream and send to server.
    	BufferedReader buffreadFile = new BufferedReader(new FileReader(fileLocalFile.getAbsolutePath()));

        strResponse = buffreadFile.readLine();
        while (strResponse != null) {
          	outstr.write((strResponse + "\n").getBytes());        
           	strResponse = buffreadFile.readLine();
        }

        buffreadFile.close();

        // Tell the server that the xml file ends.
        outstr.write("null\n".getBytes());
    }

    // Delete a file on the XML server.
    public void deleteFile(String strProject, String strFile) throws IOException
    {
   		strCommand = "DELETE " + strFile + " " + strProject;
   		outstr.write((strCommand + "\n").getBytes());
   	}

    // Method used to overwrite the file using modify command.
    private void saveRetrievedFile(String strProject, File fileLocalFile, String strXMLDoc) throws IOException
    {
   		FileWriter fout = new FileWriter(fileLocalFile.getAbsolutePath());
   		fout.write(strXMLDoc);
   		fout.close();
    }
}

