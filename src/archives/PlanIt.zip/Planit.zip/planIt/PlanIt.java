package planIt;


// Java Packages
import java.awt.Container;
import java.awt.Dimension;
import java.awt.GraphicsEnvironment;
import java.awt.Toolkit;
import java.io.FileWriter;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.UIManager;

import planIt.comm.XmlSrvConnector;

import planIt.gui.ProjectManager;
import planIt.data.Globals;
import planIt.gui.CloseableTabbedPane;
import planIt.gui.LoginDialogBox;
import planIt.gui.StartPane;
import planIt.gui.ToolBar;
import planIt.parsers.ADDParser;
import planIt.parsers.ActionParser;
import planIt.parsers.ArchetypeParser;
import planIt.parsers.AttributeParser;
import planIt.parsers.StateParser;
import planIt.utils.UtilityComparator;
import planIt.utils.Logger;

public class PlanIt extends JFrame
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private ToolBar		toolBar;
	private StartPane	startPane;
	private String 		path;

	private AttributeParser	attrParser;
	private ActionParser	actionParser;
	private ArchetypeParser	archParser;
	private ADDParser 		addParser;
	private StateParser 	stateParser;
	private XmlSrvConnector XmlSrvConnection;

	public PlanIt()
	{
		
		// Set the JFrame title
		super("PlanIt - The Interactive Planner");

		// Automatically set the look and feel based on the user's OS
		try
		{
			UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
		}

		catch (Exception e)
		{
			System.err.println("Could not set the look and feel");
		}

		// Get the main content pane
		Container cp = getContentPane();

		// Get the path and make it acceptable to java (no spaces and only forward slashes)
		path = new String(System.getProperty("user.dir"));
		path = path.replaceAll(" ", "%20");
		path = path.replace('\\', '/');
		path = "file:" + path + "/";

		// Make the updated path a URL object for Java manipulation
		try
		{
			Globals.codeBase = new URL(path);
		}

		catch (MalformedURLException e)
		{
			System.err.println("Error: " + Globals.codeBase);
		}

		// Call the user login routine
		new LoginDialogBox();

		long startTime = System.currentTimeMillis();

		Logger.log_data("Program launched.");

		/* new ProjectManager(); */

		Globals.file = "PlanIt/xml/PlanIt.xml";

		// Call file parsers to initialize data
		// These need to be consolidated now that they are all in the same file
		attrParser = new AttributeParser(Globals.file);
		Globals.attributes = attrParser.parse();
		attrParser = null;
		
		System.gc();
		
		actionParser = new ActionParser(Globals.file);
		Globals.actions = actionParser.parse();

		System.gc();
		
		archParser = new ArchetypeParser(Globals.file);
		Globals.archetypes = archParser.parse();

		System.gc();
		
		addParser = new ADDParser(Globals.file);
		Globals.add = addParser.parse();

		System.gc();
		
		stateParser = new StateParser(Globals.file);
		Globals.startState = stateParser.parse();

		System.gc();
		
		Globals.planCount = 0;
		Globals.prefIndex = -1;
		Globals.stateComparator = new UtilityComparator();

		Globals.frame = this;

		// Construct and add GUI objects to the frame
		Globals.tabs = new CloseableTabbedPane();
		toolBar = new ToolBar();
		Globals.tabs.setFont(Globals.mediumFont);
		startPane = new StartPane();

		Globals.tabs.addTab("Start", startPane);
		Globals.tabs.setCloseIconVisibleAt(0, false);
		setJMenuBar(toolBar);
		cp.add(Globals.tabs);
		
		long stopTime = System.currentTimeMillis();
		System.err.println("planIt" + "\t" + ((stopTime - startTime)/1000.0) + " s");
	}

	/**
	 * MAIN
	 */
	public static void main(String args[])
	{
		GraphicsEnvironment env = GraphicsEnvironment.getLocalGraphicsEnvironment();

		/* if (args.length == 1)
		{
			Globals.file = new String(args[0]);
		}

		else
		{
			Globals.file = new String("");
		} */

		final JFrame f = new PlanIt();

		// This sets the default non-maximized size.  If this is not done
		// un-maximizing will make the frame the minimum allowed size
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		f.setBounds(50, 50, (3 * dim.width) / 4, (3 * dim.height) / 4);

		// This maximizes the window WITHOUT covering the taskbar
		f.setExtendedState(f.getExtendedState() | f.MAXIMIZED_BOTH);

		f.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
		f.setVisible(true);
	}
}

