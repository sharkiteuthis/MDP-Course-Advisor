package planIt.pole;


public class CMain
{

	/**
	 * @param args
	 */
	public static void main(String[] args)
	{

		/*
		 * The action add description in the input file must be complete: each variable whose domain
		 * has n values should have n branches. For example, for binary variable a, it should look like
		 * (a (true (1.00)) (false (0.00))). Please note that the format is different from the format that
		 * SPUDD uses. It is similar to the "old format" on the SPUDD website. However, in each brunch,
		 * the value of the variable must be specified, unlike that in the SPUDD old format where those
		 * values are omitted.
		 * Furthermore, the ADD representation of the CPT for an action must have the following form.
		 * Let a' be the primed variable associated with an ADD. In other words, this ADD specifies
		 * the probability of variable a having one of its values in the next planning step, given an
		 * action. Assuming a is a binary variable, in SPUDD format, we only need to specify the probility
		 * for a being true in the next step. However, here we need to specify both probabilities: a being
		 * true and a being false. In a multi-valued case, we need to specify probabilities for each value.
		 * Please refer to the "example.txt" to get an idea how to write such an ADD.
		 */
		// evaluate given pla
		Runtime thisTime = Runtime.getRuntime();
	//	System.out.println("Total Mem =" + thisTime.totalMemory() + "\n");
		long startMem = thisTime.totalMemory();
		long startTime = System.currentTimeMillis();	
		//Run the planner
		CPlanner planevaluator = new CPlanner();
		planevaluator.run(args[0]);
		long endMem = thisTime.totalMemory();
		long endTime = System.currentTimeMillis();
		System.out.println("Total Memory: \n"
						+ "Start  : " + startMem + "\n"
						+ "End    : " + endMem + "\n"
						+ "Diff   : " + (endMem - startMem) + "\n\n"
				 +  "Total Time (mSec): \n"
					        + "Start  : " +startTime + "\n"
						+ "End    : " + endTime + "\n"
						+ "Diff   : " + (endTime - startTime) +"\n\n");
		// planevaluator.run("coffee_pole.txt");// coffee example
		//planevaluator.run("example_pole.txt"); // another example

		// compute the optimal plan
		//CPlanner planner = new CPlanner();

		// planner.run("coffee.txt");// coffee example
		//planner.run("example.txt"); // another example

		// compare two value functions
//		System.out.println("max diff = " + OP.maxAll(OP.abs(OP.sub(planevaluator.getValueFn(), planner.getValueFn()))));
	}

}

