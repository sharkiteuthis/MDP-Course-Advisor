package planIt.pole;


import java.util.Vector;


public class CPlanner
{
	protected ParseSPUDD m_MDP;
	protected DD m_valueFn;

	/*
	 * Global.varNames/valNames are array version of m_MDP.varNames/valNames
	 */
	protected DD valueIteration(boolean policyEvaluation)
	{
		if (policyEvaluation)
		{
			System.out.println("Evaluating plan ...");
		}

		else
		{
			System.out.print("Computing the optimal plan ...");
		}

		int[] allVar = new int[m_MDP.varNames.size()];
		int[] primedVar = new int[m_MDP.varNames.size() / 2];
		int start = m_MDP.varNames.size() / 2;

		// construct an array of all variables
		for (int i = 0; i < m_MDP.varNames.size(); i++)
		{
			allVar[i] = i + 1;
		}

		// construct an array of primed variables
		for (int i = start; i < m_MDP.varNames.size(); i++)
		{
			primedVar[i - start] = i + 1;
		}

		DD[] everything = new DD[m_MDP.varNames.size() / 2 + 2]; // last two will be primedValFn and discount

		if (policyEvaluation)
		{
			// variable i
			for (int i = 0; i < m_MDP.varNames.size() / 2; i++)
			{
				DD[] cptForCurrentVar = new DD[1];

				cptForCurrentVar[0] = ((DD[]) (m_MDP.policyActTransitions.get(0)))[i];
				everything[i] = DDnode.myNew(Global.varNames.length, cptForCurrentVar);
			}
		}

		else
		{
			// construct a two dimensional array: cpt -- cpt[i] stores a list of cpts of all actions for
			// variable i
			for (int i = 0; i < m_MDP.varNames.size() / 2; i++)
			{
				DD[] cptsForCurrentVar = new DD[m_MDP.actNames.size()];

				for (int j = 0; j < m_MDP.actNames.size(); j++)
				{
					cptsForCurrentVar[j] = ((DD[]) (m_MDP.actTransitions.get(j)))[i];
				}

				everything[i] = DDnode.myNew(Global.varNames.length, cptsForCurrentVar);
			}
		}

		// construct reward add, assuming actions have no costs
		DD rewards = m_MDP.reward;
		DD valFn = rewards;
		DD discount = m_MDP.discount;
		double tolerance = m_MDP.tolerance.getVal();
		boolean converged = false;
		DD bellErr = DD.one;
		int iter = 0;
		boolean firstIteration = true;

		while (!converged)
		{
			iter++;

			try
			{
				if (Thread.interrupted())
				{
					throw new InterruptedException();
				}
			}

			catch (InterruptedException e)
			{
				System.out.println("Planning halted");
				return null;
			}

			DD primedValFn = OP.primeVars(OP.clearConfig(valFn), m_MDP.varNames.size() / 2);

			everything[everything.length - 2] = primedValFn;
			everything[everything.length - 1] = discount;

			DD qFn = OP.addMultVarElim(everything, primedVar);

			qFn = OP.add(qFn, rewards);
			if (!firstIteration)
			{
				qFn = OP.approximate(qFn,
						(1 - discount.getVal() > 0.95 ? 0.95 : discount.getVal()) * bellErr.getVal() / 10);
			}

			int[] tempVars = new int[1];

			tempVars[0] = Global.varNames.length;
			DD newValFn = OP.maxAddVarElim(qFn, tempVars);
			DD diff = OP.abs(OP.sub(newValFn, valFn));

			bellErr = OP.maxAddVarElim(diff, allVar);
			valFn = newValFn;
			firstIteration = false;
			converged = bellErr.getVal() <= tolerance;
		}

		System.out.println("Total # of Iterations: " + iter);
		System.out.println("    bellmanErr = " + bellErr.getVal());
		System.out.println(
				"    valueFn: " + OP.nEdges(valFn) + "edges, " + OP.nNodes(valFn) + "nodes, " + OP.nLeaves(valFn) + "leaves");

		return valFn;
	}

    public void updateReward(String varName, String varValue, double deltaReward)
    {
        // get current reward ADD
        DD currentRewards = m_MDP.reward;
        System.out.println("current rewards:");
        currentRewards.display();

        // find var ID using its name
        int varId = m_MDP.varNames.indexOf(varName);
        System.out.println("varid = " + varId + "; var = " + varName);
        if (varId == -1)
            System.out.println("Not an existing dd nor an existing variable");

        // get information about values of this var
        Vector varValNames = (Vector)m_MDP.valNames.get(varId);
        System.out.println("valsize = " + varValNames.size());

        // create children leaves and init them to 0
        DD[] children = new DD[varValNames.size()];
        for (int i = 0; i < children.length; i++)
        {
                children[i] = DD.zero;
        }

        // find the value ID of which the reward is changed
        int valId = varValNames.indexOf(varValue);
        System.out.println("valid = " + valId + "; val = " + varValue);
        children[valId] = DDleaf.myNew(deltaReward);

        // create this updater add, in which all other values having
        // delta value = 0 and the target value having delta value =
        // deltaReward
        DD updaterADD = DDnode.myNew(varId+1,children);
        System.out.println("updater ADD:");
        updaterADD.display();

        // compute currentRewards+updaterADD, the ADD operation
        // will correctly generate desired ADD
        currentRewards = OP.add(currentRewards, updaterADD);

        System.out.println("updated rewards:");
        currentRewards.display();

        // update the reward ADD in the existing MDP object
        m_MDP.reward = currentRewards;
    }

	// Edited by Derek - Accounts for the "display()" fcn to return a string.
	// This is called separately here rather than in "valueIteration()" and
	// is dumped to the command line;
	public void run(String filename)
	{
		m_MDP = new ParseSPUDD(filename);
		m_MDP.parsePOMDP(true);
		m_valueFn = valueIteration(m_MDP.isPlanEvaluation());

		//System.out.println(m_valueFn.display());
	}

	// Edited by Derek - This fcn is to allow parsing of a String directly,
	// and prevents the use of an input file.  Additionally, it returns
	// the text output from "display()" rather than dumping it to the
	// command line.
	public String run(String input, boolean noFile)
	{
		m_MDP = new ParseSPUDD(input, noFile);
		m_MDP.parsePOMDP(true);
		m_valueFn = valueIteration(m_MDP.isPlanEvaluation());

		if(m_valueFn == null)
		{
			return "";
		}

		return m_valueFn.display();
	}

	public DD getValueFn()
	{
		return m_valueFn;
	}
}

