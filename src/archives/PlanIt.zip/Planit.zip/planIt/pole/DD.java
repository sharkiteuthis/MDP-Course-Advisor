package planIt.pole;


import java.io.Serializable;


abstract class DD implements Serializable
{
	public static DD one = DDleaf.myNew(1);
	public static DD zero = DDleaf.myNew(0);

	protected int var;

	public int getVar()
	{
		return var;
	}

	public int getAddress()
	{
		return super.hashCode();
	}

	public DD[] getChildren()
	{
		return null;
	}  // should throw exception

	public double getVal()
	{
		return Double.NEGATIVE_INFINITY;
	}  // should throw exception

	public int[][] getConfig()
	{
		return null;
	}  // should throw exception

	// Edited by Derek - Now returns a String instead of writing to command line.
	// This was done to allow the string to be tokenized and parsed by PlanIt
	// without requiring a temporary file.
	public String display()
	{
		return display("");
	}

	// Edited by Derek - Now returns a String instead of writing to command line.
	abstract public String display(String space);

	abstract public String display(String space, String prefix);

	abstract public int getNumLeaves();

	// abstract public SortedSet getScope();
	abstract public int[] getVarSet();

	abstract public DD store();

	public static DD cast(DDleaf leaf)
	{
		return (DD) leaf;
	}

	public static DD cast(DDnode node)
	{
		return (DD) node;
	}
}

