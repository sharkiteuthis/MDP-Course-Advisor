package planIt.pole;


class MyDoubleArray
{

	public double[] doubleArray;

	public MyDoubleArray(double[] doubleArray)
	{
		this.doubleArray = doubleArray;
	}
}

