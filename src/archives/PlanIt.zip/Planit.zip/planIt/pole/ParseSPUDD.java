package planIt.pole;


import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.io.StreamTokenizer;
import java.io.StringReader;
import java.util.Vector;


class ParseSPUDD
{
	private HashMap existingDds;
	private StreamTokenizer stream;

	public Vector varNames;
	public Vector valNames;
	public Vector actNames;
	// added by Lengning --- Oct. 11, 2005
	public Vector actTransitions; // if (!m_bPlanEvaluation) then cpts are in dual action diagram form
	// else cpts are the original cpts
	// end --- Oct. 11, 2005
	public Vector actObserve;
	public Vector actCosts;
	// added by Lengning --- Oct. 11, 2005
	public Vector policyActTransitions; // stores the cpts for a policy, only one element!!!
	// end --- Oct. 11, 2005
	public DD reward;
	public DD init;
	public DD discount;
	public DD tolerance;
	public DD horizon;
	public boolean unnormalized;
	// added by Lengning --- Oct. 11, 2005
	protected boolean m_bPlanEvaluation;
	// end --- Oct. 11, 2005
	public int nStateVars;
	public int nObsVars;

	// Added by Derek - This allows input via a String rather than a file.
	public ParseSPUDD(String input, Boolean isString)
	{
		initialize();

		stream = new StreamTokenizer(new StringReader(input));
		stream.wordChars('\'', '\'');
		stream.wordChars('_', '_');
	}

	public ParseSPUDD(String fileName)
	{
		initialize();

		try
		{
			stream = new StreamTokenizer(new FileReader(fileName));
		}

		catch (FileNotFoundException e)
		{
			System.err.println("Error: file not found\n");
			System.exit(1);
		}

		stream.wordChars('\'', '\'');
		stream.wordChars('_', '_');
	}

	// Added by Derek - This is to remove repetition within the constructors
	public void initialize()
	{
		existingDds = new HashMap();
		varNames = new Vector();
		valNames = new Vector();
		actNames = new Vector();
		actTransitions = new Vector();
		policyActTransitions = new Vector(1);
		actObserve = new Vector();
		actCosts = new Vector();
		discount = null;
		tolerance = null;
		horizon = null;
		init = DD.one;
		reward = DD.zero;
		unnormalized = false;
		m_bPlanEvaluation = false;
		nStateVars = 0;
		nObsVars = 0;
	}

	private void error(int id)
	{
		System.err.println("Parse error at line #" + stream.lineno());
		// if (stream.ttype > 0)
		// System.err.println("ttype = " + Character('a'));
		/* else */ System.err.println("ttype = " + stream.ttype);
		System.err.println("sval = " + stream.sval);
		System.err.println("nval = " + stream.nval);
		System.err.println("ID = " + id);
		System.exit(1);
	}

	private void error(String errorMessage)
	{
		System.err.println("Parse error at " + stream.toString() + ": " + errorMessage);
		System.exit(1);
	}

	public void parsePOMDP(boolean fullyObservable)
	{
		try
		{
			boolean primeVarsCreated = false;

			while (true)
			{
				if (!primeVarsCreated && nStateVars > 0 && (fullyObservable || nObsVars > 0))
				{
					primeVarsCreated = true;
					createPrimeVars();
				}

				stream.nextToken();
				switch (stream.ttype)
				{
				case '(':
					stream.nextToken();
					if (stream.sval.compareTo("variables") == 0)
					{
						parseVariables();
					}

					else if (stream.sval.compareTo("observations") == 0)
					{
						parseObservations();
					}

					else
					{
						error("Expected \"variables\" or \"observations\"");
					}

					break;

				case StreamTokenizer.TT_WORD:
					if (stream.sval.compareTo("unnormalized") == 0)
					{
						unnormalized = true;
						break;
					}

					else if (stream.sval.compareTo("planevaluation") == 0)
					{
						m_bPlanEvaluation = true;
						break;
					}

					else if (stream.sval.compareTo("dd") == 0)
					{
						parseDDdefinition();
						break;
					}

					else if (stream.sval.compareTo("action") == 0)
					{
						parseAction();
						break;
					}

					// added by Lengning --- Oct. 10, 2005
					// To parse a policy
					else if (stream.sval.compareTo("policy") == 0)
					{
						parsePolicy();
						break;
					}

					// end --- Oct. 10, 2005
					else if (stream.sval.compareTo("reward") == 0)
					{
						parseReward();
						break;
					}

					else if (stream.sval.compareTo("discount") == 0)
					{
						parseDiscount();
						break;
					}

					else if (stream.sval.compareTo("horizon") == 0)
					{
						parseHorizon();
						break;
					}

					else if (stream.sval.compareTo("tolerance") == 0)
					{
						parseTolerance();
						break;
					}

					else if (stream.sval.compareTo("init") == 0)
					{
						parseInit();
						break;
					}

					error("Expected \"unnormalized\" or \"dd\" or \"action\" or \"reward\"");

				case StreamTokenizer.TT_EOF:

					// set valNames for actions
					String[] actNamesArray = new String[actNames.size()];

					for (int actId = 0; actId < actNames.size(); actId++)
					{
						actNamesArray[actId] = (String) actNames.get(actId);
					}

					Global.setValNames(Global.valNames.length + 1, actNamesArray);

					// set varDomSize with extra action variable
					int[] varDomSizeArray = new int[Global.varDomSize.length + 1];

					for (int varId = 0; varId < Global.varDomSize.length; varId++)
					{
						varDomSizeArray[varId] = Global.varDomSize[varId];
					}

					varDomSizeArray[varDomSizeArray.length - 1] = actNamesArray.length;
					Global.setVarDomSize(varDomSizeArray);
					return;

				default:
					error(3);
				}
			}

		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}
	}

	public void parseVariables()
	{
		try
		{
			while (true)
			{
				if (stream.nextToken() == '(')
				{
					if (StreamTokenizer.TT_WORD != stream.nextToken())
					{
						error("Expected a variable name");
					}

					if (varNames.contains(stream.sval))
					{
						error("Duplicate variable name");
					}

					varNames.add(stream.sval);
					Vector varValNames = new Vector();

					while (true)
					{
						if (StreamTokenizer.TT_WORD == stream.nextToken())
						{
							if (varValNames.contains(stream.sval))
							{
								error("Duplicate value name");
							}

							varValNames.add(stream.sval);
						}

						else if (stream.ttype == ')')
						{
							break;
						}

						else
						{
							error(4);
						}
					}

					valNames.add(varValNames);
					nStateVars++;
				}

				else if (stream.ttype == ')')
				{
					break;
				}

				else
				{
					error("");
				}
			}
		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}
	}

	public void createPrimeVars()
	{
		// create prime variables
		int nVars = varNames.size();

		for (int i = 0; i < nVars; i++)
		{
			varNames.add((String) varNames.get(i) + "'");
			valNames.add((Vector) valNames.get(i));
		}

		// set Global.varNames
		String[] varNamesArray = new String[varNames.size() + 1];

		for (int i = 0; i < varNames.size(); i++)
		{
			varNamesArray[i] = (String) varNames.get(i);
		}

		varNamesArray[varNames.size()] = new String("action");
		Global.setVarNames(varNamesArray);

		// set Global.valNames and Global.varDomSize
		int[] varDomSize = new int[valNames.size()];

		for (int i = 0; i < valNames.size(); i++)
		{
			Vector varValNames = (Vector) valNames.get(i);

			varDomSize[i] = varValNames.size();
			String[] varValNamesArray = new String[varValNames.size()];

			for (int j = 0; j < varValNames.size(); j++)
			{
				varValNamesArray[j] = (String) varValNames.get(j);
			}

			Global.setValNames(i + 1, varValNamesArray);
		}

		Global.setVarDomSize(varDomSize);

		// create SAMEvariable dds
		for (int varId = 0; varId < Global.varNames.length / 2; varId++)
		{
			String ddName = new String("SAME") + Global.varNames[varId];
			DD[] children = new DD[Global.varDomSize[varId]];

			for (int i = 0; i < Global.varDomSize[varId]; i++)
			{
				DD[] grandChildren = new DD[Global.varDomSize[varId]];

				for (int j = 0; j < Global.varDomSize[varId]; j++)
				{
					if (i == j)
					{
						grandChildren[j] = DD.one;
					}

					else
					{
						grandChildren[j] = DD.zero;
					}
				}

				children[i] = DDnode.myNew(varId + 1, grandChildren);
			}
			DD dd = DDnode.myNew(varId + 1 + Global.varNames.length / 2, children);

			existingDds.put(ddName, dd);
		}

		// create variablevalue dds
		for (int varId = 0; varId < Global.varNames.length / 2; varId++)
		{
			for (int valId = 0; valId < Global.varDomSize[varId]; valId++)
			{
				String ddName = Global.varNames[varId] + Global.valNames[varId][valId];
				DD[] children = new DD[Global.varDomSize[varId]];

				for (int i = 0; i < Global.varDomSize[varId]; i++)
				{
					if (valId == i)
					{
						children[i] = DD.one;
					}

					else
					{
						children[i] = DD.zero;
					}
				}
				DD dd = DDnode.myNew(varId + 1 + Global.varNames.length / 2, children);

				existingDds.put(ddName, dd);
			}
		}
	}

	public void parseObservations()
	{
		try
		{
			while (true)
			{
				if (stream.nextToken() == '(')
				{
					if (StreamTokenizer.TT_WORD != stream.nextToken())
					{
						error("Expected a variable name");
					}

					if (varNames.contains(stream.sval))
					{
						error("Duplicate variable name");
					}

					varNames.add(stream.sval);
					Vector varValNames = new Vector();

					while (true)
					{
						if (StreamTokenizer.TT_WORD == stream.nextToken())
						{
							if (varValNames.contains(stream.sval))
							{
								error("Duplicate value name");
							}

							varValNames.add(stream.sval);
						}

						else if (stream.ttype == ')')
						{
							break;
						}

						else
						{
							error(4);
						}
					}

					valNames.add(varValNames);
					nObsVars++;
				}

				else if (stream.ttype == ')')
				{
					break;
				}

				else
				{
					error("");
				}
			}
		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}
	}

	public void parseDDdefinition()
	{
		try
		{
			if (StreamTokenizer.TT_WORD != stream.nextToken())
			{
				error("Expected a dd name");
			}
			String ddName = stream.sval;

			if (existingDds.get(ddName) != null)
			{
				error("Duplicate dd name");
			}
			DD dd = parseDD();

			existingDds.put(ddName, dd);
			stream.nextToken();
			if (stream.sval.compareTo("enddd") != 0)
			{
				error("Expected \"enddd\"");
			}
		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}
	}

	public DD parseDD()
	{
		DD dd = null;

		try
		{
			// parse DD
			if (stream.nextToken() == '(')
			{

				// parse DDnode
				if (StreamTokenizer.TT_WORD == stream.nextToken())
				{

					// existingDd
					dd = (DD) existingDds.get(stream.sval);
					if (dd != null)
					{
						if (stream.nextToken() != ')')
						{
							error("Expected ')'");
						}
					}

					// it's not an existing dd so perhaps it's a variable
					else if (dd == null)
					{
						int varId = varNames.indexOf(stream.sval);

						// System.err.println("varid = " + varId + "; var = " + stream.sval);
						if (varId == -1)
						{
							error("Not an existing dd nor an existing variable");
						}

						// parse values
						Vector varValNames = (Vector) valNames.get(varId);
						DD[] children = new DD[varValNames.size()];

						for (int i = 0; i < children.length; i++)
						{
							children[i] = DD.zero;
						}
						Vector valNamesSoFar = new Vector();

						while (true)
						{
							if (stream.nextToken() == '(')
							{
								stream.nextToken();
								if (valNamesSoFar.contains(stream.sval))
								{
									error("Duplicate child");
								}
								int valId = varValNames.indexOf(stream.sval);

								if (valId == -1)
								{
									error("Invalid value");
								}

								children[valId] = parseDD();
								if (stream.nextToken() != ')')
								{
									error("Expected ')'");
								}
							}

							else if (stream.ttype == ')')
							{
								break;
							}

							else
							{
								error("Expected ')' or '('");
							}
						}

						dd = DDnode.myNew(varId + 1, children);
					}
				}

				// parse leaf node
				else if (StreamTokenizer.TT_NUMBER == stream.ttype)
				{
					dd = DDleaf.myNew(stream.nval);
					if (stream.nextToken() != ')')
					{
						error("Expected ')'");
					}
				}

				// Invalid dd
				else
				{
					error("Invalid DDnode or DDleaf");
				}
			}

			// arithmetic operation
			else if (stream.ttype == '[')
			{

				// parse operator
				int operator = stream.nextToken();

				// multiplication
				if (operator == '*')
				{
					dd = DD.one;
					while (stream.nextToken() != ']')
					{
						stream.pushBack();
						DD newDd = OP.reorder(parseDD());

						dd = OP.mult(dd, newDd);
					}
				}

				// addition
				else if (operator == '+')
				{
					dd = DD.zero;
					while (stream.nextToken() != ']')
					{
						stream.pushBack();
						DD newDd = OP.reorder(parseDD());

						dd = OP.add(dd, newDd);
					}
				}

				// normalisation
				else if (operator == '#')
				{
					stream.nextToken();
					int[] vars = new int[1];

					vars[0] = varNames.indexOf(stream.sval) + 1;
					if (vars[0] == 0)
					{
						error("Unknown variable name");
					}
					DD[] dds = new DD[1];

					dds[0] = OP.reorder(parseDD());
					dd = OP.div(dds[0], OP.addMultVarElim(dds, vars));
					if (stream.nextToken() != ']')
					{
						error("Expected ']'");
					}
				}

				else
				{
					error("Expected '*' or '+' or '#'");
				}
			}

		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}

		return dd;
	}

	// added by Lengning --- Oct. 10, 2005
	public DD parsePolicyDD()
	{
		DD dd = null;

		try
		{
			// parse DD
			if (stream.nextToken() == '(')
			{

				// parse DDnode
				if (StreamTokenizer.TT_WORD == stream.nextToken())
				{

					// existingDd
					dd = (DD) existingDds.get(stream.sval);
					if (dd != null)
					{
						if (stream.nextToken() != ')')
						{
							error("Expected ')'");
						}
					}

					// it's not an existing dd so perhaps it's a variable
					else if (dd == null)
					{
						int varId = varNames.indexOf(stream.sval);

						// System.err.println("varid = " + varId + "; var = " + stream.sval);
						if (varId == -1)
						{
							error("Not an existing dd nor an existing variable");
						}

						// parse values
						Vector varValNames = (Vector) valNames.get(varId);
						DD[] children = new DD[varValNames.size()];

						for (int i = 0; i < children.length; i++)
						{
							children[i] = DD.zero;
						}
						Vector valNamesSoFar = new Vector();

						while (true)
						{
							if (stream.nextToken() == '(')
							{
								stream.nextToken();
								if (valNamesSoFar.contains(stream.sval))
								{
									error("Duplicate child");
								}
								int valId = varValNames.indexOf(stream.sval);

								if (valId == -1)
								{
									error("Invalid value");
								}

								children[valId] = parsePolicyDD();
								if (stream.nextToken() != ')')
								{
									error("Expected ')'");
								}
							}

							else if (stream.ttype == ')')
							{
								break;
							}

							else
							{
								error("Expected ')' or '('");
							}
						}

						dd = DDnode.myNew(varId + 1, children);
					}
				}

				// parse leaf node
				else if (StreamTokenizer.TT_NUMBER == stream.ttype)
				{
					dd = DDleaf.myNew(stream.nval);
					if (stream.nextToken() != ')')
					{
						error("Expected ')'");
					}
				}

				// Invalid dd
				else
				{
					error("Invalid DDnode or DDleaf");
				}
			}

			// arithmetic operation
			else if (stream.ttype == '[')
			{

				// parse operator
				int operator = stream.nextToken();

				// multiplication
				if (operator == '*')
				{
					dd = DD.one;
					while (stream.nextToken() != ']')
					{
						stream.pushBack();
						DD newDd = OP.reorder(parsePolicyDD());

						dd = OP.mult(dd, newDd);
					}
				}

				// addition
				else if (operator == '+')
				{
					dd = DD.zero;
					while (stream.nextToken() != ']')
					{
						stream.pushBack();
						DD newDd = OP.reorder(parsePolicyDD());

						dd = OP.add(dd, newDd);
					}
				}

				// normalisation
				else if (operator == '#')
				{
					stream.nextToken();
					int[] vars = new int[1];

					vars[0] = varNames.indexOf(stream.sval) + 1;
					if (vars[0] == 0)
					{
						error("Unknown variable name");
					}
					DD[] dds = new DD[1];

					dds[0] = OP.reorder(parsePolicyDD());
					dd = OP.div(dds[0], OP.addMultVarElim(dds, vars));
					if (stream.nextToken() != ']')
					{
						error("Expected ']'");
					}
				}

				else
				{
					error("Expected '*' or '+' or '#'");
				}
			}

		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}

		return dd;
	}

	// end --- Oct. 10, 2005

	// added by Lengning --- Oct. 10, 2005
	// require that the policy section occurs after all action sections
	public DD generatePolicyDD(DD core, int varId)
	{
		// It is a leaf
		if (core.getVar() == 0)
		{
			int actionName = (int) core.getVal();
			DD[] cpts = (DD[]) actTransitions.get(actionName - 1);

			return cpts[varId];
		}

		DD[] children = core.getChildren();
		DD[] newChildren = new DD[children.length];

		for (int i = 0; i < children.length; i++)
		{
			newChildren[i] = generatePolicyDD(children[i], varId);
		}

		return DDnode.myNew(core.getVar(), newChildren);
	}

	// end --- Oct. 10, 2005

	// Lengning --- Oct. 11, 2005:
	// TODO: Note that plan evaluation case is only finished for fully observable case
	public void parseAction()
	{

		try
		{

			// parse action name
			stream.nextToken();
			if (actNames.contains(stream.sval))
			{
				error("Duplicate action name");
			}

			else
			{
				actNames.add(stream.sval);
			}

			actCosts.add(DD.zero);
			DD[] cpts = new DD[nStateVars];

			// parse cpts
			while (true)
			{
				// endaction
				stream.nextToken();

				if(stream.sval == null)
				{
					System.err.println("Null token");
					break;
				}

				if (stream.sval.compareTo("endaction") == 0)
				{
					break;
				}

				// cost
				else if (stream.sval.compareTo("cost") == 0)
				{
					DD dd = OP.reorder(parseDD());

					actCosts.set(actCosts.size() - 1, dd);
				}

				// observation function
				else if (stream.sval.compareTo("observe") == 0)
				{
					DD[] obsCPTs = new DD[nObsVars];

					while (true)
					{

						// endobserve
						stream.nextToken();
						if (stream.sval.compareTo("endobserve") == 0)
						{
							break;
						}

						// obs cpt
						else
						{
							int varId = varNames.indexOf(stream.sval);

							if (varId < nStateVars || varId >= varNames.size() / 2)
							{
								error("Invalid observation name");
							}

							obsCPTs[varId - nStateVars] = OP.reorder(parseDD());

							// normalize
							DD[] dds = new DD[1];

							dds[0] = obsCPTs[varId - nStateVars];
							int[] vars = new int[1];

							vars[0] = varId + varNames.size() / 2 + 1;
							DD normalizationFactor = OP.addMultVarElim(dds, vars);

							if (unnormalized)
							{
								obsCPTs[varId - nStateVars] = OP.div(obsCPTs[varId - nStateVars], normalizationFactor);
							}

							else if (OP.maxAll(OP.abs(OP.sub(normalizationFactor, DD.one))) > 1e-8)
							{
								error("Unnormalized cpt for " + varNames.get(varId) + "'");
							}
						}
					}

					actObserve.add(obsCPTs);
				}

				// cpt
				else
				{
					int varId = varNames.indexOf(stream.sval);

					if (varId == -1 || varId >= nStateVars)
					{
						error("Invalid variable name");
					}

					cpts[varId] = OP.reorder(parseDD());

					/* commented by Lengning --- Oct. 16: not needed!
					 // if not the plan evaluation case, we build the dual action diagram.
					 // otherwise, we store the original cpts, assuming the input uses the
					 // original cpts!!!
					 if ( !m_bPlanEvaluation )
					 {
					 // added by Lengning --- Oct. 10, 2005
					 // if the cpt is not a dual action diagram, create one
					 // check if the primed var occurs in the cpt
					 int[] varSet = cpts[varId].getVarSet();
					 int[] vars = new int[1];
					 vars[0] = varId + varNames.size()/2+1; // the primed version of this variable

					 // cpt does not have the primed var
					 if (MySet.find(varSet,vars[0]) < 0) {
					 Vector values = (Vector)valNames.get(varId);
					 DD [] diagrams = new DD[values.size()];
					 if ( values.size() == 2 )
					 {
					 diagrams[0] = cpts[varId];
					 diagrams[1] = OP.sub(DD.one,cpts[varId]);
					 cpts[varId] = DDnode.myNew(vars[0], diagrams);
					 }
					 }
					 // end --- Oct. 10, 2005
					 */

					// normalize
					DD[] dds = new DD[1];

					dds[0] = cpts[varId];
					int[] vars = new int[1];

					vars[0] = varId + varNames.size() / 2 + 1;
					DD normalizationFactor = OP.addMultVarElim(dds, vars);

					// System.err.println("vars[0] = " + vars[0] + " normalizationFactor = ");
					// normalizationFactor.display();

					if (unnormalized)
					{
						cpts[varId] = OP.div(cpts[varId], normalizationFactor);
					}

					else if (OP.maxAll(OP.abs(OP.sub(normalizationFactor, DD.one))) > 1e-8)
					{
						error("Unnormalized cpt for " + varNames.get(varId) + "'");
					}
					// } // part of the comment on Oct. 16, 2005
				}
			}

			actTransitions.add(cpts);

		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}
	}

	// added by Lengning --- Oct. 10, 2005
	// does not consider the action costs at this moment. Need to be fixed!
	public void parsePolicy()
	{

		try
		{

			DD[] cpts = new DD[nStateVars];

			// parse policy
			while (true)
			{

				// endpolicy
				stream.nextToken();
				if (stream.sval.compareTo("endpolicy") == 0)
				{
					break;
				}

				DD core = parsePolicyDD();

				for (int varId = 0; varId < nStateVars; varId++)
				{
					cpts[varId] = OP.reorder(generatePolicyDD(core, varId));

					// System.err.println("varId = " + varId);
					// cpts[varId].display();

					/* commented by Lengning --- Oct. 16: not needed!
					 // build the dual action diagram
					 int[] vars = new int[1];
					 vars[0] = varId + varNames.size()/2+1; // varId + 1 == varName
					 DD [] diagrams = new DD[2]; // assuming binary nodes, may be a bug
					 diagrams[0] = cpts[varId];
					 diagrams[1] = OP.sub(DD.one,cpts[varId]);
					 cpts[varId] = DDnode.myNew(vars[0], diagrams);
					 */

					// normalize
					DD[] dds = new DD[1];

					dds[0] = cpts[varId];
					int[] vars = new int[1];

					vars[0] = varId + varNames.size() / 2 + 1; // varId + 1 == varName
					DD normalizationFactor = OP.addMultVarElim(dds, vars);

					// System.err.println("vars[0] = " + vars[0] + " normalizationFactor = ");
					// normalizationFactor.display();

					if (unnormalized)
					{
						cpts[varId] = OP.div(cpts[varId], normalizationFactor);
					}

					else if (OP.maxAll(OP.abs(OP.sub(normalizationFactor, DD.one))) > 1e-8)
					{
						error("Unnormalized cpt for " + varNames.get(varId) + "'");
					}
				}
			}

			policyActTransitions.add(cpts);

		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}
	}

	// end --- Oct. 10, 2005

	public void parseReward()
	{
		reward = OP.add(reward, OP.reorder(parseDD()));
	}

	public void parseInit()
	{
		init = OP.reorder(parseDD());
		int[] vars = new int[nStateVars];

		for (int i = 0; i < nStateVars; i++)
		{
			vars[i] = i + 1;
		}
		DD[] dds = new DD[1];

		dds[0] = init;
		init = OP.div(init, OP.addMultVarElim(dds, vars));
	}

	public void parseDiscount()
	{
		try
		{
			if (stream.nextToken() != StreamTokenizer.TT_NUMBER)
			{
				error("Expected a number");
			}

			discount = DDleaf.myNew(stream.nval);
		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}
	}

	public void parseHorizon()
	{
		try
		{
			if (stream.nextToken() != StreamTokenizer.TT_NUMBER)
			{
				error("Expected a number");
			}

			horizon = DDleaf.myNew(stream.nval);
		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}
	}

	public void parseTolerance()
	{
		try
		{
			if (stream.nextToken() != StreamTokenizer.TT_NUMBER)
			{
				error("Expected a number");
			}

			tolerance = DDleaf.myNew(stream.nval);
		}

		catch (IOException e)
		{
			System.err.println("Error: IOException\n");
			System.exit(1);
		}
	}

	public static void main(String args[])
	{
		ParseSPUDD file = new ParseSPUDD("/h/23/ppoupart/projects/coach/mdpVI+ADDs/coffee.txt");

		file.parsePOMDP(true);
	}

	public boolean isPlanEvaluation()
	{
		return m_bPlanEvaluation;
	}
}

