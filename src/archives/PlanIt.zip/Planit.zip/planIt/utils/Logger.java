package planIt.utils;

import java.io.*;
import java.util.*;
import planIt.data.*;

public class Logger {
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;
    
	// logging method
	public static void log_data (String input)
	{
		Date d1 = new Date();
		String path = ""; // default directory for logger file
		
		try
    	{
    		FileWriter fout = new FileWriter(path + "runlog.txt", true); // append mode 
    		fout.write(d1.toString() + " : " + Globals.username + " : " + input + "\n");
    		fout.close();
    	}
    	catch (Exception e)
    	{
    		System.out.println("File saving error");
    	}
	}
}
