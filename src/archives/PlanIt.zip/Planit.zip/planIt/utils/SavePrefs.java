package planIt.utils;


// Java Packages
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.tree.DefaultMutableTreeNode;

import planIt.data.Globals;


public class SavePrefs
{
	JFileChooser fc;
	XMLFilter filter;
	File file;

	public SavePrefs(DefaultMutableTreeNode prefs)
	{
		fc = new JFileChooser(Globals.codeBase.getPath().replace("%20", " ") + "XML");
		filter = new XMLFilter();

		fc.setFileFilter(filter);
		fc.setFileSelectionMode(JFileChooser.FILES_AND_DIRECTORIES);

		int val = fc.showSaveDialog(Globals.tabs);

		if (val == JFileChooser.APPROVE_OPTION)
		{
			file = fc.getSelectedFile();

			if (file.exists())
			{
				int selection = JOptionPane.showConfirmDialog(Globals.frame, "This file already exists, overwrite it?",
						"Warning", JOptionPane.YES_NO_OPTION);

				if (selection == 1)
				{
					return;
				}
			}
		}
	}
}

