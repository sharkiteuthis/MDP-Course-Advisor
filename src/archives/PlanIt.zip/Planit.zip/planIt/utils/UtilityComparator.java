package planIt.utils;


// Java packages
import java.util.Comparator;

import planIt.planScan.data.State;


/**
 * Custom comparator used to order states by preference
 */
public class UtilityComparator implements Comparator<State>
{
	public UtilityComparator()
	{}

	/**
	 * Compares two states based on their probability of occuring.
	 * @return 1 if the first state is less likely to occur and a -1 if the second
	 * state is less likely to occur.  If both states have an equal chance of
	 * occuring, the prefereces on the two states are compared.  In this case, a
	 * 1 is returned is the first state has less utility, and a -1 if the second
	 * state has less utility.  If both the probability and utility are equal, a
	 * 0 is returned.
	 */
	public int compare(State s1, State s2)
	{
		double result = s1.getUtility() - s2.getUtility();

		if (result < 0)
		{
			return 1;
		}

		else if (result > 0)
		{
			return -1;
		}

		else
		{
			result = s1.getProbability() - s2.getProbability();

			if (result < 0)
			{
				return 1;
			}

			else if (result > 0)
			{
				return -1;
			}
		}

		return 0;
	}
}

