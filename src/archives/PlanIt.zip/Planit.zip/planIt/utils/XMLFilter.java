package planIt.utils;


import java.io.File;

import javax.swing.filechooser.FileFilter;


public class XMLFilter extends FileFilter
{

	/**
	 * Returns true if the input file has an "xml" extension or is a directory
	 */
	public boolean accept(File f)
	{
		String extension = getExtension(f);

		if (f.isDirectory() || extension.equals("xml"))
		{
			return true;
		}

		return false;
	}

	/**
	 * Get the extension of a file.
	 */
	public static String getExtension(File f)
	{
		String ext = null;
		String s = f.getName();

		int i = s.lastIndexOf('.');

		if (i > 0 && i < s.length() - 1)
		{
			ext = s.substring(i + 1).toLowerCase();
		}

		return ext;
	}

	/**
	 * The description of this filter
	 */
	public String getDescription()
	{
		return "XML files";
	}
}

