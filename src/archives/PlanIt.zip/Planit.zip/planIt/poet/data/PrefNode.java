package planIt.poet.data;


// Local packages
import planIt.data.Attribute;
import planIt.data.Value;


public class PrefNode // Defines values in archetypes
{
	public Attribute 	attribute;
	public Value 		value; // The parent value

	public PrefNode()
	{
		attribute = null;
		value = null;
	}

	public String toString()
	{
		return value.toString();
	}

	public Value getValue()
	{
		return value;
	}

	public Attribute getAttribute()
	{
		return attribute;
	}

	public void setAttribute(Attribute attribute)
	{
		this.attribute = attribute;
	}

	public void setValue(Value value)
	{
		this.value = value;
	}

	public PrefNode clone()
	{
		PrefNode node = new PrefNode();

		node.attribute = attribute;
		node.value = value;

		return node;
	}
}

