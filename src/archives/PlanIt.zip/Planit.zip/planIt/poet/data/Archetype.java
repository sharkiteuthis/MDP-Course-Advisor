package planIt.poet.data;




public class Archetype // Defines Archetype Object
{
	public String name;
	public String description;

	public Archetype()
	{
		name = new String();
		description = new String();
	}

	public String toString()
	{
		return name;
	}

	public String getName()
	{
		return name;
	}

	public String getDescription()
	{
		return description;
	}

	public Archetype clone()
	{
		Archetype arch = new Archetype();

		arch.name = name;
		arch.description = description;

		return arch;
	}
}

