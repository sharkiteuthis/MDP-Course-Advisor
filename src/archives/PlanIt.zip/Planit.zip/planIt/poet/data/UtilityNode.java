package planIt.poet.data;


// Local packages


public class UtilityNode extends PrefNode // Defines values in archetypes
{
	public double utility;

	public UtilityNode()
	{
		value = null;
		utility = 0;
	}

	public double getUtility()
	{
		return utility;
	}

	public void setUtility(double utility)
	{
		if (utility < -1 || utility > 1)
		{
			System.err.println("Utility can't be greather than 1 or less than -1");
			return;
		}

		this.utility = utility;
	}

	public UtilityNode clone()
	{
		UtilityNode node = new UtilityNode();

		node.utility = utility;
		node.attribute = attribute;
		node.value = value;

		return node;
	}
}

