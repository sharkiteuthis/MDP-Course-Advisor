package planIt.poet.gui;


import java.awt.Color;
import java.util.Hashtable;

import javax.swing.JLabel;
import javax.swing.JSlider;


public class PrefSlider extends JSlider
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private Hashtable<Integer, JLabel> 	labels;
	private static int					max = 12;
	private static int 					min = 0;
	private static int					minorSpacing = 1;
	private static int					majorSpacing = 3;

	public PrefSlider(double init)
	{
		setMinimum(min);
		setMaximum(max);
		setInverted(true);

		setValue((int) ((max - min) * ((init + 1) / 2)));

		setMajorTickSpacing(majorSpacing);
		setMinorTickSpacing(minorSpacing);
		setPaintTicks(true);

		// Construct slider labels
		labels = new Hashtable<Integer, JLabel>();
		labels.put(new Integer(min), new JLabel("Can't Have"));
		labels.put(new Integer(majorSpacing), new JLabel("Oppose"));
		labels.put(new Integer(majorSpacing * 2), new JLabel("Indifferent"));
		labels.put(new Integer(majorSpacing * 3), new JLabel("Prefer"));
		labels.put(new Integer(max), new JLabel("Must Have"));

		// Set slider attributes
		setLabelTable(labels);
		setPaintLabels(true);
		setSnapToTicks(true);
		setInverted(true);

		// Set slider display size and background color
		// setPreferredSize(new Dimension(350, 100));
		setBackground(Color.white);
	}

	public double getUtility()
	{
		double value = getValue();
		double range = max - min;

		return (((value / range) * 2) - 1);
	}

	public int getMax()
	{
		return max;
	}

	public int getMin()
	{
		return min;
	}

	public int getMinorSpacing()
	{
		return minorSpacing;
	}

	public int getMajorSpacing()
	{
		return majorSpacing;
	}
}

