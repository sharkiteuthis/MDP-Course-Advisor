package planIt.poet.gui;


// Java Packages
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.tree.DefaultMutableTreeNode;

import planIt.data.Attribute;
import planIt.data.Value;
import planIt.poet.data.PrefNode;
import planIt.poet.data.UtilityNode;


/**
 * A panel that gives more detailed information about a node.
 * @param prefNode The user data from the node about which the pane gives information.
 * @param label The UI component which gives the description of the node.
 * @param node The node containing the user data and tree data.
 * @param icon An icon for the detail pane.
 * @param buttonPanel A panel for laying out buttons.
 * @param addButton A button for adding a new tree node.
 * @param removeButton A button for removing the current node.
 * @param parent The parent UI component.
 */
public class NodePanel extends JPanel implements ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private PrefNode 				prefNode;
	private JLabel 					label;
	private DefaultMutableTreeNode 	node;
	private ImageIcon 				icon;
	private JPanel 					buttonPanel;
	private JButton					addButton;
	private JButton					removeButton;
	private ElicitationPane			parent;

	/**
	 * Creates a new panel based on the node and the parent UI element.
	 * @param node The node containing the data for this pane.
	 * @param parent The parent UI element.
	 */
	public NodePanel(DefaultMutableTreeNode node, ElicitationPane parent)
	{
		this.node = node;
		this.parent = parent;

		prefNode = (PrefNode) node.getUserObject();
		icon = new ImageIcon("resources/gears.png");
		label = new JLabel(buildDescription(), icon, JLabel.CENTER);

		addButton = new JButton("Add Dependency");
		addButton.addActionListener(this);
		removeButton = new JButton("Remove This");
		removeButton.addActionListener(this);

		buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));
		buttonPanel.setBackground(Color.white);
		buttonPanel.add(addButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(15, 0)));
		buttonPanel.add(removeButton);

		// Set the layout, margins, and background color
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Top, left, bottom, right
		setBackground(Color.white);

		// Note - JLabels must be centered both in the layout and in the label space
		label.setHorizontalAlignment(JLabel.CENTER);
		label.setAlignmentX(Component.CENTER_ALIGNMENT);

		// Add objects to the pane, including spacers
		add(label);
		add(Box.createRigidArea(new Dimension(0, 50)));
		add(buttonPanel);
	}

	/**
	 * Build a string description of the preference tree node.
	 * @return A <code>String</code> that is the complete description of the node.
	 */
	public String buildDescription()
	{
		String description = new String();
		String condition = new String();
		String prefValue = new String();
		PrefNode tempVal = prefNode;
		DefaultMutableTreeNode tempNode = node;

		// Construct node description
		// description = "<html><font size=4>Attribute: <b>" + val.parent.name + "</b><br>";
		// description += "Value: <b>" + val.value.name + "</b><br><br>";
		description += "<html><font size=4>Condition: ";

		// Reverse parse the tree in reverse to build description
		while (!tempNode.isRoot())
		{
			tempVal = (PrefNode) tempNode.getUserObject();

			if (((DefaultMutableTreeNode) tempNode.getParent()).isRoot())
			{
				prefValue = tempVal.value.description;
			}

			else
			{
				condition += tempVal.value.description + " and ";
			}

			tempNode = (DefaultMutableTreeNode) tempNode.getParent();
		}

		// Correct capitalization, remove trailing " and", add period, close html
		if (condition.equals(""))
		{
			condition = "None";
		}

		else
		{
			condition = condition.substring(0, 1).toUpperCase()
					+ condition.substring(1, condition.length() - 5).toLowerCase();
		}

		description += condition + ".<br><br>";
		description += "Prefence Value: <b>" + prefValue + "</b>.</font></html>";

		return description;
	}

	/**
	 * Catches actions on the add and remove buttons.
	 * @param e An action event.
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == addButton)
		{
			DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) node.getFirstChild();
			Attribute attr = ((PrefNode) treeNode.getUserObject()).getAttribute();
			Value[] values = allowedValues(attr);
			UtilityNode utilityNode = null;
			Value value = null;

			if (values.length == 0)
			{
				JOptionPane.showMessageDialog(parent, "There are no more values that can be added to this node.");
				return;
			}

			value = (Value) JOptionPane.showInputDialog(parent, "Now choose the value:", "Add Dependency",
					JOptionPane.PLAIN_MESSAGE, null, values, values[0]);

			if (value == null)
			{
				return;
			}

			utilityNode = new UtilityNode();
			utilityNode.setAttribute(attr);
			utilityNode.setValue(value);

			treeNode = new DefaultMutableTreeNode();
			treeNode.setUserObject(utilityNode);

			node.add(treeNode);

			parent.update(treeNode);
		}

		else if (e.getSource() == removeButton)
		{
			DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) node.getParent();
			UtilityNode utilityNode = null;

			if (!treeNode.isRoot())
			{
				utilityNode = new UtilityNode();
				prefNode = (PrefNode) treeNode.getUserObject();
				utilityNode.setAttribute(prefNode.getAttribute());
				utilityNode.setValue(prefNode.getValue());
				utilityNode.setUtility(0);
				treeNode.setUserObject(utilityNode);
			}

			node.removeFromParent();
			parent.update(treeNode);
		}
	}

	/**
	 * Generates an array of values that are allowed to be added based on the
	 * given attribute and current branch values.  A value can exist only once
	 * in a branch (it cannot depend on itself).  Additionally, a node can only
	 * have a value as a child once.
	 * @param attr The attribute whose values are being checked.
	 * @return An array of all allowable values for the given attribute and
	 * current branch.
	 */
	public Value[] allowedValues(Attribute attr)
	{
		ArrayList<Value> values = new ArrayList<Value>(attr.values.values());
		Value[] result = null;
		DefaultMutableTreeNode current = node;
		PrefNode temp = null;

		// Check the path up to the root, one node at a time
		while (current != null && !current.isRoot())
		{
			if (current.getUserObject() instanceof PrefNode)
			{
				temp = (PrefNode) current.getUserObject();

				// if the attribute and value match, remove it from the list
				if (temp.getAttribute().getName().equals(attr.getName())
						&& attr.values.get(temp.getValue().getName()) != null)
				{
					values.remove(temp.getValue());
				}
			}

			current = (DefaultMutableTreeNode) current.getParent();
		}

		// Remove all children of this node as possibilities
		for (Enumeration e = node.children(); e.hasMoreElements();)
		{
			current = (DefaultMutableTreeNode) e.nextElement();

			if (current.getUserObject() instanceof PrefNode)
			{
				temp = (PrefNode) current.getUserObject();
				values.remove(temp.getValue());
			}

			current = (DefaultMutableTreeNode) current.getParent();
		}

		result = new Value[values.size()];
		values.toArray(result);

		return result;
	}
}

