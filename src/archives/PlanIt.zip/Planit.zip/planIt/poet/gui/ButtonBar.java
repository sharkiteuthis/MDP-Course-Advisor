package planIt.poet.gui;


import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JToolTip;

import planIt.data.Globals;
import planIt.parsers.SPUDDPlanParser;
import planIt.planScan.data.Plan;
import planIt.planScan.gui.PlanPanel;
import planIt.pole.CPlanner;
import planIt.utils.Logger;
import planIt.utils.SwingWorker;


public class ButtonBar extends JPanel implements ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private PickArch 	parent;

	private JButton 	planButton;
	private JButton 	archButton;
	private JButton 	resetButton;
	private JToolTip 	planButtonToolTip;
	private JToolTip 	archButtonToolTip;
	private JToolTip 	resetButtonToolTip;
	private ProgressBar progressBar;

	/**
	 * Create a new <code>ButtonBar</code>.
	 * @param parent The parent component.
	 */
	public ButtonBar(PickArch parent)
	{
		this.parent = parent;

		setBorder(
				BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(96, 146, 255)),
				BorderFactory.createEmptyBorder(2, 5, 2, 5)));

		// Initialize static buttons and their tooltips
		planButton = new JButton("<html><font size=4><b>Create Plan</b></font></html>");
		planButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		planButton.setMinimumSize(new Dimension(160, 26));
		planButton.setPreferredSize(new Dimension(160, 26));
		planButton.setMaximumSize(new Dimension(160, 26));
		planButton.addActionListener(this);

		planButtonToolTip = new JToolTip();
		planButtonToolTip.setTipText("Use current preferences to create a plan");
		planButtonToolTip.setComponent(planButton);

		archButton = new JButton("<html><font size=4><b>Archetypes</b></font></html>");
		archButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		archButton.setMinimumSize(new Dimension(160, 26));
		archButton.setPreferredSize(new Dimension(160, 26));
		archButton.setMaximumSize(new Dimension(160, 26));
		archButton.addActionListener(this);

		archButtonToolTip = new JToolTip();
		archButtonToolTip.setTipText("Go back to archetype selection");
		archButtonToolTip.setComponent(planButton);

		resetButton = new JButton("<html><font size=4><b>Reset</b></font></html>");
		resetButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		resetButton.setMinimumSize(new Dimension(160, 26));
		resetButton.setPreferredSize(new Dimension(160, 26));
		resetButton.setMaximumSize(new Dimension(160, 26));
		resetButton.addActionListener(this);

		resetButtonToolTip = new JToolTip();
		resetButtonToolTip.setTipText("Remove all the current preferences");
		resetButtonToolTip.setComponent(planButton);

		add(resetButton, BorderLayout.CENTER);
		add(archButton, BorderLayout.CENTER);
		add(planButton, BorderLayout.CENTER);
	}

	/**
	 * Defines actions to be performed on button events.
	 * @param e An action event.
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == planButton)
		{
			long startTime = System.currentTimeMillis();
			
			Worker worker = new Worker();
			progressBar = new ProgressBar(parent, worker);

			worker.start();
			
			Logger.log_data("User action prompts for plan generation");
			
			long stopTime = System.currentTimeMillis();
			System.err.println("planIt.poet.gui" + "\t" + ((stopTime - startTime)/1000.0) + " s");

		}

		else if (e.getSource() == archButton)
		{
			String[] options = { "Continue", "Cancel"};

			int reply = JOptionPane.showOptionDialog(parent,
					"This will reset all of your preferences, are you sure you want to continue?", "Warning",
					JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]);

			// Continue only if the user selects "Continue" in the dialog
			if (reply == 0)
			{
				parent.removeAll();
				parent.add(new PickArch());
				parent.revalidate();
				Logger.log_data("User action prompts for new archetype selection");
			}
		}

		// Reset to the original archetype
		else if (e.getSource() == resetButton)
		{
			String[] options = { "Continue", "Cancel"};

			int reply = JOptionPane.showOptionDialog(parent,
					"This will reset all of your preferences, are you sure you want to continue?", "Warning",
					JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE, null, options, options[0]);

			// Continue only if the user selects "Continue" in the dialog
			if (reply == 0)
			{
				parent.reset();
				Logger.log_data("User action prompts for current archetype reset");
			}
		}
	}

	public Plan plan()
	{
		String planText = "";
		CPlanner planner = new CPlanner();
		SPUDDPlanParser parser = null;

		long startTime = System.currentTimeMillis();
		String tempplan = Globals.add.toSPUDD();
		long stopTime = System.currentTimeMillis();
		System.err.println("planIt.planScan.data" + "\t" + ((stopTime - startTime)/1000.0) + " s");

		try	{
			File file  = new File("add.Dump.txt");
			FileWriter out = new FileWriter(file, false);
			out.write(tempplan);
			out.close();
		} catch(IOException ioe) {};
		
		startTime = System.currentTimeMillis();
		planText = planner.run(tempplan, true);
		stopTime = System.currentTimeMillis();
		System.err.println("planIt.pole" + "\t" + ((stopTime - startTime)/1000.0) + " s");

		startTime = System.currentTimeMillis();
		parser = new SPUDDPlanParser(planText);
		Plan temp = parser.parse();
		stopTime = System.currentTimeMillis();
		System.err.println("planIt.parsers" + "\t" + ((stopTime - startTime)/1000.0) + " s");
		
		return temp;
	}

	public class Worker extends SwingWorker
	{
		public Object construct()
		{
			return plan();
		}

		// Runs on the event-dispatching thread.
		public void finished()
		{
			progressBar.dispose();
			Globals.tabs.addTab("Plan " + (++Globals.planCount), new PlanPanel((Plan)get()));
			Globals.tabs.setSelectedIndex(Globals.tabs.getTabCount() - 1);
		}
	}
}

