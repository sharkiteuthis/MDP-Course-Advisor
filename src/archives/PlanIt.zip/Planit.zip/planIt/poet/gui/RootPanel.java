package planIt.poet.gui;


// Java Packages
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import java.util.Enumeration;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.tree.DefaultMutableTreeNode;

import planIt.data.Attribute;
import planIt.data.Globals;
import planIt.data.Value;
import planIt.poet.data.Archetype;
import planIt.poet.data.PrefNode;
import planIt.poet.data.UtilityNode;
import planIt.utils.Logger;


/**
 * A panel that gives more detailed information about the root node (The archetype).
 * @param arch The archetype represented by the node.
 * @param label The UI component which gives the description of the node.
 * @param node The node containing the user data and tree data.
 * @param icon An icon for the detail pane.
 * @param addButton A button for adding a new tree node.
 * @param parent The parent UI component.
 */
public class RootPanel extends JPanel implements ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private Archetype 				arch;
	private JLabel					label;
	private DefaultMutableTreeNode 	node;
	private ImageIcon 				icon;
	private JButton 				addButton;
	private ElicitationPane			parent;

	/**
	 * Creates a new panel based on the node and the parent UI element.
	 * @param node The node containing the data for this pane.
	 * @param parent The parent UI element.
	 */
	public RootPanel(DefaultMutableTreeNode node, ElicitationPane parent)
	{
		this.node = node;
		this.parent = parent;

		arch = (Archetype) node.getUserObject();

		icon = new ImageIcon("resources/house.png");
		label = new JLabel(buildDescription(), icon, JLabel.CENTER);
		label.setAlignmentX(Component.CENTER_ALIGNMENT);

		addButton = new JButton("Add Preference");
		addButton.addActionListener(this);

		// Set the layout, margins, and background color
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Top, left, bottom, right
		setBackground(Color.white);

		// Add objects to the pane, including spacers
		add(label);
		add(Box.createRigidArea(new Dimension(0, 20)));
		add(addButton);
	}

	/**
	 * Build a string description of the preference tree node.
	 * @return A <code>String</code> that is the complete description of the node.
	 */
	public String buildDescription()
	{
		String description = new String();

		description = "<html><font size=4>Archetype: <b>" + arch.toString() + "</b><br><br>";
		description += "Description: " + arch.description + "</font></html>";

		return description;
	}

	/**
	 * Catches actions on the add and remove buttons.
	 * @param e An action event.
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == addButton)
		{
			Attribute[] attrs = allowedAttributes();
			Value[] values = null;
			DefaultMutableTreeNode treeNode = null;
			UtilityNode utilityNode = null;
			Attribute attr = null;
			Value value = null;

			if (attrs.length == 0)
			{
				JOptionPane.showMessageDialog(parent, "There are no more values that can be added to this node.");
				return;
			}

			attr = (Attribute) JOptionPane.showInputDialog(parent, "Choose an attribute:", "Add an Attribute",
					JOptionPane.PLAIN_MESSAGE, null, attrs, attrs[0]);

			if (attr == null)
			{
				return;
			}

			values = allowedValues(attr);

			value = (Value) JOptionPane.showInputDialog(parent, "Now choose the value:", "Add an Attribute",
					JOptionPane.PLAIN_MESSAGE, null, values, values[0]);

			if (value == null)
			{
				return;
			}

			utilityNode = new UtilityNode();
			utilityNode.setAttribute(attr);
			utilityNode.setValue(value);

			treeNode = new DefaultMutableTreeNode();
			treeNode.setUserObject(utilityNode);

			node.add(treeNode);

			Logger.log_data("User adds new node at root node (" + node.toString() + "). New node (" + utilityNode.getAttribute().toString() + ") at value (" + utilityNode.getValue().toString() + ")");

			parent.update(treeNode);

		}
	}

	/**
	 * Generates an array of attributes that are allowed to be added based on the
	 * given attribute and current branch values.  Although for the root, any
	 * attribute is allowed, the purpose of this function is to pre-check all
	 * attribute values.  If all values for an attribute are present as children
	 * of the root, then selecting that attribute to add would bring up an empty
	 * value selection box.  This function removes such attributes to prevent
	 * this behavior.
	 * @return An array of all allowable attributes for the current branch.
	 */
	public Attribute[] allowedAttributes()
	{
		ArrayList<Attribute> attrs = new ArrayList<Attribute>(Globals.attributes.values());
		Attribute[] result = null;
		DefaultMutableTreeNode current = node;
		PrefNode temp = null;

		for (Enumeration e = node.children(); e.hasMoreElements();)
		{
			current = (DefaultMutableTreeNode) e.nextElement();

			if (current.getUserObject() instanceof PrefNode)
			{
				temp = (PrefNode) current.getUserObject();

				if (allowedValues(temp.getAttribute()).length < 1)
				{
					attrs.remove(temp.getAttribute());
				}
			}

			current = (DefaultMutableTreeNode) current.getParent();
		}

		result = new Attribute[attrs.size()];
		attrs.toArray(result);

		return result;
	}

	/**
	 * Generates an array of values that are allowed to be added based on the
	 * given attribute and current branch values.  A value can exist only once
	 * in a branch (it cannot depend on itself).
	 * @param attr The attribute whose values are being checked.
	 * @return An array of all allowable values for the given attribute and
	 * current branch.
	 */
	public Value[] allowedValues(Attribute attr)
	{
		ArrayList<Value> values = new ArrayList<Value>(attr.values.values());
		Value[] result = null;
		DefaultMutableTreeNode current = node;
		PrefNode temp = null;

		for (Enumeration e = node.children(); e.hasMoreElements();)
		{
			current = (DefaultMutableTreeNode) e.nextElement();

			if (current.getUserObject() instanceof PrefNode)
			{
				temp = (PrefNode) current.getUserObject();

				// if the attribute and value match, remove it from the list
				if (temp.getAttribute().getName().equals(attr.getName())
						&& attr.values.get(temp.getValue().getName()) != null)
				{
					values.remove(temp.getValue());
				}
			}

			current = (DefaultMutableTreeNode) current.getParent();
		}

		result = new Value[values.size()];
		values.toArray(result);

		return result;
	}
}

