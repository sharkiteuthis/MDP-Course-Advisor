package planIt.poet.gui;


// Java packages
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;
import java.util.Enumeration;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JEditorPane;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListSelectionModel;
import javax.swing.border.TitledBorder;
import javax.swing.event.HyperlinkEvent;
import javax.swing.event.HyperlinkListener;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;

import planIt.data.Globals;
import planIt.gui.CloseableTabbedPaneListener;
import planIt.poet.data.Archetype;
import planIt.poet.data.PrefNode;
import planIt.poet.data.UtilityNode;
import planIt.utils.Logger;


public class PickArch extends JPanel implements HyperlinkListener, ListSelectionListener, ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private JPanel 					leftPanel;
	private JEditorPane 			credits;
	private JScrollPane 			scrollPane;
	private JList 					archJList;
	private JScrollPane 			listScroll;
	private JButton 				continueButton;
	private JButton					homeButton;
	private JPanel					buttonPanel;
	private HelpPane 				helpPane;
	private DefaultMutableTreeNode 	selection;

	public PickArch() // DISPLAYS LIST OF ARCHS FOR CHOOSING
	{
		Globals.tabs.addCloseableTabbedPaneListener(new TabListener());

		setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		credits = new JEditorPane();
		helpPane = new HelpPane(
				"<html><font size=4><b><p align=center> Click on the <i>Continue</i> button to begin preference elicitation. <br>You should read through the entire tutorial first so you know what to expect.<br>If you need help later on, a box will display information on whatever the mouse cursor is pointing at.</font></b></html>");

		scrollPane = new JScrollPane(credits);
		scrollPane.setBorder(BorderFactory.createLineBorder(new Color(96, 146, 255)));

		leftPanel = new JPanel();
		leftPanel.setBorder(
				BorderFactory.createCompoundBorder(
						BorderFactory.createTitledBorder(BorderFactory.createLineBorder(new Color(96, 146, 255)), "Archetypes",
						TitledBorder.CENTER, TitledBorder.TOP, Globals.smallBoldFont),
						BorderFactory.createEmptyBorder(5, 5, 5, 5)));

		try
		{
			credits.setPage(Globals.codeBase + "resources/startup.htm");
			credits.setEditable(false);
			credits.addHyperlinkListener(this);
		}

		catch (IOException e)
		{
			System.err.println("Attempted to read a bad URL: " + Globals.codeBase + "resources/startup.htm");
		}

		archJList = new JList(Globals.archetypes);
		archJList.setFont(Globals.mediumFont);
		archJList.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // Top, left, bottom, right
		archJList.setVisibleRowCount(15);
		archJList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
		archJList.setSelectedIndex(0);
		archJList.addListSelectionListener(this);

		listScroll = new JScrollPane(archJList);

		continueButton = new JButton("Continue");
		continueButton.setFont(Globals.mediumFont);
		continueButton.setBackground(new Color(225, 225, 235));
		continueButton.setToolTipText("Press to begin giving your preferences");
		continueButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		continueButton.addActionListener(this);

		homeButton = new JButton("Home");
		homeButton.setFont(Globals.mediumFont);
		homeButton.setBackground(new Color(255, 255, 235));
		homeButton.setToolTipText("Return to the start screen");
		homeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		homeButton.addActionListener(this);

		buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));
		buttonPanel.add(homeButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(10, 0)));
		buttonPanel.add(continueButton);

		leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.PAGE_AXIS));
		leftPanel.add(listScroll);
		leftPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer
		leftPanel.add(buttonPanel);

		BorderLayout borderLayout = new BorderLayout();

		borderLayout.setHgap(10);
		borderLayout.setVgap(10);
		setLayout(borderLayout);

		add(scrollPane, BorderLayout.CENTER);
		add(leftPanel, BorderLayout.LINE_START);
		add(helpPane, BorderLayout.PAGE_END);
	}

	/**
	 * Update the helpPane when someone begins archtype selection
	 */
	public void valueChanged(ListSelectionEvent e)
	{
		Archetype arch = getSelectedArch();

		if (arch != null)
		{
			helpPane.setHelpText(arch.getDescription());
		}
	}

	/**
	 * Listens for hyperlink selection in the credits and tutorial HTML pages
	 */
	public void hyperlinkUpdate(HyperlinkEvent event) // LISTENER FOR HYPERLINKS IN CREDITS PAGE
	{
		if (event.getEventType() == HyperlinkEvent.EventType.ACTIVATED)
		{
			try
			{
				credits.setPage(event.getURL());
			}

			catch (IOException ioe)
			{
				System.err.println("Can't follow link to " + event.getURL().toExternalForm() + ": " + ioe);
			}
		}
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == continueButton)
		{
			long startTime = System.currentTimeMillis();
			
			selection = (DefaultMutableTreeNode) archJList.getSelectedValue();

			if (selection == null)
			{
				System.err.println("The Node for the selected archetype is null");
				return;
			}

			Logger.log_data("User selects archetype (" + selection.toString() + ")");
			
			// Remove all components
			removeAll();
			setLayout(new BorderLayout());

			// Copy the archetype so it is not edited
			Globals.prefs = copyTree(selection);

			// Add the preference display
			ElicitationPane ePane = new ElicitationPane(Globals.prefs);

			add(ePane, BorderLayout.CENTER);
			add(new ButtonBar(this), BorderLayout.PAGE_END);
			revalidate();
			
			long stopTime = System.currentTimeMillis();
			System.err.println("planIt.poet.gui" + "\t" + ((stopTime - startTime)/1000.0) + " s");
			
		}

		else if (e.getSource() == homeButton)
		{
			// Back to splash screen
			Globals.tabs.remove(Globals.tabs.getSelectedIndex());
			Globals.tabs.setSelectedIndex(0);
			Globals.prefIndex = -1;
			Logger.log_data("User returns home from archetype selection");
		}
	}

	/**
	 * Retrieves the archetype represented by the current list selection
	 */
	private Archetype getSelectedArch()
	{
		Archetype arch = null;
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) archJList.getSelectedValue();

		if (node == null)
		{
			return null;
		}

		arch = (Archetype) node.getUserObject();

		return arch;
	}

	/**
	 * Makes a clone, "copy", of a tree rooted at "original".  All children and user objects are cloned.
	 */
	private DefaultMutableTreeNode copyTree(DefaultMutableTreeNode original)
	{
		DefaultMutableTreeNode copy = new DefaultMutableTreeNode();
		DefaultMutableTreeNode child = null;
		Object object = original.getUserObject();

		if (object instanceof UtilityNode)
		{
			copy.setUserObject(((UtilityNode) object).clone());
		}

		else if (object instanceof PrefNode)
		{
			copy.setUserObject(((PrefNode) object).clone());
		}

		else if (object instanceof Archetype)
		{
			copy.setUserObject(((Archetype) object).clone());
		}

		else
		{
			System.err.println("Unknown user object type in preference tree");
		}

		// Enumerate child states and make recursive call to copy them
		for (Enumeration e = original.children(); e.hasMoreElements();)
		{
			child = new DefaultMutableTreeNode();
			child = copyTree((DefaultMutableTreeNode) e.nextElement());
			copy.add(child);
		}

		return copy;
	}

	public void reset()
	{
		if (selection == null)
		{
			System.err.println("There is no recorded archetype selection");
			return;
		}

		// Remove all components
		removeAll();
		setLayout(new BorderLayout());

		// Copy the archetype so it is not edited
		Globals.prefs = copyTree(selection);

		// Add the preference display
		add(new ElicitationPane(Globals.prefs), BorderLayout.CENTER);
		add(new ButtonBar(this), BorderLayout.PAGE_END);

		revalidate();
	}

	public class TabListener implements CloseableTabbedPaneListener
	{
		public boolean closeTab(int tabIndexToClose)
		{
			Globals.prefIndex = -1;
			Logger.log_data("User closes Pick Archetype tab");
			return true;
		}
	}
}

