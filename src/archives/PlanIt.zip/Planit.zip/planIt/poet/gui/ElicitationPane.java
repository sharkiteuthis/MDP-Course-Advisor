package planIt.poet.gui;


import java.awt.Component;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.ScrollPaneConstants;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreePath;

import planIt.data.Globals;
import planIt.poet.data.Archetype;
import planIt.poet.data.PrefNode;
import planIt.poet.data.UtilityNode;
import planIt.utils.Logger;


/**
 * Custom split pane interface with a JTree of the preference tree on the left
 * and a detail pane of the selected node on the right
 * @param tree A GUI tree representation of the preference tree.
 * @param model The tree model for the <code>JTree</code>.
 * @param renderer The <code>JTree</code> cell renderer.
 * @param arch The root of the preference tree.
 * @param leftScroll A scroll pane for the <code>JTree</code> object.
 * @param openIcon A custom icon for expaning <code>JTree</code> branches.
 * @param openIcon A custom icon for collapsing <code>JTree</code> branches.
 * @param openIcon A custom icon for leaves in the <code>JTree</code>.
 */
public class ElicitationPane extends JSplitPane implements TreeSelectionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private JTree 					tree;
	private DefaultTreeModel		model;
	private DefaultTreeCellRenderer renderer;
	private DefaultMutableTreeNode	arch;
	private JScrollPane 			leftScroll;
	private Icon 					openIcon;
	private Icon 					closeIcon;
	private Icon 					leafIcon;

	public ElicitationPane(DefaultMutableTreeNode arch)
	{
		// SAVE THE POINTER TO THE ARCHETYPE BEING USED
		this.arch = arch;

		// Initialization of components
		leftScroll = new JScrollPane();

		openIcon = new ImageIcon("resources/Down.gif");
		closeIcon = new ImageIcon("resources/Forward.gif");
		leafIcon = new ImageIcon("resources/check.gif");

		// SET SCROLLBAR POLICIES: ONLY SHOW IF DISPLAY IS LARGER THAN WINDOW
		leftScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		leftScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
		leftScroll.setMinimumSize(new Dimension(150, 100));

		// Create a custom cell renderer and use custom icons
		renderer = new DefaultTreeCellRenderer();
		renderer.setOpenIcon(null);
		renderer.setClosedIcon(null);
		renderer.setLeafIcon(leafIcon);
		renderer.setFont(Globals.mediumFont);

		// Create the model and gui tree
		model = new DefaultTreeModel(arch);
		tree = new JTree(model);
		tree.setSelectionRow(0);
		tree.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		tree.setCellRenderer(renderer);
		tree.addTreeSelectionListener(this);

		setLeftComponent(leftScroll);
		leftScroll.setViewportView(tree);

		setRightComponent(new RootPanel(arch, this));
		setDividerLocation(150);
	}

	/**
	 * Calls <code>updateDetailPane(1)</code> to update the display when a tree node is selected.
	 * @param e A selection event on a tree node.
	 */
	public void valueChanged(TreeSelectionEvent e)
	{
		DefaultMutableTreeNode node = (DefaultMutableTreeNode) tree.getLastSelectedPathComponent();

		updateDetailPane(node);
	}

	/**
	 * Updates the detail pane to reflect the currently selected node in the tree
	 * @param node The currently selected node in the tree.
	 */
	public void updateDetailPane(DefaultMutableTreeNode node)
	{
		// Remeber the divider location to prevent automatic resizing
		int loc = getDividerLocation();

		// Create description window based on node type
		if (node == null)
		{
			return;
		}

		// remove the current detail pane before adding a new one
		remove(getRightComponent());

		// Note: import to check for root BEFORE leaf, since an empty root return true for isLeaf()
		if (node.isRoot())
		{
			Logger.log_data("User selects root node in archetype (" + node.toString() + ")");
			setRightComponent(new RootPanel(node, this));
		}

		else if (node.isLeaf())
		{
			Logger.log_data("User selects leaf node in archetype (" + node.toString() + ")");
			setRightComponent(new LeafPanel(node, this));
		}

		else
		{
			Logger.log_data("User selects other node in archetype (" + node.toString() + ")");
			setRightComponent(new NodePanel(node, this));
		}

		// Reset the original divider location after updating the detail pane
		setDividerLocation(loc);
	}

	/**
	 * Updates both the tree and detail pane.  Used when nodes are added or removed.
	 * @param node The added node or parent of a removed subtree.  This node is
	 * set to be visible in the tree, selected, and the detail pane updated.
	 */
	public void update(DefaultMutableTreeNode node)
	{
		TreePath path = new TreePath(model.getPathToRoot(node));

		model.reload();
		tree.makeVisible(path);
		tree.setSelectionPath(path);
		updateDetailPane(node);
	}
}


/**
 * Custom cell renderer for nodes in a JTree
 * @param text The text for a node in the <code>JTree</code>
 * @param node The <code>DefaultMutableTreeNode</code> represented by this cell.
 */
class MyTreeRenderer extends DefaultTreeCellRenderer
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private String text;
	private DefaultMutableTreeNode node;

	public MyTreeRenderer()
	{
		text = "";
		node = null;
	}

	public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel, boolean expanded, boolean leaf, int row, boolean hasFocus)
	{
		Object temp;

		super.getTreeCellRendererComponent(tree, value, sel, expanded, leaf, row, hasFocus);

		if (!(value instanceof DefaultMutableTreeNode))
		{
			return this;
		}

		node = (DefaultMutableTreeNode) value;
		temp = node.getUserObject();

		if (temp instanceof Archetype)
		{
			text = ((Archetype) temp).toString();
		}

		else if (temp instanceof PrefNode)
		{
			text = ((PrefNode) temp).getValue().toString();
		}

		else if (temp instanceof UtilityNode)
		{
			text = ((UtilityNode) temp).getValue().toString();
		}

		setText(text);

		return this;
	}
}

