package planIt.poet.gui;


import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JProgressBar;

import planIt.data.Globals;
import planIt.utils.SwingWorker;

public class ProgressBar extends JFrame implements ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private SwingWorker		worker;
	private JPanel			panel;
	private JButton			cancelButton;
	private JProgressBar	progressBar;

	public ProgressBar(Component parent, SwingWorker worker)
	{
		super("Planning...");
		this.worker = worker;

		panel = new JPanel();
		cancelButton = new JButton("Cancel");
		progressBar = new JProgressBar(JProgressBar.HORIZONTAL);

		panel.setLayout(new BoxLayout(panel, BoxLayout.PAGE_AXIS));
		panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		progressBar.setIndeterminate(true);
		progressBar.setForeground(Color.blue);

		cancelButton.addActionListener(this);

		panel.add(progressBar);
		panel.add(Box.createRigidArea(new Dimension(0, 10)));
		panel.add(cancelButton);

		add(panel);

		pack();
		setLocationRelativeTo(parent);
		setVisible(true);

		Globals.frame.addWindowListener(new WindowAdapter()
		{
			public void windowClosed(WindowEvent e)
			{
				dispose();
			}
		});
	}

	public void actionPerformed(ActionEvent e)
	{
		worker.interrupt();
		dispose();
	}
}







