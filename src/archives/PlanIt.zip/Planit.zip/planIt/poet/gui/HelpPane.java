package planIt.poet.gui;


import java.awt.Color;
import java.awt.Dimension;

import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JPanel;

import planIt.data.Globals;


public class HelpPane extends JPanel
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private JLabel label = new JLabel();

	HelpPane(String text)
	{
		setBorder(
				BorderFactory.createCompoundBorder(BorderFactory.createLineBorder(new Color(96, 146, 255)),
				BorderFactory.createEmptyBorder(2, 5, 2, 5)));

		setMaximumSize(new Dimension(575, 300)); // was set to 600

		setBackground(Color.white);
		setHelpText(text);

		add(label);
	}

	/**
	 * Erases any previous help message and displays the new given  help message
	 */
	public void setHelpText(String text)
	{
		label.setText(text);
		label.setFont(Globals.mediumBoldFont);
		label.setHorizontalAlignment(JLabel.CENTER);
		revalidate();
	}
}

