package planIt.poet.gui;


// Java Packages
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.tree.DefaultMutableTreeNode;

import planIt.data.Attribute;
import planIt.data.Globals;
import planIt.data.Value;
import planIt.poet.data.PrefNode;
import planIt.poet.data.UtilityNode;
import planIt.utils.Logger;


/**
 * A panel that gives more detailed information about a leaf node.
 * @param utilityNode The user data from the node about which the pane gives information.
 * @param slider A slider for setting the utility.
 * @param label The UI component which gives the description of the node.
 * @param node The node containing the user data and tree data.
 * @param icon An icon for the detail pane.
 * @param buttonPanel A panel for laying out buttons.
 * @param addButton A button for adding a new tree node.
 * @param removeButton A button for removing the current node.
 * @param parent The parent UI component.
 */
public class LeafPanel extends JPanel implements ChangeListener, ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private UtilityNode 			utilityNode;
	private PrefSlider 				slider;
	private JLabel 					label;
	private DefaultMutableTreeNode 	node;
	private ImageIcon 				icon;
	private JPanel 					buttonPanel;
	private JButton					addButton;
	private JButton					removeButton;
	private ElicitationPane			parent;

	/**
	 * Creates a new panel based on the node and the parent UI element.
	 * @param node The node containing the data for this pane.
	 * @param parent The parent UI element.
	 */
	public LeafPanel(DefaultMutableTreeNode node, ElicitationPane parent)
	{
		this.node = node;
		this.parent = parent;

		utilityNode = (UtilityNode) node.getUserObject();

		slider = new PrefSlider(utilityNode.getUtility());
		icon = new ImageIcon("resources/clipboard.gif");
		label = new JLabel(buildDescription(slider.getUtility()), icon, JLabel.CENTER);

		addButton = new JButton("Add Dependency");
		addButton.addActionListener(this);
		removeButton = new JButton("Remove This");
		removeButton.addActionListener(this);

		buttonPanel = new JPanel();
		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));
		buttonPanel.setBackground(Color.white);
		buttonPanel.add(addButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(15, 0)));
		buttonPanel.add(removeButton);

		// Set the layout, margins, and background color
		setLayout(new BoxLayout(this, BoxLayout.PAGE_AXIS));
		setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10)); // Top, left, bottom, right
		setBackground(Color.white);

		// Note - JLabels must be aligned both in the layout and in the label space
		label.setAlignmentX(Component.CENTER_ALIGNMENT);
		slider.setAlignmentX(Component.CENTER_ALIGNMENT);
		slider.addChangeListener(this);
		buttonPanel.add(slider);

		// Add objects to the pane, including spacers
		add(label);
		add(Box.createRigidArea(new Dimension(0, 50)));
		add(slider);
		add(Box.createRigidArea(new Dimension(0, 50)));
		add(buttonPanel);
	}

	/**
	 * Update values and the UI on slider change events.
	 * @param e A change event (from the slider).
	 */
	public void stateChanged(ChangeEvent e)
	{
		double utility = 0;

		// Wait until slider is done being adjusted
		if (e.getSource() == slider && !slider.getValueIsAdjusting())
		{
			utility = slider.getUtility();
			utilityNode.setUtility(utility);
			label.setText(buildDescription(utility));
			revalidate();
			Logger.log_data("User adjusts leaf node (" + node.toString() + ") utility to (" + utility + ")");
		}
	}

	/**
	 * Build a string description of the preference tree node.
	 * @param utility The utility used in building the description.
	 * @return A <code>String</code> that is the complete description of the node.
	 */
	public String buildDescription(double utility)
	{
		String 		description = new String();
		String 		condition = new String();
		String 		prefValue = new String();
		PrefNode 	tempVal = null;
		DefaultMutableTreeNode tempNode = node;

		// Construct node description
		// description = "<html><font size=4>Attribute: <b>" + utilityNode.parent.name + "</b><br><br>";
		// description += "Value: <b>" + utilityNode.value.name + "</b><br><br>";
		description += "<html><font size=4>Condition: ";

		// Reverse parse the tree in reverse to build description
		while (!tempNode.isRoot())
		{
			tempVal = (PrefNode) tempNode.getUserObject();

			if (((DefaultMutableTreeNode) tempNode.getParent()).isRoot())
			{
				prefValue = tempVal.getValue().toString();
			}

			else
			{
				condition += tempVal.getValue().toString() + " and ";
			}

			tempNode = (DefaultMutableTreeNode) tempNode.getParent();
		}

		// Correct capitalization, remove trailing " and", add period, close html
		if (condition.equals(""))
		{
			condition = "None";
		}

		else
		{
			condition = condition.substring(0, 1).toUpperCase()
					+ condition.substring(1, condition.length() - 5).toLowerCase();
		}

		description += condition + ".<br>";
		description += "Given the condition, you <b> ";

		if (utility == -1)
		{
			description += "must not have";
		}

		else if (utility <= -0.8333)
		{
			description += "very strongly oppose";
		}

		else if (utility <= -0.6666)
		{
			description += "strongly oppose";
		}

		else if (utility <= -0.5 )
		{
			description += "oppose";
		}

		else if (utility <= -.3333)
		{
			description += "moderately oppose";
		}

		else if (utility < 0)
		{
			description += "slightly oppose";
		}

		else if (utility == 0)
		{
			description += "are indifferent of";
		}

		else if (utility <= 0.1667)
		{
			description += "slightly prefer";
		}

		else if (utility <= 0.3334)
		{
			description += "moderately prefer";
		}

		else if (utility <= 0.5)
		{
			description += "prefer";
		}

		else if (utility <= 0.6667)
		{
			description += "strongly prefer";
		}

		else if (utility <= 0.8334)
		{
			description += "very strongly prefer";
		}

		else if (utility <= 1)
		{
			description += "must have";
		}

		else
		{
			description += "???";
		}

		description += " </b> the value \"<b>" + prefValue + "</b>\".</font></html>";

		return description;
	}

	/**
	 * Rounds the given double to the given number of decimal places.
	 * @param value The value to be rounded.
	 * @param precision The number of decimal places to round to.
	 * @return The rounded value.
	 */
	double round(double value, int precision)
	{
		double powerTen = 1;

		while (precision-- > 0)
		{
			powerTen *= 10.0;
		}

		return Math.round(value * powerTen) / powerTen;
	}

	/**
	 * Catches actions on the add and remove buttons.
	 * @param e An action event.
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == addButton)
		{
			Attribute[] attrs = allowedAttributes();
			Value[] values = null;
			DefaultMutableTreeNode treeNode = null;
			PrefNode prefNode = null;
			Attribute attr = null;
			Value value = null;

			if (attrs.length == 0)
			{
				JOptionPane.showMessageDialog(parent, "There are no more values that can be added to this node.");
				return;
			}

			attr = (Attribute) JOptionPane.showInputDialog(parent, "Choose an attribute:", "Add Dependency",
					JOptionPane.PLAIN_MESSAGE, null, attrs, attrs[0]);

			if (attr == null)
			{
				return;
			}

			values = allowedValues(attr);

			value = (Value) JOptionPane.showInputDialog(parent, "Now choose the value:", "Add Dependency",
					JOptionPane.PLAIN_MESSAGE, null, values, values[0]);

			if (value == null)
			{
				return;
			}

			prefNode = new PrefNode();
			prefNode.setAttribute(utilityNode.getAttribute());
			prefNode.setValue(utilityNode.getValue());

			utilityNode.setAttribute(attr);
			utilityNode.setValue(value);
			utilityNode.setUtility(0);

			treeNode = new DefaultMutableTreeNode();
			treeNode.setUserObject(utilityNode);

			node.setUserObject(prefNode);
			node.add(treeNode);

			Logger.log_data("User adds new node at leaf node (" + node.toString() + "). New node (" + utilityNode.getAttribute().toString() + ") at value (" + utilityNode.getValue().toString() + ")");

			parent.update(treeNode);
			
		}

		else if (e.getSource() == removeButton)
		{
			DefaultMutableTreeNode treeNode = (DefaultMutableTreeNode) node.getParent();
			PrefNode prefNode = null;

			if (!treeNode.isRoot())
			{
				prefNode = (PrefNode) treeNode.getUserObject();
				utilityNode.setAttribute(prefNode.getAttribute());
				utilityNode.setValue(prefNode.getValue());
				utilityNode.setUtility(0);
				treeNode.setUserObject(utilityNode);
			}

			node.removeFromParent();
			Logger.log_data("User removes node at leaf node (" + node.toString() + ")");
			parent.update(treeNode);
		}
	}

	/**
	 * Generates an array of attributes that are allowed to be added based on the
	 * given attribute and current branch values.  Although for a leaf, any
	 * attribute is allowed, the purpose of this function is to pre-check all
	 * attribute values.  If all values for an attribute are present in a branch,
	 * then selecting that attribute to add would bring up an empty value selection
	 * box.  This function removes such attributes to prevent this behavior.
	 * @return An array of all allowable attributes for the current branch.
	 */
	public Attribute[] allowedAttributes()
	{
		ArrayList<Attribute> attrs = new ArrayList<Attribute>(Globals.attributes.values());
		Attribute[] result = new Attribute[0];
		DefaultMutableTreeNode current = node;
		PrefNode temp = null;

		// Traverse backwards up the branch to the root, checking each node
		while (current != null && !current.isRoot())
		{
			if (current.getUserObject() instanceof PrefNode)
			{
				temp = (PrefNode) current.getUserObject();

				// if (allowedValues(temp.getAttribute()).length < 1)
				// {
				attrs.remove(temp.getAttribute());
				// }
			}

			current = (DefaultMutableTreeNode) current.getParent();
		}

		result = new Attribute[attrs.size()];
		attrs.toArray(result);

		return result;
	}

	/**
	 * Generates an array of values that are allowed to be added based on the
	 * given attribute and current branch values.  A value can exist only once
	 * in a branch (it cannot depend on itself).
	 * @param attr The attribute whose values are being checked.
	 * @return An array of all allowable values for the given attribute and
	 * current branch.
	 */
	public Value[] allowedValues(Attribute attr)
	{
		ArrayList<Value> values = new ArrayList<Value>(attr.values.values());
		Value[] result = null;
		DefaultMutableTreeNode current = node;
		PrefNode temp = null;

		while (current != null && !current.isRoot())
		{
			if (current.getUserObject() instanceof PrefNode)
			{
				temp = (PrefNode) current.getUserObject();

				// if the attribute and value match, remove it from the list
				if (temp.getAttribute() == attr && attr.values.get(temp.getValue().getName()) != null)
				{
					values.remove(temp.getValue());
				}
			}

			current = (DefaultMutableTreeNode) current.getParent();
		}

		result = new Value[values.size()];
		values.toArray(result);

		return result;
	}
}

