package planIt.data;


public class Value
{
	public String name;
	public String description;

	public Value()
	{
		name = "";
		description = "";
	}

	public String toString()
	{
		return description;
	}

	public String getName()
	{
		return name;
	}

	public String getDescription()
	{
		return description;
	}

	public Value clone()
	{
		Value value = new Value();

		value.name = name;
		value.description = description;

		return value;
	}
}

