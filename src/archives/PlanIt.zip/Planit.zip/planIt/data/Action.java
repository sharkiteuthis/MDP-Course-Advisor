package planIt.data;


public class Action
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	public String name; // The action name
	public String label; // The GUI label for the action
	public String description; // The action description

	public Action()
	{
		name = "";
		label = "";
		description = "";
	}

	public String toString()
	{
		return description;
	}

	public String getDescription()
	{
		return description;
	}

	public String getName()
	{
		return name;
	}

	public Action clone()
	{
		Action action = new Action();

		action.name = name;
		action.label = label;
		action.description = description;

		return action;
	}
}

