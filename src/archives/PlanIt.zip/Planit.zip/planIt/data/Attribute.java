package planIt.data;


import java.util.HashMap;


public class Attribute // Store attribute name, description, and value list
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	public String name;
	public String description;
	public HashMap <String, Value> values;

	public Attribute()
	{
		name = "";
		description = "";
		values = new HashMap<String, Value>();
	}

	public String toString()
	{
		return description;
	}

	public String getName()
	{
		return name;
	}

	public HashMap <String, Value> getValues()
	{
		return values;
	}
}

