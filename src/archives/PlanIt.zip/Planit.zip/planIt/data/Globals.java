package planIt.data;


// Java packages
import java.awt.Font;
import java.net.URL;
import java.util.Comparator;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.tree.DefaultMutableTreeNode;

import planIt.gui.CloseableTabbedPane;
import planIt.planScan.data.ADD;
import planIt.planScan.data.State;
import planIt.poet.data.Archetype;


public class Globals
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;
	
	// Files and paths
	public static URL						codeBase;
	public static String					file;
	public static String					project;

	/* User Data */
	public static String					username;
	// public static String					password;

	// Shared data
	public static Map<String, Attribute>	attributes;
	public static Map<String, Action>		actions;

	// POET data
	public static DefaultMutableTreeNode	prefs;
	public static DefaultMutableTreeNode[]	archetypes;
	public static Archetype					userPrefs;
	public static int						prefIndex;

	// PlanScan data
	public static ADD 						add;
	public static State						startState;
	public static int						planCount;
	public static Comparator<State>			stateComparator;

	// Layout access
	public static CloseableTabbedPane		tabs;
	public static JFrame					frame;

	// Fonts
	public static Font largeFont = new Font("SansSerif", Font.PLAIN, 16);
	public static Font mediumFont = new Font("SansSerif", Font.PLAIN, 14);
	public static Font smallFont = new Font("SansSerif", Font.PLAIN, 12);
	public static Font largeBoldFont = new Font("SansSerif", Font.BOLD, 16);
	public static Font mediumBoldFont = new Font("SansSerif", Font.BOLD, 14);
	public static Font smallBoldFont = new Font("SansSerif", Font.BOLD, 12);
}

