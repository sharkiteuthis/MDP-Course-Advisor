package planIt.planScan.gui;


import java.util.EventListener;

import planIt.planScan.data.State;


/**
 * The listener is notified a selected <code>State</code>.
 */
public interface StateSelectionListener extends EventListener
{

	/**
	 * Informs all <code>StateSelectionListener</code>s when a new
	 * <code>State<code> object is selected.
	 * @param state  The selected <code>State<code>.
	 */
	void stateSelected(State state);
}

