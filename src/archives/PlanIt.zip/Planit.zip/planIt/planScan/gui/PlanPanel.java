package planIt.planScan.gui;


// Java packages
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import javax.swing.*;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import planIt.data.Globals;
import planIt.planScan.data.Plan;
import planIt.planScan.data.State;
import planIt.planScan.data.StateValue;
import planIt.data.Action;
import planIt.utils.DocumentRenderer;

/**
 * The main display component for displaying a plan.
 * @param resultPane A detailed description of the result state.
 * @param currentPane A detailed description of the current state.
 * @param shapesPanel The panel containing the result state shapes.
 * @param buttonPanel The panel for action selection and traversal.
 * @param currentState The current state.
 * @param resultState The selected result state.
 * @param nextStates The possible outcome states.
 * @param forward The stack of states tied to the forward button.
 * @param back The stack of states tied to the back button.
 * @param prefChange Tracks whether or not the preferences have changed.
 */
public class PlanPanel extends JPanel implements ChangeListener, ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	// The plan corresponding to this UI
	protected Plan				plan;

	protected DetailPane 		resultPane;
	protected DetailPane 		currentPane;
	protected ShapesPanel 		shapesPanel;
	protected ButtonPanel 		buttonPanel;
	private JButton				setStateButton;
	private JPanel				leftPanel;

	/* The current, possible result, and selected result states */
	protected State 			currentState; // Keep track of the current display state values
	protected State 			resultState; // Selected result state
	protected ArrayList<State> 	nextStates; // An array of all possible next states

	/* Stacks of next and previous states for the forward and back buttons */
	protected List<State> 		forward;
	protected List<State> 		back;
	private boolean 			prefChange;

	public PlanPanel(Plan plan)
	{
		this.plan = plan;

		leftPanel = new JPanel();
		setStateButton = new JButton("Edit State");
		back = new ArrayList<State>();
		forward = new ArrayList<State>();
		Globals.tabs.addChangeListener(this);
		prefChange = false;

		setLayout(new BorderLayout());
		leftPanel.setLayout(new BoxLayout(leftPanel, BoxLayout.PAGE_AXIS));
		setStateButton.addActionListener(this);

		// Set the current state to the start state
		currentState = Globals.startState;

		// Setup detail windows
		currentPane = new DetailPane(currentState, "<html><b><font size=5>Current State</font></b></html>");
		currentPane.setCellRenderer(new CurrentCellRenderer());
		resultPane = new DetailPane(resultState, "<html><b><font size=5>Result State</font></b></html>");
		resultPane.setCellRenderer(new ResultCellRenderer());

		// Setup button panel and compute next possible states for suggested action
		buttonPanel = new ButtonPanel(this);
		buttonPanel.addActionSelectionListener(new ActionSelection());
		nextStates = currentState.resultStates(buttonPanel.getSelectedAction());

		// Build shapes panel based on result states
		shapesPanel = new ShapesPanel(this);
		shapesPanel.addStateSelectionListener(new StateSelection());
		shapesPanel.update(nextStates, null);
		buttonPanel.update();

		leftPanel.add(currentPane);
		leftPanel.add(Box.createRigidArea(new Dimension(10, 0)));
		leftPanel.add(setStateButton);
		leftPanel.add(Box.createRigidArea(new Dimension(10, 0)));

		add(leftPanel, BorderLayout.LINE_START);
		add(shapesPanel, BorderLayout.CENTER);
		add(resultPane, BorderLayout.LINE_END);
		add(buttonPanel, BorderLayout.PAGE_END);
	}

	/**
	 * Gets the plan for this <code>PlanPanel</code>.
	 * @return The <code>Plan</code>.
	 */
	public Plan getPlan()
	{
		return plan;
	}

	/**
	 * Gets the <code>ShapesPanel</code> associated with this <code>PlanPanel
	 * </code>.
	 */
	public void updateShapes()
	{
		shapesPanel.update();
	}

	/**
	 * Gets the current state.
	 * @return The current state.
	 */
	public State getCurrentState()
	{
		return currentState;
	}

	/**
	 * Goes back to the previous state.
	 */
	public void goBack()
	{
		int index = back.size() - 1;

		forward.add(currentState);
		resultState = currentState;
		currentState = back.get(index);
		back.remove(index);
		nextStates = currentState.resultStates(buttonPanel.getSelectedAction());

		// Update the button panel (gets the new suggested action), then the shapes, then the detail panes
		buttonPanel.update();
		shapesPanel.update(nextStates, resultState);
		fireCurrentState(currentState);
	}

	void printPlan()
	{
		// Set the current state to the start state
		State printcurrentState = Globals.startState;
		String strPlan = "";
		int Counter = 1;

		ArrayList<Action> printActions = plan.getAction(printcurrentState);

		while (printcurrentState.stateValues.get("validity").value.name.equals("valid")) {
			ArrayList<State> printnextStates = printcurrentState.resultStates(printActions.get(0));
			printcurrentState = printnextStates.get(0);
			printActions = plan.getAction(printcurrentState);
			Counter = Counter + 1;
		}

		// Set the current state to the start state
		printcurrentState = Globals.startState;
		printActions = plan.getAction(printcurrentState);

		if (printActions.size() > 0) {
			strPlan = printActions.get(0).getDescription() + "<br>";
		} else {
			System.err.println("No suggested action.");
		}

		for (int j=1; j<Counter-2; j++) {
			ArrayList<State> printnextStates = printcurrentState.resultStates(printActions.get(0));
			printcurrentState = printnextStates.get(0);
			printActions = plan.getAction(printcurrentState);
			if (printActions.size() > 0) {
				strPlan = strPlan + printActions.get(0).getDescription() + "<br>";
			} else {
				System.err.println("No suggested action.");
			}
		}
		
		// Create HTML representation of Plan
		String genPlan = "<HTML><BODY>";
		genPlan += "<p align=\"center\" style=\"margin-top: 20; margin-bottom: 0\">" +
				   "<img border=\"0\" src=\"logo1.png\"></p>";
		genPlan += "<p><p><p><center>" + strPlan + "</center>";
		genPlan += "</BODY></HTML>";
		try {
			FileWriter fout1 = new FileWriter("resources/plandoc.html");
			fout1.write(genPlan);
			fout1.close();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String url = "file:" + new File("resources/plandoc.html").getAbsolutePath();
		
		JFrame jf = new JFrame();
		JEditorPane jep = new JEditorPane();
		jep.setEditable(false);
		try {
		jep.setPage(url);
		
		} catch (Exception exc) {
			System.err.println(exc.getMessage());
		}

		jf.add(jep);
		jf.setVisible(true);
		jf.setVisible(false);

		DocumentRenderer test = new DocumentRenderer();
		test.print(jep);
	}

	/**
	 * Advances the current state to the selected result state - if no result
	 * is selected, it will go to the next state in the forward stack
	 */
	void goForward()
	{
		int index = forward.size() - 1;
		State selection = shapesPanel.getSelected();

		// No result state selected and no states in the forward stack
		if (selection == null && index < 0)
		{
			System.err.println("Please select a result state to move to.");
			return;
		}

		// No result state selected, at least one state in forward stack
		else if (selection == null)
		{
			back.add(currentState);
			currentState = forward.get(index);

			resultState = (index == 0) ? null : forward.get(index - 1);
			forward.remove(index);
		}

		// State selected
		else
		{
			back.add(currentState);
			currentState = resultState;
			resultState = null;
			forward.clear();
		}

		// Update the button panel (gets the new suggested action), then the shapes, then the detail panes
		nextStates = currentState.resultStates(buttonPanel.getSelectedAction());
		buttonPanel.update();
		shapesPanel.update(nextStates, resultState);
		fireCurrentState(currentState);
	}

	public void setCompositeActions(ArrayList<State> states)
	{
		shapesPanel.update(states, null);
	}

	/**
	 * Updates the current plan display if the tabs preferences tab has been
	 * selected since this tab was last viewed.  This ensures that updates to
	 * preferences will be reflected in the current plan display.
	 * @param e A <code>ChangeEvent</code> which is checked to verify it is from
	 * the tabbed pane.
	 */
	public void stateChanged(ChangeEvent e)
	{
		if (e.getSource() == Globals.tabs)
		{
			if (Globals.tabs.getSelectedIndex() == Globals.prefIndex)
			{
				prefChange = true;
			}

			else if (Globals.tabs.getSelectedComponent() == this)
			{
				if (prefChange)
				{
					shapesPanel.update();
				}
			}
		}
	}

	public void actionPerformed(ActionEvent e)
	{
		if(e.getSource() == setStateButton)
		{
			StateCreationFrame f = new StateCreationFrame(currentState, false);

			f.addStateCreationListener(new CreationListener());
			f.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					setStateButton.setEnabled(true);
				}

				public void windowClosed(WindowEvent e)
				{
					setStateButton.setEnabled(true);
				}
			});
		}
	}

	public class CreationListener implements StateCreationListener
	{
		public void stateCreated(State state)
		{
			currentState = state;

			forward.clear();
			back.clear();
			buttonPanel.update();
			nextStates = currentState.resultStates(buttonPanel.getSelectedAction());
			shapesPanel.update(nextStates, resultState);
			fireCurrentState(currentState);
		}
	}

	/**
	 * Custom Cell renderer for the current state detail pane.
	 * @param sVal The attribute value data object.
	 * @param text The text to be displayed by this cell renderer.
	 */
	class CurrentCellRenderer extends StateValue implements ListCellRenderer
	{
		// Revision ID - Prevents annoying warning in Java 1.5
		public static final long serialVersionUID = 1;
		private StateValue sVal;

		protected DefaultListCellRenderer defaultRenderer = new DefaultListCellRenderer();

		public CurrentCellRenderer()
		{
			setOpaque(true);
		}

		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
		{
			JLabel renderer = (JLabel) defaultRenderer.getListCellRendererComponent(list, value, index, isSelected,
					cellHasFocus);

			if (!(value instanceof StateValue))
			{
				renderer.setText("");
				return renderer;
			}

			sVal = (StateValue) value;
			renderer.setText(sVal.getValue().getDescription());

			if (resultState == null)
			{
				renderer.setFont(Globals.mediumFont);
				return renderer;
			}

			StateValue temp = resultState.stateValues.get(sVal.getAttribute().getName());

			if (temp.getValue() == sVal.getValue())
			{
				renderer.setFont(Globals.mediumFont);
			}

			else
			{
				renderer.setBackground(Color.yellow);
				renderer.setFont(Globals.mediumBoldFont);
			}

			// Add code here to render on mouse hover - tooltip?
			if (isSelected)
			{}

			return renderer;
		}
	}


	/**
	 * Custom Cell renderer for the current state detail pane.
	 * @param sVal The state value associated with the cell.
	 * @param text The text to be painted on the cell.
	 */
	class ResultCellRenderer extends StateValue implements ListCellRenderer
	{
		// Revision ID - Prevents annoying warning in Java 1.5
		public static final long serialVersionUID = 1;

		private StateValue sVal;
		protected DefaultListCellRenderer defaultRenderer = new DefaultListCellRenderer();

		public ResultCellRenderer()
		{
			setOpaque(true);
		}

		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
		{
			JLabel renderer = (JLabel) defaultRenderer.getListCellRendererComponent(list, value, index, isSelected,
					cellHasFocus);

			if (!(value instanceof StateValue))
			{
				return renderer;
			}

			sVal = (StateValue) value;
			StateValue temp = currentState.stateValues.get(sVal.getAttribute().getName());

			renderer.setText(sVal.getValue().getDescription());

			if (temp.getValue() == sVal.getValue())
			{
				renderer.setFont(Globals.mediumFont);
			}

			else
			{
				renderer.setFont(Globals.mediumBoldFont);
				renderer.setBackground(Color.yellow);
			}

			// Add code here to render on mouse hover - tooltip or value selection?
			if (isSelected)
			{}

			return renderer;
		}
	}


	/**
	 * A custom listener for when a new <code>State</code> is selected.
	 */
	public class StateSelection implements StateSelectionListener
	{
		public void stateSelected(State state)
		{
			resultState = state;
			currentPane.update(currentState);
			resultPane.update(resultState);
			buttonPanel.enableForwardButton();
		}
	}


	/**
	 * A custom listener for when a new <code>Action</code> is selected.
	 */
	public class ActionSelection implements ActionSelectionListener
	{
		public void actionSelected(planIt.data.Action action)
		{
			String actionString = action.getDescription();

			if (buttonPanel.isSuggested(action))
			{
				actionString += " (Suggested)";
			}

			shapesPanel.setActionLabel(actionString);
			nextStates = currentState.resultStates(action);
			shapesPanel.update(nextStates, null);
		}
	}

	/**
	 * Adds a <code>CurrentStateListener</code> to this <code>PlanPanel</code>.
	 * @param l The <code>CurrentStateListener</code> to be added.
	 */
	public void addCurrentStateListener(CurrentStateListener l)
	{
		listenerList.add(CurrentStateListener.class, l);
	}

	/**
	 * Removes a <code>CurrentStateListener</code> from this
	 * <code>PlanPanel</code>.
	 * @param l The listener to be removed.
	 */
	public void removeCurrentStateListener(CurrentStateListener l)
	{
		listenerList.remove(CurrentStateListener.class, l);
	}

	/**
	 * Returns an array of all the <code>CurrentStateListener</code>s added to
	 * this <code>PlanPanel</code> with <code>addCurrentStateListener()</code>.
	 * @return all of the <code>CurrentStateListener</code>s added or an empty
	 * array if no listeners have been added
	 */
	public CurrentStateListener[] getCurrentStateListener()
	{
		return listenerList.getListeners(CurrentStateListener.class);
	}

	/**
	 * Notifies all registered <code>CurrentStateListener</code>s.
	 * @param state The current <code>State</code>.
	 */
	protected void fireCurrentState(State state)
	{
		Object[] listeners = listenerList.getListenerList();

		for (Object i : listeners)
		{
			if (i instanceof CurrentStateListener)
			{
				((CurrentStateListener) i).currentStateChanged(state);
			}
		}
	}
}

