package planIt.planScan.gui;


import java.util.EventListener;

import planIt.data.Action;


/**
 * The listener that's notified when a new <code>Action</code> is selected.
 */
public interface ActionSelectionListener extends EventListener
{

	/**
	 * Informs all <code>ActionSelectionListener</code>s when an
	 * <code>Action</code> has been selected.
	 * @param action The selected <code>Action</code>
	 */
	public void actionSelected(Action action);
}

