package planIt.planScan.gui;


// Java packages
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.ListCellRenderer;
import javax.swing.SwingConstants;
import javax.swing.event.EventListenerList;

import planIt.data.Action;
import planIt.data.Globals;
import planIt.poet.gui.PickArch;
import planIt.utils.Logger;


/**
 * Creates a panel of UI elements for selecting actions and traversing a plan.
 * @param parent The parent UI element.
 * @param suggestedActions A list of all actions suggested by the plan for the
 * current state.
 * @param selectedAction The currently selected action.
 * @param centerPanel A container panel that contains central UI elements.
 * @param actionPanel A container panel for UI elements for action selection.
 * @param suggestedPanel A container panel for suggested actions.
 * @param alternatePanel A container panel for alternate actions.
 * @param topPanel A container panel for the forward and back buttons.
 * @param suggestedButton The suggested action button.
 * @param forwardButton The forward button.
 * @param backButton The back button.
 * @param prefButton A button to return to preference elicitation.
 * @param dropMenu A drop down menu of all available actions.
 * @param renderer A custom cell renderer for the drop down menu.
 * @param suggestedLabel The suggested action label.
 * @param The alternate action label.
 * @param forwardButtonToolTip A tool tip for the forward button.
 * @param backButtonToolTip A tool tip for the back button.
 * @param actionButtonToolTip A tool tip for the suggested action button.
 * @param prefToolTip A tool tip for the preference button.
 * @param updating This variable is a workaround for an odd bug that fires
 * an action event when <code>JComboBox</code> items are removed/added.
 * According to the API, the high level event listener should only fire when
 * an item is selected.  This boolean is set to true when an update is taking
 * place.
 */
public class ButtonPanel extends JPanel implements ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private ArrayList<planIt.data.Action> 	suggestedActions;
	private planIt.data.Action				selectedAction;

	private PlanPanel 			parent;
	private EventListenerList 	listenerList;

	private JPanel 				centerPanel;
	private JPanel 				actionPanel;
	private JPanel 				suggestedPanel;
	private JPanel 				alternatePanel;
	private JPanel				topPanel;

	private JButton 			suggestedButton;
	private JButton 			forwardButton;
	private JButton 			backButton;
	private JButton 			prefButton;
	private JButton				compositeButton;
	private JButton				goalButton;
	//private JButton				printButton;

	private JComboBox 			dropMenu;
	private ListCellRenderer 	renderer;

	private JLabel 				suggestedLabel;
	private JLabel 				alternateLabel;

	// The composite action and goal frames
	private CompositeActionFrame compositeFrame;
	private GoalFrame 			goalFrame;

	// This variable is a workaround for an odd bug that fires an action event when
	// the jcombobox items are removed or new items are added.  According to the API,
	// the high level event listener I use should ONLY fire when an item is selected
	// This boolean is set to true when an update is taking place, and any events
	// fired during an update are simply discarded.
	private boolean		updating;

	public ButtonPanel(PlanPanel planPanel)
	{
		parent = planPanel;
		updating = false;
		listenerList = new EventListenerList();

		// Set layout
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		// Initialize Panels
		topPanel = new JPanel();
		topPanel.setLayout(new BoxLayout(topPanel, BoxLayout.X_AXIS));
		topPanel.setBorder(BorderFactory.createEmptyBorder(10, 15, 10, 15));

		centerPanel = new JPanel();
		centerPanel.setLayout(new BoxLayout(centerPanel, BoxLayout.PAGE_AXIS));
		centerPanel.setBorder(BorderFactory.createEtchedBorder());

		suggestedPanel = new JPanel();
		suggestedPanel.setLayout(new BoxLayout(suggestedPanel, BoxLayout.PAGE_AXIS));
		suggestedPanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // Top, left, bottom, right

		alternatePanel = new JPanel();
		alternatePanel.setLayout(new BoxLayout(alternatePanel, BoxLayout.PAGE_AXIS));
		alternatePanel.setBorder(BorderFactory.createEmptyBorder(5, 10, 5, 10)); // Top, left, bottom, right

		actionPanel = new JPanel();
		dropMenu = new JComboBox();
		renderer = new MyCellRenderer();
		dropMenu.setRenderer(renderer);

		JLabel suggestedLabel = new JLabel("Suggested Action");

		suggestedLabel.setFont(Globals.mediumBoldFont);
		suggestedLabel.setHorizontalAlignment(JLabel.CENTER);
		suggestedLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

		JLabel alternateLabel = new JLabel("Alternate Actions");

		alternateLabel.setFont(Globals.mediumBoldFont);
		alternateLabel.setHorizontalAlignment(JLabel.CENTER);
		alternateLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

		// Initialize static buttons and their tooltips
		prefButton = new JButton("Edit Preferences");
		prefButton.setToolTipText("Makes the selected result state the current state");
		prefButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		prefButton.setFont(Globals.mediumBoldFont);

		forwardButton = new JButton("Forward", new ImageIcon("resources/forward.gif"));
		forwardButton.setDisabledIcon(new ImageIcon("resources/forward_gray.gif"));
		forwardButton.setToolTipText("Makes the selected result state the current state");
		forwardButton.setFont(Globals.mediumBoldFont);
		forwardButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		forwardButton.setHorizontalTextPosition(SwingConstants.LEFT);

		backButton = new JButton("Previous", new ImageIcon("resources/back.gif"));
		backButton.setDisabledIcon(new ImageIcon("resources/back_gray.gif"));
		backButton.setToolTipText("Change the selected value");
		backButton.setFont(Globals.mediumBoldFont);
		backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		backButton.setHorizontalTextPosition(SwingConstants.RIGHT);

		suggestedButton = new JButton();
		suggestedButton.setToolTipText("Use the action suggest by the plan");
		suggestedButton.setAlignmentX(Component.CENTER_ALIGNMENT);

		compositeButton = new JButton("Multiple Actions");
		compositeButton.setToolTipText("Perform several actions in sequence from the current state");
		compositeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		compositeButton.setFont(Globals.mediumBoldFont);

		goalButton = new JButton("Set Goals");
		goalButton.setToolTipText("Create and track goals");
		goalButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		goalButton.setFont(Globals.mediumBoldFont);

		//printButton = new JButton("Print Plan");
		//printButton.setToolTipText("Print suggested actions");
		//printButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		//printButton.setFont(Globals.mediumBoldFont);
		
		// Add action listeners
		dropMenu.addActionListener(this);
		suggestedButton.addActionListener(this);
		prefButton.addActionListener(this);
		forwardButton.addActionListener(this);
		backButton.addActionListener(this);
		compositeButton.addActionListener(this);
		goalButton.addActionListener(this);
		//printButton.addActionListener(this);

		// Sets text on buttons and labels for current state
		update();

		topPanel.add(backButton);
		topPanel.add(Box.createHorizontalGlue());
		topPanel.add(prefButton);
		topPanel.add(Box.createRigidArea(new Dimension(5, 0)));
		topPanel.add(compositeButton);
		topPanel.add(Box.createRigidArea(new Dimension(5, 0)));
		topPanel.add(goalButton);
		topPanel.add(Box.createRigidArea(new Dimension(5, 0)));
		//topPanel.add(printButton);
		topPanel.add(Box.createHorizontalGlue());
		topPanel.add(forwardButton);

		suggestedPanel.add(suggestedLabel);
		suggestedPanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer
		suggestedPanel.add(suggestedButton);

		alternatePanel.add(alternateLabel);
		alternatePanel.add(Box.createRigidArea(new Dimension(0, 10))); // Spacer
		alternatePanel.add(dropMenu);

		actionPanel.add(suggestedPanel);
		actionPanel.add(alternatePanel);
		centerPanel.add(actionPanel);

		add(topPanel);
		add(centerPanel);
	}

	/**
	 * Handles all action events on the buttons.
	 * @param e An action event.
	 */
	public void actionPerformed(ActionEvent e)
	{
		if (updating)
		{
			return;
		}

		Object object = e.getSource();

		// Action drop down menu selection event
		if (object == dropMenu)
		{
			Action action = (planIt.data.Action) ((JComboBox) e.getSource()).getSelectedItem();

			if (action == null)
			{
				return;
			}

			selectedAction = action;

			String text = "";

			text += "Current Action - " + selectedAction.description;

			if (suggestedActions.contains(selectedAction))
			{
				text += " (Suggested)";
			}

			Logger.log_data("User selects action (" + text + ")");
			
			fireActionSelection(selectedAction);
		}

		// Suggested action button pressed event
		else if (object == suggestedButton)
		{
			selectedAction = suggestedActions.get(0);
			
			Logger.log_data("User action (Suggested Action)");
			
			fireActionSelection(selectedAction);
		}

		// Forward button pressed event
		else if (object == forwardButton)
		{
			Logger.log_data("User action (Move Forward)");
			
			parent.goForward();
		}

		// Back button pressed event
		else if (object == backButton)
		{
			Logger.log_data("User action (Move Back)");
			
			parent.goBack();
		}

		// Preference elicitation button pressed event
		else if (object == prefButton)
		{
			if (Globals.prefIndex < 1)
			{
				Globals.tabs.addTab("Preferences", new PickArch());
				Globals.prefIndex = Globals.tabs.getTabCount() - 1;
			}

			Logger.log_data("User action (Return to Preference Elicitation)");
			
			Globals.tabs.setSelectedIndex(Globals.prefIndex);
		}

		// Creates a new composite action panel for the current plan
		else if (object == compositeButton)
		{
			Logger.log_data("User action (Composite Action)");
			
			if (compositeFrame == null)
			{
				compositeFrame = new CompositeActionFrame(parent);
			}

			else
			{
				compositeFrame.requestFocus();
			}

			compositeFrame.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					compositeFrame = null;
				}
			});
		}

		// Creates a new composite action panel for the current plan
		else if (object == goalButton)
		{
			Logger.log_data("User action (Goals)");
			
			if (goalFrame == null)
			{
				goalFrame = new GoalFrame(parent);
			}

			else
			{
				goalFrame.requestFocus();
			}

			goalFrame.addWindowListener(new WindowAdapter()
			{
				public void windowClosing(WindowEvent e)
				{
					goalFrame = null;
				}
			});
		}
		
		/* else if (object == printButton)
		{
			parent.printPlan();
		} */
	}

	/**
	 * Gets the suggests actions set for the current state and updates text labels accordingly
	 */
	public void update()
	{
		updating = true;

		// Get all suggested actions
		suggestedActions = parent.plan.getAction(parent.currentState);
		selectedAction = suggestedActions.get(0);
		fireActionSelection(selectedAction);

		// For multiple suggested actions, use the first
		if (suggestedActions == null || suggestedActions.isEmpty())
		{
			System.err.println("Warning - no suggested actions found");
			return;
		}

		// Set the suggested button and selection label text
		suggestedButton.setText(selectedAction.description);
		suggestedButton.setFont(Globals.mediumBoldFont);

		// Remove all items from the drop down menu
		dropMenu.removeAllItems();

		// Populate the drop down box with all actions save the suggested
		for (Action temp : Globals.actions.values())
		{
			if (temp != selectedAction)
			{
				dropMenu.addItem(temp);
			}
		}

		// Handle avalibility of the forward and back buttons
		if (parent.resultState == null && parent.forward.isEmpty())
		{
			forwardButton.setEnabled(false);
		}

		else
		{
			forwardButton.setEnabled(true);
		}

		if (parent.back.isEmpty())
		{
			backButton.setEnabled(false);
		}

		else
		{
			backButton.setEnabled(true);
		}

		updating = false;
	}

	/**
	 * Enables the forward button.
	 */
	public void enableBackButton()
	{
		backButton.setEnabled(true);
	}

	/**
	 * Enables the back button.
	 */
	public void enableForwardButton()
	{
		forwardButton.setEnabled(true);
	}

	/**
	 * Disables the back button.
	 */
	public void disableBackButton()
	{
		backButton.setEnabled(false);
	}

	/**
	 * Disables the forward button.
	 */
	public void disableForwardButton()
	{
		forwardButton.setEnabled(false);
	}

	/**
	 * Determines if the back button is enabled.
	 * @return True if the back Button is enabled, false otherwise.
	 */
	public boolean isBackEnabled()
	{
		return backButton.isEnabled();
	}

	/**
	 * Determines if the foward button is enabled.
	 * @return True if the foward Button is enabled, false otherwise.
	 */
	public boolean isForwardEnabled()
	{
		return forwardButton.isEnabled();
	}

	/**
	 * Retrieves the currently selected action.
	 * @return The currently selected action.
	 */
	public Action getSelectedAction()
	{
		return selectedAction;
	}

	/**
	 * Determines if a specified <code>Action</code> is suggested by the plan.
	 * @param action The specified <code>Action</code>.
	 * @return True if <code>action</code> is suggested, false otherwise.
	 */
	public boolean isSuggested(Action action)
	{
		if (action != null && suggestedActions.contains(action))
		{
			return true;
		}

		return false;
	}

	/**
	 * Adds an <code>ActionSelectionListener</code> to the
	 * <code>ButtonPanel</code>.
	 * @param l The <code>ActionSelectionListener</code> to be added.
	 */
	public void addActionSelectionListener(ActionSelectionListener l)
	{
		listenerList.add(ActionSelectionListener.class, l);
	}

	/**
	 * Removes an <code>ActionSelectionListener</code> from the
	 * <code>ButtonPanel</code>.
	 * @param l The <code>ActionSelectionListener</code> to be removed.
	 */
	public void removeActionSelectionListener(ActionSelectionListener l)
	{
		listenerList.remove(ActionSelectionListener.class, l);
	}

	/**
	 * Returns an array of all the <code>ActionSelectionListener</code>s for
	 * this <code>ActionButtons</code>
	 * @return All of the <code>ActionSelectionListener</code>s added, or an
	 * empty array if no listeners have been added.
	 */
	public ActionSelectionListener[] getActionSelectionListener()
	{
		return listenerList.getListeners(ActionSelectionListener.class);
	}

	/**
	 * Notifies all <code>ActionSelectionListener</code> that an action was
	 * selected.
	 * @param action The <code>Action</code> selected.
	 */
	protected void fireActionSelection(Action action)
	{
		Object[] listeners = listenerList.getListenerList();

		for (Object i : listeners)
		{
			if (i instanceof ActionSelectionListener)
			{
				((ActionSelectionListener) i).actionSelected(action);
			}
		}
	}

	/**
	 * Custom Cell renderer for displaying <code>Action</code>s in a
	 * <code>JComboBox</code>.
	 * @param text The text to be painted for the cell.
	 * @param defaultRenderer The default cell renderer.
	 */
	class MyCellRenderer extends JLabel implements ListCellRenderer
	{
		// Revision ID - Prevents annoying warning in Java 1.5
		public static final long serialVersionUID = 1;

		private planIt.data.Action action;
		private String text;

		protected DefaultListCellRenderer defaultRenderer = new DefaultListCellRenderer();

		public MyCellRenderer()
		{
			setOpaque(true);
		}

		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
		{
			JLabel renderer = (JLabel) defaultRenderer.getListCellRendererComponent(list, value, index, isSelected,
					cellHasFocus);

			if (value instanceof planIt.data.Action)
			{
				action = (planIt.data.Action) value;
			}

			else
			{
				return renderer;
			}

			if (suggestedActions.contains(action))
			{
				text = "<html><font size=4 color=\"#006600\"><b>";
				text += action.description;
				text += "</b></font></html>";
			}

			else
			{
				text = "<html><font size=4 color=\"#CC0033\"><b>";
				text += action.description;
				text += "<b></font></html>";
			}

			renderer.setText(text);
			return renderer;
		}
	}
}

