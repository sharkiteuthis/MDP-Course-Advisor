package planIt.planScan.gui;


// Java packages
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.geom.Rectangle2D;
import java.awt.geom.RoundRectangle2D;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.event.EventListenerList;

import planIt.data.Globals;
import planIt.planScan.data.State;


/* Extend the Canvas class */
class ShapesPanel extends JPanel
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private PlanPanel 			parent;
	private MyCanvas 			canvas;
	private JScrollPane 		canvasScrollPane;
	private JLabel 				title;
	private JLabel				action;
	private EventListenerList 	listenerList;

	public ShapesPanel(PlanPanel planPanel)
	{
		// Pointer to the outcome DeatilPane and next states
		parent = planPanel;

		// Initialize the listener list
		listenerList = new EventListenerList();

		// SET AN EMPTY BORDER FOR SPACING
		setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));
		setLayout(new BoxLayout(this, BoxLayout.Y_AXIS));

		// Initialize label
		title = new JLabel("Possible Result States");
		title.setFont(Globals.largeBoldFont);
		title.setHorizontalAlignment(JLabel.CENTER);
		title.setAlignmentX(Component.CENTER_ALIGNMENT);

		// Initialize label
		action = new JLabel();
		action.setHorizontalAlignment(JLabel.CENTER);
		action.setAlignmentX(Component.CENTER_ALIGNMENT);

		// Create drawing area and add it to the jscrollpane
		canvas = new MyCanvas();
		canvasScrollPane = new JScrollPane(canvas);

		add(title);
		add(Box.createRigidArea(new Dimension(0, 10))); // Spacer
		add(canvasScrollPane);
		add(Box.createRigidArea(new Dimension(0, 15))); // Spacer
		add(action);
		add(Box.createRigidArea(new Dimension(0, 20))); // Spacer
	}

	/**
	 * Creates new shapes for the given set of states and repaints the canvas
	 */
	public void update(ArrayList<State> states, State state)
	{
		canvas.clear();

		Collections.sort(states, Globals.stateComparator);

		// Construct a rectangle for each possibleresult state
		for (State next : states)
		{
			canvas.addRectangle(next);
		}

		canvas.setSelected(state);
		canvas.updateSize();
		canvas.repaint();
	}

	/**
	 * Creates new shapes for the given set of states and repaints the canvas
	 */
	public void update()
	{
		update(canvas.getStates(), canvas.getSelected());
	}

	public void setActionLabel(String label)
	{
		// Update the action label text
		action.setText(label);
		action.setFont(Globals.largeBoldFont);
	}

	public State getSelected()
	{
		return canvas.getSelected();
	}

	class MyCanvas extends JPanel implements MouseListener
	{
		// Revision ID
		public static final long serialVersionUID = 1;

		// Lists for info for drawing rectangles
		private List<MyRectangle> shapes = new ArrayList<MyRectangle>(); // Holds the shape objects
		private MyRectangle selected;

		/* TODO - Set these automatically based on window or desktop size */
		private double overhead = 10;
		private double space = 20;

		/* Store the next horizontal position to draw - initial value is the space from container edge */
		private double lastX = space;

		/* TODO - Set this automatically based on window or desktop size */
		private double multiplier = 2;

		/**
		 * Adds a mouse listener and sets the preffered size of the canvas.
		 */
		MyCanvas()
		{

			/* Add a mouse listener to catch click on rectangles */
			addMouseListener(this);
		}

		/**
		 * Build a new rectangle based on a <code>State</code>
		 * @param state The state whose values are used to construct the rectangle
		 */
		public void addRectangle(State state)
		{
			MyRectangle rect = null;
			Color color = getMyColor(state.getUtility());
			double prob = state.getProbability();
			double size = prob;
			double width = 0;
			double height = 0;
			double arc = 0;
			double y = 0;

			/* I allow maximum size of 100 since this should correspond to utility */
			if (size > 1)
			{
				System.err.println("State probabilities cannot be greater than zero or less than one");
				return;
			}

			if (size <= .1)
			{
				size = .1;
			}

			if (size <= .2)
			{
				lastX += 10;
			}

			size = size * 100;

			// Width of the rectangle - based on multiplier
			width = size * multiplier;
			// Height is based on multiplier - I use rectangles instead of squares.
			height = width - (width / 10);
			// Set the arch on the corners based on the size of the rectangle
			arc = width / 10;
			// Align shaped vertically either to top, center, or baseline
			// y = overhead;
			// y = overhead + ((90 * multiplier - height) / 2);
			y = overhead + (90 * multiplier - height);

			// Create the new rectangle and add it to the list
			rect = new MyRectangle(lastX, y, width, height, arc, arc, state, color, prob);
			shapes.add(rect);

			// Update the last position and total length
			lastX += width + space;

			if (size <= 20)
			{
				lastX += 10;
			}
		}

		/**
		 * Creates a color based on a utility between -1 and 1, blue being more
		 * preferred and red being less.  The stronger the preference, the more alpha
		 * is applied (making weaker preferences fade in color).  Neutral preferences
		 * are a shade of grey.
		 * @param utility The utility to base the color on
		 * @return A color corresponding to the utility
		 */
		private Color getMyColor(double utility)
		{
			int red = 0;
			int green = 0;
			int blue = 0;
			int alpha = 255;

			if (utility > 0)
			{
				blue = 255;
				alpha = (int) (utility * 255);
			}

			else if (utility < 0)
			{
				red = 255;
				alpha = (int) ((-utility) * 255);
			}

			else if (utility == 0)
			{
				red = 130;
				blue = 130;
				green = 130;
			}

			return new Color(red, green, blue, alpha);
		}

		public void setSelected(State state)
		{
			if (state == null)
			{
				setDefaultSelection();
				return;
			}

			for (MyRectangle rect : shapes)
			{
				if (rect.getState().equals(state))
				{
					selected = rect;
					fireStateSelection(state);
					repaint();
					return;
				}
			}

			setDefaultSelection();
		}

		/**
		 * Sets the currently selected shape to the default (most likely)
		 */
		public void setDefaultSelection()
		{
			MyRectangle temp = null;

			if (shapes == null)
			{
				return;
			}

			selected = shapes.get(0);
			fireStateSelection(selected.getState());
			repaint();
		}

		/**
		 * Paints the shapes on the canvas.
		 * @param g The <code>Graphics</code> object for the component.
		 */
		public void paint(Graphics g)
		{
			Graphics2D g2d = (Graphics2D) g;
			Font font = new Font("SansSerif", Font.BOLD, 16); // TODO - Auto adjust font size

			g2d.setFont(font);
			FontMetrics fm = g2d.getFontMetrics(font);
			Rectangle2D fontBounds = null;
			double textX = 0;
			double textY = 0; // Overhead + max rectangle height

			g2d.setColor(getBackground());
			g2d.fill(new Rectangle(getSize()));

			for (MyRectangle rect : shapes)
			{
				// Draw the rectangle - use black line
				g2d.setColor(Color.black);
				g2d.draw(rect);

				// Fill the rectangle with the correct color
				g2d.setColor(rect.getColor());
				g2d.fill(rect);

				// Draw the probability
				g2d.setColor(Color.black);
				fontBounds = fm.getStringBounds(rect.getText(), g2d);

				// Align text
				textX = rect.getCenterX() - (fontBounds.getWidth() / 2);
				textY = overhead + (90 * multiplier) + fontBounds.getHeight() + 10;

				// Draw the string
				g2d.drawString(rect.getText(), (float) textX, (float) textY);
			}

			if (selected != null)
			{
				g2d.setColor(Color.yellow);
				g2d.setStroke(new BasicStroke(4));
				g2d.draw(selected);
			}
		}

		/**
		 *
		 */
		public ArrayList<State> getStates()
		{
			ArrayList<State> states = new ArrayList<State>();

			for (MyRectangle rect : shapes)
			{
				states.add(rect.getState());
			}

			return states;
		}

		/**
		 * Updated the preferred size based on the bounds of the rectangles and their text
		 * and then revalidate.  This is required to ensure that the scrollbars appear when
		 * needed, and should be called whenever any changes occur that alter the dimensions
		 * of the drawing area.
		 */
		public void updateSize()
		{
			setPreferredSize(new Dimension((int) (lastX + space), (int) (100 * multiplier + overhead * 2)));
			revalidate();
		}

		/**
		 * Remove all shapes and colors, and reset position and selected values.
		 */
		public void clear()
		{
			shapes.clear();
			lastX = space;
			selected = null;
		}

		/**
		 * Get the currently selected state or null if no state is selected.
		 * @return The state represented by the selected shape.
		 */
		public State getSelected()
		{
			return selected.getState();
		}

		/**
		 * Handle mouse clicks in the canvase area - If a click occurs within a
		 * shape, the corresponding state is selected and the detail panes
		 * updated accordingly.
		 * @param e A mouse event.
		 */
		public void mouseClicked(MouseEvent e)
		{
			// Check if a rectangle contains the point of mouse click
			for (MyRectangle rect : shapes)
			{
				if (rect.contains(e.getX(), e.getY()))
				{
					selected = rect;
					fireStateSelection(selected.getState());
					repaint();
				}
			}
		}

		/**
		 * Empty method, required implementation for custom mouse event functions.
		 * @param e A mouse event.
		 */
		public void mouseEntered(MouseEvent e)
		{}

		/**
		 * Empty method, required implementation for custom mouse event functions.
		 * @param e A mouse event.
		 */
		public void mousePressed(MouseEvent e)
		{}

		/**
		 * Empty method, required implementation for custom mouse event functions.
		 * @param e A mouse event.
		 */
		public void mouseReleased(MouseEvent e)
		{}

		/**
		 * Empty method, required implementation for custom mouse event functions.
		 * @param e A mouse event.
		 */
		public void mouseExited(MouseEvent e)
		{}
	}

	/**
	 * Rounds the given double to the given number of decimal places.
	 * @param value The value to be rounded.
	 * @param precision The number of decimal places to round to.
	 * @return The rounded value.
	 */
	double round(double value, int precision)
	{
		double powerTen = 1;

		while (precision-- > 0)
		{
			powerTen *= 10.0;
		}

		return Math.round(value * powerTen) / powerTen;
	}

	/**
	 * Adds a <code>StateSelectionListener</code> to this
	 * <code>ShapesPanel</code>.
	 * @param l The <code>StateSelectionListener</code> to be added.
	 */
	public void addStateSelectionListener(StateSelectionListener l)
	{
		listenerList.add(StateSelectionListener.class, l);
	}

	/**
	 * Removes a <code>StateSelectionListener</code> from this
	 * <code>ShapesPanel</code>.
	 * @param l The listener to be removed.
	 */
	public void removeStateSelectionListener(StateSelectionListener l)
	{
		listenerList.remove(StateSelectionListener.class, l);
	}

	/**
	 * Returns an array of all the <code>StateSelectionListener</code>s added
	 * to this <code>ShapesPanel</code> with
	 * <code>addStateSelectionListener()</code>.
	 * @return all of the <code>addStateSelectionListener</code>s added or an
	 * empty array if no listeners have been added.
	 */
	public StateSelectionListener[] getStateSelectionListener()
	{
		return listenerList.getListeners(StateSelectionListener.class);
	}

	/**
	 * Notifies all registered <code>StateSelectionListener</code>s.
	 * @param state The selected <code>State<code>.
	 */
	protected void fireStateSelection(State state)
	{
		Object[] listeners = listenerList.getListenerList();

		for (Object i : listeners)
		{
			if (i instanceof StateSelectionListener)
			{
				((StateSelectionListener) i).stateSelected(state);
			}
		}
	}

	/**
	 * A extended RoundRectangle2D object
	 * @param state The state to which this rectangle corresponds.
	 * @param color The color of the rectangle which corresponds to its preference.
	 * @param text A String noting the percent chance of the state occuring.
	 */
	class MyRectangle extends RoundRectangle2D.Double
	{
		private State state;
		private Color color;
		private String text;

		public MyRectangle(double x, double y, double w, double h, double arcw, double arch, State state, Color color, double prob)
		{
			setRoundRect(x, y, w, h, arcw, arch);
			this.state = state;
			this.color = color;
			prob = round(prob * 100, 1);

			if (prob == 0)
			{
				text = "<0.1%";
			}

			else
			{
				text = java.lang.Double.toString(prob) + "%";
			}
		}

		/**
		 * Gets the current color of the rectangle.
		 * @return The color of the rectangle.
		 */
		public Color getColor()
		{
			return color;
		}

		/**
		 * Get the state associated with the rectangle.
		 * @return The state associated with the rectangle.
		 */
		public State getState()
		{
			return state;
		}

		/**
		 * Get the text associated with the rectangle.
		 * @return The text associated with the rectangle.
		 */
		public String getText()
		{
			return text;
		}

		public void setColor(Color color)
		{
			this.color = color;
		}
	}
}

