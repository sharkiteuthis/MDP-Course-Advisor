package planIt.planScan.gui;


// Java Packages
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.text.NumberFormat;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JProgressBar;
import javax.swing.JScrollPane;
import javax.swing.SwingConstants;

import planIt.data.Globals;
import planIt.planScan.data.State;
import planIt.utils.SwingWorker;


public class GoalFrame extends JFrame implements ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private PlanPanel			parent;
	private JPanel 				panel;
	private JPanel				lowerPanel;
	private JPanel				traversePanel;
	private JPanel				buttonPanel;
	private JPanel				goalsPanel;
	private JScrollPane			scrollPane;
	private JButton				addButton;
	private JButton				forwardButton;
	private JButton				backButton;
	private JFormattedTextField	textBox;
	private JCheckBox			autoUpdateBox;
	private JCheckBox			suggestedSearchBox;
	private JLabel				textBoxLabel;

	private int					time;
	private boolean				autoUpdate;
	private boolean				suggestedSearch;
	private State				currentState;

	public GoalFrame(PlanPanel parent)
	{
		// Set the JFrame title
		super("PlanIt - The Interactive Planner");

		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		// Instantiate objects
		this.parent = parent;
		currentState = parent.currentState;
		time = 10;

		panel = new JPanel();
		panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		panel.setLayout(new BorderLayout());

		buttonPanel = new JPanel();
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		traversePanel = new JPanel();
		traversePanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		traversePanel.setLayout(new BoxLayout(traversePanel, BoxLayout.LINE_AXIS));

		lowerPanel = new JPanel();
		lowerPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		lowerPanel.setLayout(new BoxLayout(lowerPanel, BoxLayout.PAGE_AXIS));

		forwardButton = new JButton("Forward", new ImageIcon("resources/forward.gif"));
		forwardButton.setDisabledIcon(new ImageIcon("resources/forward_gray.gif"));
		forwardButton.setToolTipText("Makes the selected result state the current state");
		forwardButton.setFont(Globals.mediumBoldFont);
		forwardButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		forwardButton.setHorizontalTextPosition(SwingConstants.LEFT);
		forwardButton.setEnabled(parent.buttonPanel.isForwardEnabled());
		forwardButton.addActionListener(this);

		backButton = new JButton("Previous", new ImageIcon("resources/back.gif"));
		backButton.setDisabledIcon(new ImageIcon("resources/back_gray.gif"));
		backButton.setToolTipText("Change the selected value");
		backButton.setFont(Globals.mediumBoldFont);
		backButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		backButton.setHorizontalTextPosition(SwingConstants.RIGHT);
		backButton.setEnabled(parent.buttonPanel.isBackEnabled());
		backButton.addActionListener(this);

		goalsPanel = new JPanel();
		goalsPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		goalsPanel.setLayout(new BoxLayout(goalsPanel, BoxLayout.PAGE_AXIS));

		scrollPane = new JScrollPane(goalsPanel);
		scrollPane.setPreferredSize(new Dimension(100, 100));

		addButton = new JButton("Add Goal");
		addButton.setToolTipText("Add a new goal");
		addButton.addActionListener(this);

		textBox = new JFormattedTextField(NumberFormat.getIntegerInstance());
		textBox.setToolTipText("Give up searching after this many seconds");
		textBox.setColumns(3);
		textBox.setValue(new Integer(time));
		textBox.setEditable(true);
		textBox.addActionListener(this);

		autoUpdateBox = new JCheckBox("Auto-Update");
		autoUpdateBox.setToolTipText("Automatically search for all goal whenever the current state changes");
		autoUpdateBox.setSelected(false);
		autoUpdate = false;
		autoUpdateBox.addActionListener(this);

		suggestedSearchBox = new JCheckBox("Only suggested actions");
		suggestedSearchBox.setToolTipText("Searches only states that can be reached through suggested actions");
		suggestedSearchBox.setSelected(true);
		suggestedSearch = true;
		suggestedSearchBox.addActionListener(this);

		textBoxLabel = new JLabel("Max Time (sec)");
		textBoxLabel.setFont(Globals.mediumFont);

		parent.addCurrentStateListener(new StateListener());

		traversePanel.add(backButton);
		traversePanel.add(Box.createHorizontalGlue());
		traversePanel.add(forwardButton);

		buttonPanel.add(addButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(10, 0)));
		buttonPanel.add(suggestedSearchBox);
		buttonPanel.add(Box.createRigidArea(new Dimension(5, 0)));
		buttonPanel.add(autoUpdateBox);
		buttonPanel.add(Box.createRigidArea(new Dimension(10, 0)));
		buttonPanel.add(textBoxLabel);
		buttonPanel.add(Box.createRigidArea(new Dimension(5, 0)));
		buttonPanel.add(textBox);

		lowerPanel.add(buttonPanel);
		lowerPanel.add(traversePanel);

		panel.add(scrollPane, BorderLayout.CENTER);
		panel.add(lowerPanel, BorderLayout.PAGE_END);

		add(panel);

		pack();
		setLocationRelativeTo(parent);
		setVisible(true);

		Globals.frame.addWindowListener(new WindowAdapter()
		{
			public void windowClosed(WindowEvent e)
			{
				dispose();
			}
		});
	}

	public void actionPerformed(ActionEvent e)
	{
		Object source = e.getSource();

		if (source == addButton)
		{
			StateCreationFrame stateCreation = new StateCreationFrame(currentState, true);

			stateCreation.addStateCreationListener(new CreationListener());
		}

		else if (source == forwardButton)
		{
			parent.goForward();
		}

		else if (source == backButton)
		{
			parent.goBack();
		}

		else if (source == autoUpdateBox)
		{
			autoUpdate = autoUpdate ? false : true;

		}

		else if (source == textBox)
		{
			// This is a bug as the cast SHOULD be to an Integer for Integer number format used
			time = ((Long) textBox.getValue()).intValue();
		}

		else if (source == suggestedSearchBox)
		{
			suggestedSearch = suggestedSearch ? false : true;
		}
	}

	public class StateListener implements CurrentStateListener
	{
		public void currentStateChanged(State state)
		{
			currentState = state;
			backButton.setEnabled(parent.buttonPanel.isBackEnabled());
			forwardButton.setEnabled(parent.buttonPanel.isForwardEnabled());

			Component[] components = goalsPanel.getComponents();
			GoalPanel gp = null;

			for (int i = 0; i < components.length; i++)
			{
				if (components[i] instanceof GoalPanel)
				{
					gp = (GoalPanel) components[i];
					gp.stop();

					if (autoUpdate)
					{
						gp.search();
					}
				}
			}
		}
	}


	public class CreationListener implements StateCreationListener
	{
		public void stateCreated(State state)
		{
			GoalPanel gp = new GoalPanel(state);

			goalsPanel.add(gp);
			panel.revalidate();

			if (autoUpdate)
			{
				gp.search();
			}
		}
	}


	public class GoalPanel extends JPanel implements ActionListener
	{
		public static final long serialVersionUID = 1;

		private JButton 			searchButton;
		private JButton				editButton;
		private JButton				closeButton;
		private ImageIcon			closeIcon;
		private JProgressBar		progressBar;
		private JLabel				name;
		private SwingWorker 		worker;

		private State 				state;
		private boolean				isSearching;
		private int					distance;
		private ArrayList<State>	path;
		private javax.swing.Timer 	timer;

		public GoalPanel(State state)
		{
			this.state = state;

			setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
			setLayout(new BoxLayout(this, BoxLayout.LINE_AXIS));

			closeIcon = new ImageIcon("resources/close_icon3.gif");

			closeButton = new JButton();
			closeButton.setIcon(closeIcon);
			closeButton.setBorderPainted(false);
			closeButton.setContentAreaFilled(false);
			closeButton.setPreferredSize(new Dimension(closeIcon.getIconWidth(), closeIcon.getIconHeight()));
			closeButton.setToolTipText("Close this goal");
			closeButton.addActionListener(this);

			searchButton = new JButton("Search");
			searchButton.setToolTipText("Search for a possible future state that matches this goal");
			searchButton.addActionListener(this);

			editButton = new JButton("Edit state");
			editButton.setToolTipText("Edit the values for this goal");
			editButton.addActionListener(this);

			progressBar = new JProgressBar(JProgressBar.HORIZONTAL, 0, time);
			progressBar.setStringPainted(true);
			resetProgress();

			name = new JLabel("Goal " + goalsPanel.getComponentCount());
			name.setFont(Globals.mediumFont);

			isSearching = false;
			distance = 0;

			add(name);
			add(Box.createRigidArea(new Dimension(10, 0)));
			add(progressBar);
			add(Box.createRigidArea(new Dimension(10, 0)));
			add(editButton);
			add(Box.createRigidArea(new Dimension(5, 0)));
			add(searchButton);
			add(Box.createRigidArea(new Dimension(5, 0)));
			add(closeButton);
		}

		public boolean isWorking()
		{
			return isSearching;
		}

		public void stop()
		{
			if (worker != null)
			{
				worker.interrupt();
				worker = null;
				timer.stop();

				isSearching = false;
				searchButton.setText("Search");
				editButton.setEnabled(true);
				progressBar.setIndeterminate(false);
				progressBar.setForeground(Color.gray);
				textBox.setEditable(true);
			}
		}

		public void search()
		{
			stop();
			progressBar.setForeground(Color.gray);
			progressBar.setString("Searching...");
			progressBar.setIndeterminate(true);

			editButton.setEnabled(false);
			isSearching = true;
			searchButton.setText("Cancel");
			textBox.setEditable(false);

			worker = new Worker();
			worker.setPriority(2);

			timer = new javax.swing.Timer(time * 1000, this);

			timer.start();
			worker.start();
		}

		public int traverse()
		{
			ArrayList<State> queue = new ArrayList<State>();
			ArrayList<State> next = new ArrayList<State>();
			State current = null;
			int currentDepth = 0;
			int mark = 1;

			try
			{
				queue.clear();
				queue.add(currentState);

				while (!queue.isEmpty())
				{
					current = queue.remove(0);
					mark--;

					if (current.equals(state))
					{
						return currentDepth;
					}

					if (Thread.interrupted())
					{
						throw new InterruptedException();
					}

					if (suggestedSearch)
					{
						// Add all states that can be reached in one action
						for (planIt.data.Action action : parent.plan.getAction(current))
						{
							next.addAll(current.resultStates(action));
						}
					}

					else
					{
						// Add all states that can be reached in one action
						for (planIt.data.Action action : Globals.actions.values())
						{
							next.addAll(current.resultStates(action));
						}
					}

					for (State temp : next)
					{
						if (!temp.equals(current))
						{
							queue.add(temp);
						}
					}

					next.clear();

					if (mark < 1)
					{
						currentDepth++;
						mark = queue.size();
					}
				}
			}

			catch (InterruptedException e)
			{
				stop();
				return -1;
			}

			return -1;
		}

		public void resetProgress()
		{
			progressBar.setForeground(Color.gray);
			progressBar.setString("No match");
			progressBar.setValue(0);
			progressBar.setMaximum(0);
		}

		public void updateProgress(int value)
		{
			int oldValue = progressBar.getValue();
			int max = progressBar.getMaximum();

			// No match found
			if (value < 0)
			{
				resetProgress();
			}

			// Matched a possible future state
			else if (value > 0)
			{
				// No previous match
				if (max <= 0)
				{
					progressBar.setMaximum(value + 1);
					progressBar.setValue(1);
					progressBar.setForeground(Color.green);
				}

				// Further from goal
				else if ((max - oldValue) < value)
				{
					// Old value was first match, so the max must be increased
					if (oldValue == 1)
					{
						progressBar.setMaximum(value + 1);
					}

					// Else decrement the value
					else if (oldValue > 1)
					{
						progressBar.setValue(max - value);
					}

					progressBar.setForeground(Color.red);
				}

				// Closer to goal
				else if ((max - oldValue) > value)
				{
					progressBar.setForeground(Color.green);
					progressBar.setValue(max - value);
				}

				String string = "Reachable in " + value + " ";
				string += (value == 1) ? " state" : " states";

				progressBar.setString(string);
			}

			// Reached goal
			else if (value == 0)
			{
				if (max == 0)
				{
					progressBar.setMaximum(1);
				}

				progressBar.setValue(max - value + 1);
				progressBar.setForeground(Color.blue);
				progressBar.setString("Reached Goal");
			}
		}

		public void actionPerformed(ActionEvent e)
		{
			Object source = e.getSource();

			if (source == editButton)
			{
				editButton.setEnabled(false);
				StateCreationFrame f = new StateCreationFrame(state, true);

				f.addStateCreationListener(new EditStateListener());
				f.addWindowListener(new WindowAdapter()
				{
					public void windowClosing(WindowEvent e)
					{
						editButton.setEnabled(true);
					}

					public void windowClosed(WindowEvent e)
					{
						editButton.setEnabled(true);
					}
				});
			}

			else if (source == searchButton)
			{
				if (isSearching)
				{
					stop();
					progressBar.setString("Stopped");
					resetProgress();
				}

				else
				{
					search();
				}
			}

			else if (source == closeButton)
			{
				stop();
				removeAll();
				goalsPanel.remove(this);

				if (goalsPanel.getWidth() < scrollPane.getWidth() || goalsPanel.getHeight() < scrollPane.getHeight())
				{
					goalsPanel.setSize(scrollPane.getSize());
				}

				panel.revalidate();
			}

			else if (source == timer)
			{
				timer.stop();
				stop();
				progressBar.setString("Timed Out");
			}
		}

		public class EditStateListener implements StateCreationListener
		{
			public void stateCreated(State editedState)
			{
				state = editedState;
				resetProgress();

				if (autoUpdate)
				{
					search();
				}
			}
		}


		public class Worker extends SwingWorker
		{
			int value;

			public Object construct()
			{
				value = traverse();
				return null;
			}

			// Runs on the event-dispatching thread.
			public void finished()
			{
				timer.stop();

				isSearching = false;
				searchButton.setText("Search");
				editButton.setEnabled(true);
				progressBar.setIndeterminate(false);
				textBox.setEditable(true);
				updateProgress(value);
			}
		}
	}
}

