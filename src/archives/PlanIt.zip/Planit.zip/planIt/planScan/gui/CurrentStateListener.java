package planIt.planScan.gui;


import java.util.EventListener;

import planIt.planScan.data.State;


/**
 * The listener that's notified when an tab should be closed in the
 * <code>CloseableTabbedPane</code>.
 */
public interface CurrentStateListener extends EventListener
{

	/**
	 * Informs all <code>CurrentStateListener</code>s when a new state is
	 * selected.
	 * @param state The newly selected state.
	 */
	public void currentStateChanged(State state);
}

