package planIt.planScan.gui;


// Java packages
import java.awt.Component;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.WindowAdapter;
import java.awt.event.WindowEvent;
import java.util.ArrayList;

import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.DefaultListCellRenderer;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.ListCellRenderer;

import planIt.data.Globals;
import planIt.planScan.data.State;


/**
 * A frame for selecting a sequence of actions to take.
 * @param parent The <code>PlanPanel</code> for which the composite action is for
 * @param panel The main GUI container.
 * @param buttonPanel The panel which hold the buttons.
 * @param leftScroll The left scroll pane.
 * @param rightScroll The right scroll pane.
 * @param available A <code>JList</code> of available actions.
 * @param selected A <code>JList</code> of selected actions.
 * @param addButton Moves an available action to the list of selected actions.
 * @param removeButton Removes an action for the list of selected actions.
 * @param upButton Moves an action in the selected actions list up in the order.
 * @param downButton Move an action in the selected actions list down in the order.
 * @param calcButton Calculates the result states and updates the parent.
 * @param state The current state.
 * @param actions The current list of selected actions.
 */
public class CompositeActionFrame extends JFrame implements ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private PlanPanel	parent;

	private JPanel		panel;
	private JPanel 		buttonPanel;
	private JScrollPane	leftScroll;
	private JScrollPane	rightScroll;
	private JList 		available;
	private JList 		selected;

	private JButton		addButton;
	private JButton 	removeButton;
	private JButton		upButton;
	private JButton 	downButton;
	private JButton		calcButton;

	private State		state;
	private ArrayList<planIt.data.Action> actions;

	public CompositeActionFrame(PlanPanel parent)
	{
		// Set the JFrame title
		super("Composite Action Window");

		this.parent = parent;

		panel = new JPanel();
		buttonPanel = new JPanel();

		available = new JList(Globals.actions.values().toArray());
		available.setCellRenderer(new MyCellRenderer());
		selected = new JList();
		selected.setCellRenderer(new MyCellRenderer());

		leftScroll = new JScrollPane(available);
		rightScroll = new JScrollPane(selected);

		addButton = new JButton("   Add >>   ");
		addButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		addButton.setFont(Globals.mediumFont);

		removeButton = new JButton("<< Remove");
		removeButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		removeButton.setFont(Globals.mediumFont);

		upButton = new JButton("  Move up  ");
		upButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		upButton.setFont(Globals.mediumFont);

		downButton = new JButton("Move down");
		downButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		downButton.setFont(Globals.mediumFont);

		calcButton = new JButton("Calculate");
		calcButton.setAlignmentX(Component.CENTER_ALIGNMENT);
		calcButton.setFont(Globals.mediumFont);

		addButton.addActionListener(this);
		removeButton.addActionListener(this);
		upButton.addActionListener(this);
		downButton.addActionListener(this);
		calcButton.addActionListener(this);

		actions = new ArrayList<planIt.data.Action>();
		state = parent.getCurrentState();

		panel.setLayout(new BoxLayout(panel, BoxLayout.LINE_AXIS));
		panel.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

		buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.PAGE_AXIS));
		buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		available.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		selected.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));

		buttonPanel.add(addButton);
		buttonPanel.add(removeButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(0, 15)));
		buttonPanel.add(upButton);
		buttonPanel.add(downButton);
		buttonPanel.add(Box.createRigidArea(new Dimension(0, 20)));
		buttonPanel.add(calcButton);

		panel.add(leftScroll);
		panel.add(buttonPanel);
		panel.add(rightScroll);

		add(panel);

		pack();
		setLocationRelativeTo(parent);
		setVisible(true);

		Globals.frame.addWindowListener(new WindowAdapter()
		{
			public void windowClosed(WindowEvent e)
			{
				dispose();
			}
		});
	}

	/**
	 * Custom Cell renderer for the current state detail pane.
	 * @param sVal The attribute value data object.
	 * @param text The text to be displayed by this cell renderer.
	 */
	class MyCellRenderer extends planIt.data.Action implements ListCellRenderer
	{
		// Revision ID - Prevents annoying warning in Java 1.5
		public static final long serialVersionUID = 1;

		protected DefaultListCellRenderer defaultRenderer = new DefaultListCellRenderer();

		public MyCellRenderer()
		{}

		public Component getListCellRendererComponent(JList list, Object value, int index, boolean isSelected, boolean cellHasFocus)
		{
			JLabel renderer = (JLabel) defaultRenderer.getListCellRendererComponent(list, value, index, isSelected,
					cellHasFocus);

			if (!(value instanceof planIt.data.Action))
			{
				return renderer;
			}

			// Add code here to render on mouse hover - tooltip?
			if (isSelected)
			{}

			renderer.setText(((planIt.data.Action) value).description);
			renderer.setFont(Globals.mediumFont);
			return renderer;
		}
	}


	public class StateListener implements CurrentStateListener
	{
		public void currentStateChanged(State newState)
		{
			state = newState;
		}
	}

	public void actionPerformed(ActionEvent e)
	{
		planIt.data.Action action = null;

		if (e.getSource() == addButton)
		{
			action = (planIt.data.Action) available.getSelectedValue();

			if (action != null)
			{
				actions.add(action);
				selected.setListData(actions.toArray());
			}

			selected.setSelectedIndex(actions.size() - 1);
		}

		else if (e.getSource() == removeButton)
		{
			action = (planIt.data.Action) selected.getSelectedValue();
			int index = selected.getSelectedIndex();

			if (action != null)
			{
				actions.remove(action);
				selected.setListData(actions.toArray());
			}

			if (index >= 0 && index < actions.size())
			{
				selected.setSelectedIndex(index);
			}

			else if (index == actions.size())
			{
				selected.setSelectedIndex(index - 1);
			}
		}

		else if (e.getSource() == upButton)
		{
			action = (planIt.data.Action) selected.getSelectedValue();

			if (action != null)
			{
				int index = actions.indexOf(action);

				if (index > 0)
				{
					actions.remove(action);
					actions.add(index - 1, action);
					selected.setListData(actions.toArray());
					selected.setSelectedIndex(index - 1);
				}
			}
		}

		else if (e.getSource() == downButton)
		{
			action = (planIt.data.Action) selected.getSelectedValue();

			if (action != null)
			{
				int index = actions.indexOf(action);

				if (index < actions.size() - 1)
				{
					actions.remove(action);
					actions.add(index + 1, action);
					selected.setListData(actions.toArray());
					selected.setSelectedIndex(index + 1);
				}
			}
		}

		else if (e.getSource() == calcButton)
		{
			state = new State(state);
			double prob = 1.0;
			ArrayList<State> states = new ArrayList<State>();
			ArrayList<State> result = new ArrayList<State>();
			int index = -1;

			state.probability = prob;
			result.add(state);

			for (planIt.data.Action nextAction : actions)
			{
				states.clear();
				states.addAll(result);
				result.clear();

				for (State next : states)
				{
					prob = next.getProbability();

					for (State outcome : next.resultStates(nextAction))
					{
						index = result.indexOf(outcome);

						// No match, add to possible outcomes
						if (index < 0)
						{
							outcome.probability *= prob;
							result.add(outcome);
						}

						// Match, don't add dupe but sum probabilities
						else
						{
							result.get(index).probability += (outcome.getProbability() * prob);
						}
					}
				}
			}

			parent.setCompositeActions(result);
			parent.shapesPanel.setActionLabel("Composite Actions");
		}
	}
}

