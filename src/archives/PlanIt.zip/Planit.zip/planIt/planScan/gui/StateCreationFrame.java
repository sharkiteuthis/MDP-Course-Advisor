package planIt.planScan.gui;


// Java Packages
import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.BorderFactory;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.event.EventListenerList;

import planIt.data.Attribute;
import planIt.data.Globals;
import planIt.data.Value;
import planIt.planScan.data.State;
import planIt.planScan.data.StateValue;


public class StateCreationFrame extends JFrame implements ActionListener
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	private JPanel 				panel;
	private JPanel				boxPanel;
	private JPanel				buttonPanel;
	private JList 				list;
	private MyComboBox[]		valueBoxes;
	private JButton				doneButton;
	private State				state;
	private EventListenerList 	listenerList;

	public StateCreationFrame(State state, boolean wildcards)
	{
		// Set the JFrame title
		super("PlanIt - The Interactive Planner");

		// Setup Frame size and position on screen
		Dimension dim = Toolkit.getDefaultToolkit().getScreenSize();

		setBounds(dim.width / 4, dim.height / 4, dim.width / 2, dim.height / 2);
		setDefaultCloseOperation(DISPOSE_ON_CLOSE);

		panel = new JPanel();
		boxPanel = new JPanel();
		buttonPanel = new JPanel();
		list = new JList();
		this.state = new State(state);
		doneButton = new JButton("Finished");
		valueBoxes = new MyComboBox[Globals.attributes.size()];
		listenerList = new EventListenerList();

		boxPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		boxPanel.setLayout(new GridLayout(0, 1));

		buttonPanel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		// buttonPanel.setLayout(new BoxLayout(buttonPanel, BoxLayout.LINE_AXIS));

		panel.setBorder(BorderFactory.createEmptyBorder(5, 5, 5, 5));
		panel.setLayout(new BorderLayout());

		doneButton.addActionListener(this);

		int i = 0;
		Value value = null;

		for (Attribute attribute : Globals.attributes.values())
		{
			valueBoxes[i] = new MyComboBox(attribute, wildcards);
			value = state.stateValues.get(attribute.getName()).getValue();

			if (value != null)
			{
				valueBoxes[i].setSelectedItem(value);
			}

			else
			{
				valueBoxes[i].setSelectedItem("Any value");
			}

			boxPanel.add(valueBoxes[i]);
			i++;
		}

		buttonPanel.add(doneButton);

		panel.add(boxPanel, BorderLayout.CENTER);
		panel.add(buttonPanel, BorderLayout.SOUTH);

		add(panel);

		pack();
		setVisible(true);
	}

	public void toState()
	{
		Object selection = null;
		StateValue stateValue = null;
		Value value = null;

		state = new State();

		for (int i = 0; i < valueBoxes.length; i++)
		{
			selection = valueBoxes[i].getSelectedItem();
			stateValue = state.stateValues.get(valueBoxes[i].getAttribute().getName());

			if (selection instanceof Value)
			{
				value = (Value) selection;
				state.stateValues.get(valueBoxes[i].getAttribute().getName()).setValue(value);
			}
		}
	}

	public void actionPerformed(ActionEvent e)
	{
		if (e.getSource() == doneButton)
		{
			toState();
			fireStateCreated(state);
			dispose();
		}
	}

	public class MyComboBox extends JComboBox
	{
		// Revision ID - Prevents annoying warning in Java 1.5
		public static final long serialVersionUID = 1;

		private Attribute attribute;

		public MyComboBox(Attribute attribute, boolean wildcard)
		{
			this.attribute = attribute;

			for (Value value : attribute.values.values())
			{
				addItem(value);
			}

			if(wildcard)
			{
				addItem("Any value");
			}
		}

		public Attribute getAttribute()
		{
			return attribute;
		}
	}

	/**
	 * Adds a <code>StateCreationListener</code> to this
	 * <code>StateCreationFrame</code>.
	 * @param l The <code>StateCreationListener</code> to be added.
	 */
	public void addStateCreationListener(StateCreationListener l)
	{
		listenerList.add(StateCreationListener.class, l);
	}

	/**
	 * Removes a <code>StateCreationListener</code> from this
	 * <code>StateCreationFrame</code>.
	 * @param l The <code>StateCreationListener</code> to be removed.
	 */
	public void removeStateCreationListener(StateCreationListener l)
	{
		listenerList.remove(StateCreationListener.class, l);
	}

	/**
	 * Returns an array of all the <code>StateCreationListener</code>s added to
	 * this <code>StateCreationFrame</code> with
	 * <code>addStateCreationListener()</code>.
	 * @return all of the <code>StateCreationListener</code>s added or an empty
	 * array if no listeners have been added
	 */
	public StateCreationListener[] getStateCreationListener()
	{
		return listenerList.getListeners(StateCreationListener.class);
	}

	/**
	 * Notifies all registered <code>StateCreationListener</code>s.
	 * @param state The current <code>State</code>.
	 */
	protected void fireStateCreated(State state)
	{
		Object[] listeners = listenerList.getListenerList();

		for (Object i : listeners)
		{
			if (i instanceof StateCreationListener)
			{
				((StateCreationListener) i).stateCreated(state);
			}
		}
	}
}

