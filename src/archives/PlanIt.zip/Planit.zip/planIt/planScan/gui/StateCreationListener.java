package planIt.planScan.gui;


import java.util.EventListener;

import planIt.planScan.data.State;


/**
 * The listener is notified when a new <code>State</code> is created.
 */
public interface StateCreationListener extends EventListener
{

	/**
	 * Informs all <code>StateCreationListener</code>s when a new
	 * <code>State<code> object is created.
	 * @param state  The new <code>State<code>.
	 */
	void stateCreated(State state);
}

