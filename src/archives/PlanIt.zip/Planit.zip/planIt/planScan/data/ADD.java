package planIt.planScan.data;


import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Map;

import javax.swing.tree.DefaultMutableTreeNode;

import planIt.data.Attribute;
import planIt.data.Globals;
import planIt.data.Value;
import planIt.poet.data.Archetype;
import planIt.poet.data.PrefNode;
import planIt.poet.data.UtilityNode;


/**
 * Contains a map of tree fragments by action name
 */
public class ADD
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	public Map<String, ArrayList<ADDParent> > 	children; // Map of child nodes by Action name
	public ADDParent 							reward; // Optional reward info from ADD
	public double 								discount;
	public double								tolerance;

	public String toSPUDD()
	{
		String out = "(variables";
		String name = null;

		for (Attribute attr : Globals.attributes.values())
		{
			out += " (" + attr.getName();

			for (Value val : attr.values.values())
			{
				out += " " + val.getName();
			}

			out += ")\n";
		}

		out += ")\n\n";

		for (String actionName : Globals.actions.keySet())
		{
			out += "action " + actionName + "\n";

			for (ADDParent node : children.get(actionName))
			{
				name = node.getAttribute().getName();
				out += "  " + name;
				out += actionToSPUDD(node, node.getAttribute().getName()) + "\n";
			}

			out += "endaction\n\n";
		}

		out += prefsToSPUDD();
		out += "discount " + discount + "\n";
		out += "tolerance " + tolerance + "\n";

		return out;
	}

	private String actionToSPUDD(ADDNode node, String rootName)
	{
		String out = "";

		if (node instanceof ADDParent)
		{
			ADDParent parent = (ADDParent) node;

			out += " (" + parent.getAttribute().getName();

			for (String valueName : parent.children.keySet())
			{
				out += " (" + valueName;
				out += actionToSPUDD(parent.children.get(valueName), rootName);
				out += ")";
			}

			out += ")";
		}

		else if (node instanceof ADDLeaf)
		{
			ADDLeaf leaf = (ADDLeaf) node;

			out += " (" + rootName + "'";

			for (String valueName : leaf.cpt.keySet())
			{
				out += " (" + valueName + " (";
				out += leaf.cpt.get(valueName).toString() + "))";
			}

			out += ")";
		}

		return out;
	}

	private String prefsToSPUDD()
	{
		String out = "";

		out += prefTreeToSPUDD(Globals.prefs, true) + "\n";

		return out;
	}

	private String prefTreeToSPUDD(DefaultMutableTreeNode node, boolean printAttr)
	{
		String out = "";
		Object object = node.getUserObject();

		if(object instanceof Archetype)
		{
			ArrayList<DefaultMutableTreeNode> list = new ArrayList<DefaultMutableTreeNode>();
			DefaultMutableTreeNode[] array = null;
			boolean processed = false;

			for(Enumeration e = node.children(); e.hasMoreElements();)
			{
				list.add((DefaultMutableTreeNode) e.nextElement());
			}

			array = new DefaultMutableTreeNode[list.size()];
			list.toArray(array);

			for(int i=0; i<array.length; i++)
			{
				processed = false;

				for(int j=i-1; j >= 0; j--)
				{
					if(((PrefNode)array[i].getUserObject()).getAttribute() == ((PrefNode)array[j].getUserObject()).getAttribute())
					{
						processed = true;
						break;
					}
				}

				if(!processed)
				{
					out += "reward";
					out += prefTreeToSPUDD(array[i], true);

					for(int j=i+1; j<array.length; j++)
					{


						if(((PrefNode)array[i].getUserObject()).getAttribute() == ((PrefNode)array[j].getUserObject()).getAttribute())
						{
							out += prefTreeToSPUDD(array[j], false);
						}
					}

					out += ")\n";
				}
			}
		}

		if(object instanceof UtilityNode)
		{
			UtilityNode uNode = (UtilityNode) object;

			if(printAttr)
			{
				out += " (" + uNode.getAttribute().getName();
			}

			out += " (" + uNode.getValue().getName();
			out += " (" + uNode.getUtility() + "))";
		}

		else if(object instanceof PrefNode)
		{
			PrefNode pNode = (PrefNode) object;
			ArrayList<DefaultMutableTreeNode> list = new ArrayList<DefaultMutableTreeNode>();
			DefaultMutableTreeNode[] array = null;
			boolean processed = false;

			if(printAttr)
			{
				out += " (" + pNode.getAttribute().getName();
			}

			out += " (" + pNode.getValue().getName();

			for(Enumeration e = node.children(); e.hasMoreElements();)
			{
				list.add((DefaultMutableTreeNode) e.nextElement());
			}

			array = new DefaultMutableTreeNode[list.size()];
			list.toArray(array);

			for(int i=0; i<array.length; i++)
			{
				processed = false;

				for(int j=i-1; j >= 0; j--)
				{
					if(((PrefNode)array[i].getUserObject()).getAttribute() == ((PrefNode)array[j].getUserObject()).getAttribute())
					{
						processed = true;
						break;
					}
				}

				if(!processed)
				{
					out += prefTreeToSPUDD(array[i], true);

					for(int j=i+1; j<array.length; j++)
					{
						if(((PrefNode)array[i].getUserObject()).getAttribute() == ((PrefNode)array[j].getUserObject()).getAttribute())
						{
							out += prefTreeToSPUDD(array[j], false);
						}
					}
				}
			}

			out += ")";

			if(printAttr)
			{
				out += ")";
			}
		}

		return out;
	}
}

