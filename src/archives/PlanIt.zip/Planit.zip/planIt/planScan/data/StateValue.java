package planIt.planScan.data;


// Local packages
import planIt.data.Attribute;
import planIt.data.Value;


public class StateValue
{
	public Attribute 	attribute;
	public Value		value;
	public double		probability;

	/**
	 * Instantiates the StateValue object with a probability of 1.0
	 */
	public StateValue()
	{
		attribute = null;
		value = null;
		probability = 1.0;
	}

	/**
	 * Intantiates the StateValue object with the given attribute, value and probability.
	 */
	public StateValue(Attribute attr, Value value, double prob)
	{
		attribute = attr;
		this.value = value;
		probability = prob;
	}

	/**
	 * Copy constructor
	 */
	public StateValue(StateValue stateValue)
	{
		if (stateValue == null)
		{
			System.err.println("Null StateValue given as argument to copy constructor");
		}

		else
		{
			attribute = stateValue.attribute;
			probability = stateValue.probability;
			value = stateValue.value;
		}
	}

	public void setValue(Value value)
	{
		this.value = value;
	}

	public Value getValue()
	{
		return value;
	}

	public Attribute getAttribute()
	{
		return attribute;
	}

	public boolean equals(StateValue compare)
	{
		if (compare == null)
		{
			return false;
		}

		if (attribute != compare.getAttribute())
		{
			return false;
		}

		if (value != null && compare.getValue() != null && value != compare.getValue())
		{
			return false;
		}

		return true;
	}
}

