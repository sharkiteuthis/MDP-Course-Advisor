package planIt.planScan.data;


// Java packages
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Set;

import planIt.data.Action;


public class Plan implements ADDNode
{
	public ADDParent root;

	public Plan(ADDParent root)
	{
		this.root = root;
	}

	public Plan(ADDNode root)
	{
		if(root instanceof ADDParent)
		{
			this.root = (ADDParent)root;
		}

		else
		{
			System.err.println("The root node of a plan must be an ADDParent");
		}
	}

	/**
	 * Print a plan to a string
	 */
	public String print()
	{
		String out = null;

		out = printNode(root, "");

		return out;
	}

	private String printNode(ADDNode node, String tab)
	{
		String out = "";
		String value = null;

		if (node instanceof ADDParent)
		{
			ADDParent temp = (ADDParent) node;

			Set<String> keys = temp.children.keySet();

			out += tab + "Attribute: " + temp.attribute.getName() + "\n";

			tab += "  ";

			for (Iterator<String> itr = keys.iterator(); itr.hasNext();)
			{
				value = itr.next();
				out += tab + "Value: " + value + "\n";
				out += printNode(temp.children.get(value), tab + "  ");
			}
		}

		else if (node instanceof PlanLeaf)
		{
			PlanLeaf temp = (PlanLeaf) node;

			for (Iterator<Action> itr = temp.actions.iterator(); itr.hasNext();)
			{
				out += tab + "Action: " + itr.next().toString() + "\n";
			}
		}

		return out;
	}

	public String printXML()
	{
		String out = ("<?xml version=\"1.0\" encoding=\"UTF-8\"?>\n");

		out += "<plan>\n";
		out += printNodeXML(root, "\t");
		out += "</plan>\n";

		return out;
	}

	private String printNodeXML(ADDNode node, String tab)
	{
		String out = "";

		if (node instanceof ADDParent)
		{
			ADDParent temp = (ADDParent) node;

			out += tab + "<attribute>\n";
			out += tab + "\t" + "<name>" + temp.attribute.getName() + "</name>\n";

			for (String value : temp.children.keySet())
			{
				out += tab + "\t" + "<edge name=\"" + value + "\">\n";
				out += printNodeXML(temp.children.get(value), tab + "\t\t");
				out += tab + "\t" + "</edge>\n";
			}

			out += tab + "</attribute>\n";
		}

		else if (node instanceof PlanLeaf)
		{
			PlanLeaf temp = (PlanLeaf) node;

			out += tab + "<actions>\n";

			for (Action action : temp.actions)
			{
				out += tab + "\t" + "<action>" + action.getName();
				out += "</action>" + "\n";
			}

			out += tab + "</actions>\n";
		}

		return out;
	}

	/**
	 * Given a State, returns the action(s) suggest by this plan
	 */
	public ArrayList<Action> getAction(State state)
	{
		ADDParent node = root;
		ADDNode temp = null;
		StateValue stateValue = null;

		while (root != null)
		{
			// Get the state value of the root plan attribute
			stateValue = state.stateValues.get(node.attribute.name);

			if (stateValue == null)
			{
				System.err.println("Could not find the attribute \"" + node.attribute.name + "\"");
			}

			// Follow the plan branch corresponding to the current state attribute value
			temp = node.children.get(stateValue.value.name);

			// error
			if (temp == null)
			{
				System.err.println(
						"Could not find the value \"" + stateValue.value.name + "\" for attribute \"" + node.attribute.name
						+ "\"");
				break;
			}// Repeat with new parent node

			else if (temp instanceof ADDParent)
			{
				node = (ADDParent) temp;
			}// Found leaf, return actions

			else if (temp instanceof PlanLeaf)
			{
				return ((PlanLeaf) temp).actions;
			}
		}

		System.err.println("Could not find suggested action");
		return new ArrayList<Action>();
	}
}

