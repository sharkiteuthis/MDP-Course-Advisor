package planIt.planScan.data;


import java.util.HashMap;
import java.util.Map;


public class ADDLeaf implements ADDNode
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	public Map<String, Double> cpt; // CPT values mapped by value name

	public ADDLeaf()
	{
		cpt = new HashMap<String, Double>();
	}
}

