package planIt.planScan.data;


import java.util.ArrayList;

import planIt.data.Action;


public class PlanLeaf implements ADDNode
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	public ArrayList<Action> actions; // List of suggested actions

	public PlanLeaf()
	{
		actions = new ArrayList<Action>();
	}

	public void addAction(Action action)
	{
		if(!actions.contains(action))
		{
			actions.add(action);
		}
	}
}

