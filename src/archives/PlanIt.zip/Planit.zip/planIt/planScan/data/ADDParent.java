package planIt.planScan.data;


import java.util.HashMap;
import java.util.Map;

import planIt.data.Attribute;


/**
 * A node with an Attribute and a map of child nodes by value name (String)
 */
public class ADDParent implements ADDNode
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	public Attribute attribute;				// Attribute being represented
	public Map<String, ADDNode> children; 	// Edges mapped by attribute value name

	/**
	 *Creates a new Node with no children and the given attribute
	 */
	public ADDParent(Attribute attribute)
	{
		this.attribute = attribute;
		children = new HashMap<String, ADDNode>();
	}

	public void addChild(String value, ADDNode child)
	{
		children.put(value, child);
	}


	public Attribute getAttribute()
	{
		return attribute;
	}
}

