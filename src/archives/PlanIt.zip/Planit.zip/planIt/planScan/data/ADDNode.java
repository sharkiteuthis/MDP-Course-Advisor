package planIt.planScan.data;


public interface ADDNode
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;
}

