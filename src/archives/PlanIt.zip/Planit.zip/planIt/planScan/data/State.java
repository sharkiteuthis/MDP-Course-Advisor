package planIt.planScan.data;


// Java packages
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.swing.tree.DefaultMutableTreeNode;

import planIt.data.Action;
import planIt.data.Attribute;
import planIt.data.Globals;
import planIt.poet.data.Archetype;
import planIt.poet.data.PrefNode;
import planIt.poet.data.UtilityNode;


public class State
{
	// Revision ID - Prevents annoying warning in Java 1.5
	public static final long serialVersionUID = 1;

	public HashMap<String, StateValue> stateValues;
	public double probability;

	/**
	 * Creates a new empty state.
	 */
	public State()
	{
		String name = null;

		stateValues = new HashMap<String, StateValue>();
		probability = 0;

		for (Attribute temp : Globals.attributes.values())
		{
			stateValues.put(temp.name, new StateValue(temp, null, 1.0));
		}
	}

	/**
	 * Creates a new State with the same values as the given state.
	 * @param state The state whose values are copied for the new state.
	 */
	public State(State state)
	{
		stateValues = new HashMap<String, StateValue>();
		probability = state.getProbability();

		if (state == null)
		{
			System.err.println("The state is null");
			return;
		}

		for (StateValue temp : state.stateValues.values())
		{
			stateValues.put(temp.attribute.name, new StateValue(temp));
		}
	}

	/**
	 * Enumerate and return all possible resulting states for given action
	 * @param action The action for which the result states are calculated.
	 * @return An array list of the possible resulting states.
	 */
	public ArrayList<State> resultStates(Action action)
	{
		ArrayList<ADDParent> list = Globals.add.children.get(action.name);
		ArrayList<State> outcome = new ArrayList<State>();
		Map<String, Double> cpt = null;

		outcome.add(new State());

		for (ADDParent node : list)
		{
			cpt = getCPT(node);
			outcome = new ArrayList<State>(enumerateStates(outcome, cpt, node.attribute));
		}

		for (State state : outcome)
		{
			state.updateProbability();
		}

		return outcome;
	}

	/**
	 * Follows a branch from the given Cell to a leaf based on the State's
	 * attribute values and returns the CPT
	 * @param node The root of an ADD to use in generating the CPT
	 */
	Map<String, Double> getCPT(ADDNode node)
	{
		String valueName = null;
		ADDParent temp = null;

		// Parse the fragment until you reach a leaf
		while (node instanceof ADDParent)
		{
			temp = (ADDParent) node;

			// Choose branch based on this states value for the current attribute
			valueName = stateValues.get(temp.attribute.name).value.getName();
			node = temp.children.get(valueName);
		}

		if (node == null)
		{
			System.err.println("Unknown value name");
			return null;
		}

		return ((ADDLeaf) node).cpt;
	}

	/**
	 * For each state in the list, the CPT is used to determine if an enumerated next possible state has
	 * a non-zero chance of occuring.  If so, it is added to the list.  In this way, states that have no
	 * chance of occuring are never added and the list requires no pruning.
	 * @param states The current list of enumerated states.
	 * @param cpt The conditional probability table corresponding to the current state for some selected
	 * action, used to compute the probabilities of each enumerated state.
	 * @param attr The current attribute.
	 * @return A list of newly enumerated states
	 */
	public List<State> enumerateStates(List<State> states, Map<String, Double> cpt, Attribute attr)
	{
		List<State> outcome = new ArrayList<State>();
		State temp = null;
		StateValue sVal = null;
		double prob = 0;

		for (State state : states)
		{
			for (String value : cpt.keySet())
			{
				prob = cpt.get(value).doubleValue();

				if (prob != 0)
				{
					temp = new State(state);
					sVal = temp.stateValues.get(attr.name);
					sVal.value = attr.values.get(value);
					sVal.probability = prob;
					outcome.add(temp);
				}
			}
		}

		return outcome;
	}

	/**
	 * Gets the probability of the state (assumes the probability of each value has already been computed)
	 * @return The probability of the state.
	 */
	public double getProbability()
	{
		return probability;
	}

	public void updateProbability()
	{
		probability = 1.0;

		for (StateValue value : stateValues.values())
		{
			probability *= value.probability;
		}
	}

	/**
	 * Gets the utility for this state based on the global preference tree
	 * @return The utility for the state, bounded between 1 and -1.
	 */
	public double getUtility()
	{
		return (getUtility(Globals.prefs) / (double) stateValues.size());
	}

	/**
	 * Gets the utility for this state.
	 * @param node The root of a preference tree from which preferences are retrieved.
	 * @return The utility for the state, bounded between 1 and -1.
	 */
	private double getUtility(DefaultMutableTreeNode node)
	{
		double utility = 0;
		Object object = null;

		if (node == null)
		{
			return utility;
		}

		object = node.getUserObject();

		// If the node is the archetype (root), recursively call on each child
		if (object instanceof Archetype)
		{
			for (Enumeration e = node.children(); e.hasMoreElements();)
			{
				utility += getUtility((DefaultMutableTreeNode) e.nextElement());
			}
		}

		else if (object instanceof UtilityNode)
		{
			UtilityNode temp = (UtilityNode) object;
			StateValue val = stateValues.get(temp.attribute.name);

			if (temp.value.name.equals(val.value.name))
			{
				utility += temp.utility;
			}
		}

		else if (object instanceof PrefNode)
		{
			PrefNode temp = (PrefNode) object;
			StateValue val = stateValues.get(temp.attribute.name);

			if (temp.value.name.equals(val.value.name))
			{
				for (Enumeration e = node.children(); e.hasMoreElements();)
				{
					utility += getUtility((DefaultMutableTreeNode) e.nextElement());
				}
			}
		}

		return utility;
	}

	/**
	 * Gets a <code>List</code> of string representations of the State's attribute values.
	 * @return A <code>List</code> of HTML encoded value descriptions.
	 */
	public List<String> toStrings()
	{
		List<String> temp = new ArrayList<String>();

		if (stateValues == null || stateValues.size() == 0)
		{
			return new ArrayList<String>();
		}

		for (Iterator<StateValue> itr = stateValues.values().iterator(); itr.hasNext();)
		{
			temp.add("<html><FONT SIZE=4>" + itr.next().value.description + " </FONT></html>");
		}

		return temp;
	}

	/**
	 * Returns string of state values seperated by commas.
	 * @return A comma separated list of value names.
	 */
	public String toString()
	{
		String out = "";

		if (stateValues == null || stateValues.size() == 0)
		{
			return out;
		}

		out += "(";

		for (Iterator<StateValue> itr = stateValues.values().iterator(); itr.hasNext();)
		{
			out += itr.next().value.name;

			if (itr.hasNext())
			{
				out += ",";
			}
		}

		out += ")";

		return out;
	}

	/**
	 * Prints all attributes and their values to a <code>String</code>.
	 * @return A <code>String</code> of all attribute/value pairs that make up the state,
	 * separated by newline characters.
	 */
	public String print()
	{
		String out = new String();

		for (StateValue temp : stateValues.values())
		{
			if (temp.attribute != null)
			{
				out += temp.attribute.getName() + " = ";
			}

			else
			{
				out += "Null attribute = ";
			}

			if (temp.value != null)
			{
				out += temp.value.getName() + "\n";
			}

			else
			{
				out += "Null value \n";
			}
		}

		return out;
	}

	/**
	 * Returns true if the given state has the same values as the current state
	 * @param state the <code>State</code> to be compared to this <code>State</code>
	 * @return True is the states are equal, false otherwise.
	 */
	public boolean equals(State state)
	{
		StateValue value2 = null;

		if (state == null)
		{
			return false;
		}

		// Compare sizes to possibly catch a quick false
		if (stateValues.size() != state.stateValues.size())
		{
			return false;
		}

		// Match all values - null Value objects are considered wildcards
		for (StateValue value1 : stateValues.values())
		{
			value2 = state.stateValues.get(value1.attribute.getName());

			if (!value1.equals(value2))
			{
				return false;
			}
		}

		return true;
	}

	/**
	 * Returns true if the given state has the same values as the current state.
	 * This function overrides the <code>Object</code> equals fucntion.
	 * @param state The <code>Object</code> to be compared to this <code>State</code>
	 * @return True is the states are equal, false otherwise.
	 */
	public boolean equals(Object state)
	{
		State temp = null;
		StateValue value2 = null;

		if (state == null || !(state instanceof State))
		{
			return false;
		}

		temp = (State) state;

		// Compare sizes to possibly catch a quick false
		if (stateValues.size() != temp.stateValues.size())
		{
			return false;
		}

		// Match all values - null Value objects are considered wildcards
		for (StateValue value1 : stateValues.values())
		{
			value2 = temp.stateValues.get(value1.attribute.getName());

			if (!value1.equals(value2))
			{
				return false;
			}
		}

		return true;
	}

	public int hashCode()
	{
		int result = 0;

		for (StateValue value : stateValues.values())
		{
			result += value.hashCode();
		}

		return result;
	}
}

