#! /usr/bin/env bash

#echo "2 Actions:"
#java -Xmx512m planIt/pole/CMain 2act.txt
#java -Xmx512m planIt/pole/CMain 2act.txt
#java -Xmx512m planIt/pole/CMain 2act.txt
#java -Xmx512m planIt/pole/CMain 2act.txt

echo "6 Actions:"
java -Xmx512m planIt/pole/CMain 6act.txt
java -Xmx512m planIt/pole/CMain 6act.txt
java -Xmx512m planIt/pole/CMain 6act.txt
java -Xmx512m planIt/pole/CMain 6act.txt


